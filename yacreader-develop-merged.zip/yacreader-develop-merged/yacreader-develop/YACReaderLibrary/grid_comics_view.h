    void setToolBar(QToolBar *toolBar) override;
    void releaseToolBar() override;
    void saveViewConfig() override;
    void setCurrentIndex(const QModelIndex &index) override;
    QModelIndex currentIndex() override;
    QItemSelectionModel *selectionModel() override;
    void scrollTo(const QModelIndex &mi, QAbstractItemView::ScrollHint hint) override;
    void toFullScreen() override;
    void toNormal() override;
    void updateConfig(QSettings *settings) override;
    void enableFilterMode(bool enabled) override;
    QByteArray getMimeDataFromSelection();
    void updateCurrentComicView() override;
    void focusComicsNavigation(Qt::FocusReason reason) override;
    void reloadContent() override;
    ContentViewState captureViewState() const override;
    bool eventFilter(QObject *watched, QEvent *event) override;

public slots:
    // ComicsView
    void setShowMarks(bool show) override;
    void selectAll() override;
    void selectIndex(int index) override;
    void triggerOpenCurrentComic();
    void updateSettings();
    void updateBannerSettings();
    void updateBackgroundConfig();
    void updateInfoPanelVisibility();

    // Showcase style is controlled by YACReaderContentViewsManager.
    void setShowcaseStyle(bool enabled);

protected slots:
    // QML - double clicked item
    void activateItem(int viewRow);

    // QML - rating
    void rate(int index, int rating);
    // QML - dragManager
    void startDrag();
    // QML - dropManager
    bool canDropUrls(const QList<QUrl> &urls, Qt::DropAction action);
    bool canDropImage(const QList<QUrl> &urls);
    bool canDropFormats(const QStringList &formats);
    void droppedFiles(const QList<QUrl> &urls, Qt::DropAction action);
    void droppedImageAt(const QList<QUrl> &urls, int viewRow);
    void droppedComicsForResortingAt(const QString &data, int index);
    // QML - context menu
    void requestItemContextMenu(const QPoint &point, int viewRow);

    void setCoversSize(int width);
    void updateCoversSizeInContext(int width, QQmlContext *ctxt);

    // Showcase style: bigger covers, rounded corners, soft shadows and reading progress bars
    bool isShowcaseStyle() const { return showcaseStyle; }

    void updateCurrentComicBanner();

    void applyPendingViewState();

    virtual void showEvent(QShowEvent *event) override;

signals:
    void onScrollToOrigin();
    void folderSelected(const QModelIndex &index);
    void openFolderContextMenu(const QPoint &point, const Folder &folder);
    void openContinueReadingComicContextMenu(const QPoint &point, const ComicDB &comic);
    void comicSelectionStateChanged(bool hasSelection);
    void selectedComicsInfoChanged();
    void rootContinueReadingModelChanged();
    void rootFolderChanged();
    void globalContinueReadingEnabledChanged();
    void currentComicBannerVisibleChanged();
    void focusedFolderChanged();
    void currentLocationInfoChanged();
    void openLibraryFolderRequested();

private:
    QSettings *settings;
    QToolBar *toolbar;
    QWidget *coverSizeSliderWidget;
    QSlider *coverSizeSlider;
    QAction *coverSizeSliderAction;
    QAction *showInfoAction;
    QAction *showInfoSeparatorAction;
    QAction *startSeparatorAction;

    bool filterEnabled;
    bool showcaseStyle = false;

    YACReaderComicsSelectionHelper *selectionHelper;
    YACReaderComicInfoHelper *comicInfoHelper;
    GridContentModel *contentModel;
    std::unique_ptr<ComicModel> rootContinueReadingModelStorage;
    bool rootFolder = false;
    bool globalContinueReadingEnabled = true;
    bool currentComicBannerVisible = false;
    QPersistentModelIndex focusedFolderIndex;
    QVariantMap focusedFolderInfo;
    QVariantMap currentLocationInfo;
    QTimer *viewStateTimer;
    std::optional<ContentViewState> pendingViewState;
    QMetaObject::Connection modelDataChangedConnection;
    QMetaObject::Connection modelFavoritesChangedConnection;

    ComicDB currentComic;

    void closeEvent(QCloseEvent *event) override;
    void createCoverSizeSliderWidget();
    QVariantMap makeFolderInfo(const Folder &folder, const QVariant &cover) const;
    void updateCurrentListIcon();
    void setFocusedFolder(int viewRow);
    void clearFocusedFolder();
    int viewRowForItem(const ContentItemRef &item) const;

    // Zoom slider labels (for theming)
    QLabel *smallZoomLabel;
    QLabel *bigZoomLabel;
};

#endif // GRID_COMICS_VIEW_H
