#ifndef INFOCOMICSVIEW_H
#define INFOCOMICSVIEW_H

#include "comics_view.h"
#include "themable.h"

#include <QQmlContext>

class QQuickView;

class YACReaderComicsSelectionHelper;
class YACReaderComicInfoHelper;

class InfoComicsView : public ComicsView, protected Themable
{
    Q_OBJECT
public:
    explicit InfoComicsView(QWidget *parent = nullptr);

protected:
    void applyTheme(const Theme &theme) override;
    ~InfoComicsView() override;
    void setToolBar(QToolBar *toolBar) override;
    void releaseToolBar() override;
    void setModel(ComicModel *model) override;
    void setCurrentIndex(const QModelIndex &index) override;
    QModelIndex currentIndex() override;
    QItemSelectionModel *selectionModel() override;
    void scrollTo(const QModelIndex &mi, QAbstractItemView::ScrollHint hint) override;
    void toFullScreen() override;
    void toNormal() override;
    void updateConfig(QSettings *settings) override;
    void enableFilterMode(bool enabled) override;
    void selectIndex(int index) override;
    void updateCurrentComicView() override;
    void focusComicsNavigation(Qt::FocusReason reason) override;
    ContentViewState captureViewState() const override;
    void restoreViewState(const ContentViewState &state) override;

public slots:
    void setShowMarks(bool show) override;
    void selectAll() override;

protected slots:
    void setCurrentIndex(int index);

    bool canDropUrls(const QList<QUrl> &urls, Qt::DropAction action);
    bool canDropImage(const QList<QUrl> &urls);
    void droppedFiles(const QList<QUrl> &urls, Qt::DropAction action);
    void droppedImage(const QList<QUrl> &urls);

    void requestedContextMenu(const QPoint &point);

    void selectedItem(int index);

protected:
    QToolBar *toolbar;
    QObject *flow;
    QObject *list;

    YACReaderComicsSelectionHelper *selectionHelper;
    YACReaderComicInfoHelper *comicInfoHelper;
};

#endif // INFOCOMICSVIEW_H
