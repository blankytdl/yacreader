#ifndef TREEMODEL_H
#define TREEMODEL_H

#include "folder.h"
#include "folder_query_result_processor.h"
#include "themable.h"
#include "yacreader_global.h"

#include <QAbstractItemModel>
#include <QHash>
#include <QIcon>
#include <QModelIndex>
#include <QSortFilterProxyModel>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QUrl>
#include <QVariant>

class FolderItem;

class FolderModelProxy : public QSortFilterProxyModel
{
    Q_OBJECT
public:
    explicit FolderModelProxy(QObject *parent = nullptr);
    ~FolderModelProxy() override;

    void setFilterData(QMap<unsigned long long, FolderItem *> *filteredItems, FolderItem *root);
    void clear();

    bool filterAcceptsRow(int source_row, const QModelIndex &source_parent) const override;

    // `comicSortKey` is a ComicModel::SortKey, see folder_sort.h
    void setFolderSort(int comicSortKey, Qt::SortOrder order);

protected:
    bool lessThan(const QModelIndex &left, const QModelIndex &right) const override;

    int folderSortKey = 0;
    FolderItem *rootItem;
    QMap<unsigned long long int, FolderItem *> filteredItems; // relación entre folders

    bool filterEnabled;
};

class FolderModel : public QAbstractItemModel, protected Themable
{
    Q_OBJECT

    friend class FolderModelProxy;
    friend class YACReader::FolderQueryResultProcessor;

public:
    static constexpr qulonglong RootFolderId = 1;

    explicit FolderModel(QObject *parent = nullptr);
    ~FolderModel() override;

    // QAbstractItemModel methods
    QVariant data(const QModelIndex &index, int role) const override;
    Qt::ItemFlags flags(const QModelIndex &index) const override;
    QVariant headerData(int section, Qt::Orientation orientation,
                        int role = Qt::DisplayRole) const override;
    QModelIndex index(int row, int column,
                      const QModelIndex &parent = QModelIndex()) const override;
    QModelIndex index(qulonglong folderId) const;
    QModelIndex parent(const QModelIndex &index) const override;
    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    int columnCount(const QModelIndex &parent = QModelIndex()) const override;
    QHash<int, QByteArray> roleNames() const override;

    // Convenience methods
    void reload();
    void reload(const QModelIndex &index);
    void setupModelData(QString path);
    QString getDatabase();
    QString getFolderPath(const QModelIndex &folder);

    void updateFolderCompletedStatus(const QModelIndexList &list, bool status);
    void updateFolderFinishedStatus(const QModelIndexList &list, bool status);
    void updateFolderType(const QModelIndexList &list, YACReader::FileType type);
    bool renameFolder(const QModelIndex &folder, const QString &name, QString *error = nullptr);
    void updateTreeType(YACReader::FileType type);
    void setCustomFolderCover(const QModelIndex &index, const QString &path);
    void resetFolderCover(const QModelIndex &index);

    Folder getRootFolder() const;
    Folder getFolder(const QModelIndex &mi) const;
    QModelIndex getIndexFromFolderId(qulonglong folderId, const QModelIndex &parent = QModelIndex());
    QModelIndex getIndexFromFolder(const Folder &folder, const QModelIndex &parent = QModelIndex());

    QModelIndex addFolderAtParent(const QString &folderName, const QModelIndex &parent);

    Q_INVOKABLE QUrl getCoverUrlPathForComicHash(const QString &hash) const;
    Q_INVOKABLE QUrl getCoverUrlPathForFolderId(qulonglong folderId) const;

    void setShowRecent(bool showRecent);
    void setRecentRange(int days);

    enum Columns {
        Name = 0,
        Path,
        Finished,
        Completed,
        NumChildren,
        FirstChildHash,
        CustomImage,
        Type, // FileType
        Added,
        Updated,
    };

    enum Roles {
        FinishedRole = Qt::UserRole + 1,
        CompletedRole,
        IdRole,
        CoverPathRole,
        FolderNameRole,
        NumChildrenRole,
        TypeRole,
        AddedRole,
        UpdatedRole,
        ShowRecentRole,
        RecentRangeRole,
    };

public slots:
    void deleteFolder(const QModelIndex &mi);
    void updateFolderChildrenInfo(qulonglong folderId);

private:
    void emitDataChangedRecursively(const QModelIndex &parent, int role);

    struct ModelData {
        FolderItem *rootItem; // items tree
        QMap<unsigned long long int, FolderItem *> items; // items lookup
    };

    void setModelData(const ModelData &modelData);
    ModelData createModelData(const QString &path) const;
    ModelData createModelData(QSqlQuery &sqlquery, FolderItem *parent) const;

    // parent contains the current data in the model (parentModelIndex is its index), updated contains fresh info loaded from the DB,
    void takeUpdatedChildrenInfo(FolderItem *parent, const QModelIndex &parentModelIndex, FolderItem *updated);

    Folder folderFromItem(FolderItem *item) const;

    FolderItem *rootItem; // items tree
    QMap<unsigned long long int, FolderItem *> items; // items lookup

    QString _databasePath;

    QIcon folderIcon;
    QIcon folderFinishedIcon;

    bool showRecent;
    qlonglong recentDays;
    QHash<qulonglong, qulonglong> coverRevisions;

protected:
    void applyTheme(const Theme &theme) override;
};

#endif
