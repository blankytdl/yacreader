#include "folder_model.h"

#include "data_base_management.h"
#include "db_helper.h"
#include "folder.h"
#include "folder_item.h"
#include "folder_sort.h"
#include "qnaturalsorting.h"
#include "yacreader_global.h"

#include <QDir>
#include <QFileIconProvider>
#include <QPainter>
#include <QSqlError>
#include <QSqlRecord>

#include <algorithm>

using namespace YACReader;

QIcon drawFinishedFolderIcon(const QPixmap &overlay)
{
    QIcon finishedIcon;
    QIcon ico = QFileIconProvider().icon(QFileIconProvider::Folder);
    QPixmap pixNormalOff = ico.pixmap(16, 16, QIcon::Normal, QIcon::Off);
    QPixmap pixNormalOn = ico.pixmap(16, 16, QIcon::Normal, QIcon::On);
    QPixmap pixSelectedOff = ico.pixmap(16, 16, QIcon::Selected, QIcon::Off);
    QPixmap pixSelectedOn = ico.pixmap(16, 16, QIcon::Selected, QIcon::On);

    {
        QPainter p(&pixNormalOff);
        p.drawPixmap(4, 7, overlay);
    }
    finishedIcon.addPixmap(pixNormalOff, QIcon::Normal, QIcon::Off);

    {
        QPainter p(&pixNormalOn);
        p.drawPixmap(4, 7, overlay);
    }
    finishedIcon.addPixmap(pixNormalOn, QIcon::Normal, QIcon::On);

    {
        QPainter p(&pixSelectedOff);
        p.drawPixmap(4, 7, overlay);
    }
    finishedIcon.addPixmap(pixSelectedOff, QIcon::Selected, QIcon::Off);

    {
        QPainter p(&pixSelectedOn);
        p.drawPixmap(4, 7, overlay);
    }
    finishedIcon.addPixmap(pixSelectedOn, QIcon::Selected, QIcon::On);

    return finishedIcon;
}

struct FolderColumns {
    int name;
    int path;
    int finished;
    int completed;
    int id;
    int parentId;
    int numChildren;
    int firstChildHash;
    int customImage;
    int type;
    int added;
    int updated;

    FolderColumns(QSqlQuery &sqlquery)
    {
        auto record = sqlquery.record();

        name = record.indexOf("name");
        path = record.indexOf("path");
        finished = record.indexOf("finished");
        completed = record.indexOf("completed");
        id = record.indexOf("id");
        parentId = record.indexOf("parentId");
        numChildren = record.indexOf("numChildren");
        firstChildHash = record.indexOf("firstChildHash");
        customImage = record.indexOf("customImage");
        type = record.indexOf("type");
        added = record.indexOf("added");
        updated = record.indexOf("updated");
    }
};

QList<QVariant> folderDataFromQuery(QSqlQuery &query, const FolderColumns &columns)
{
    QList<QVariant> data;

    data << query.value(columns.name);
    data << query.value(columns.path);
    data << query.value(columns.finished);
    data << query.value(columns.completed);
    data << query.value(columns.numChildren);
    data << query.value(columns.firstChildHash);
    data << query.value(columns.customImage);
    data << query.value(columns.type);
    data << query.value(columns.added);
    data << query.value(columns.updated);

    return data;
}

// TODO: load from DB, type is pretty much needed
FolderItem *createRoot(QSqlDatabase &db)
{
    QList<QVariant> data;

    QSqlQuery selectQuery(db);
    selectQuery.prepare("SELECT * FROM folder WHERE id = 1");
    selectQuery.exec();

    auto columns = FolderColumns(selectQuery);

    if (!selectQuery.next()) {
        return nullptr;
    }

    data = folderDataFromQuery(selectQuery, columns);
    data[0] = "root";

    auto root = new FolderItem(data);
    root->id = FolderModel::RootFolderId;
    root->parentItem = nullptr;

    return root;
}

FolderModel::FolderModel(QObject *parent)
    : QAbstractItemModel(parent), rootItem(nullptr), showRecent(false), recentDays(1)
{
    initTheme(this);
}

void FolderModel::applyTheme(const Theme &theme)
{
    const auto &sidebarIcons = theme.sidebarIcons;

    if (sidebarIcons.useSystemFolderIcons) {
        folderIcon = QFileIconProvider().icon(QFileIconProvider::Folder);
        folderFinishedIcon = drawFinishedFolderIcon(sidebarIcons.folderReadOverlay);
    } else {
        folderIcon = theme.navigationTree.folderIcon;
        folderFinishedIcon = theme.navigationTree.folderFinishedIcon;
    }
}

FolderModel::~FolderModel()
{
    if (rootItem != nullptr)
        delete rootItem;
}

int FolderModel::columnCount(const QModelIndex &parent) const
{
    if (parent.isValid())
        return static_cast<FolderItem *>(parent.internalPointer())->columnCount();
    else {
        if (rootItem == nullptr) {
            return 0;
        }
        return 1;
    }
}

QHash<int, QByteArray> FolderModel::roleNames() const
{
    QHash<int, QByteArray> roles;

    roles[FinishedRole] = "is_finished";
    roles[CompletedRole] = "is_completed";
    roles[IdRole] = "id";
    roles[CoverPathRole] = "cover_path";
    roles[FolderNameRole] = "name";
    roles[NumChildrenRole] = "num_children";
    roles[TypeRole] = "type";
    roles[AddedRole] = "added";
    roles[UpdatedRole] = "updated";
    roles[ShowRecentRole] = "show_recent";
    roles[RecentRangeRole] = "recent_range";

    return roles;
}

void FolderModel::reload()
{
    if (rootItem == nullptr)
        return;

    auto newModelData = createModelData(_databasePath);

    takeUpdatedChildrenInfo(rootItem, QModelIndex(), newModelData.rootItem);

    // copy items from newModelData to this model that are not in this model
    const auto newItemKeys = newModelData.items.keys();
    for (const auto key : newItemKeys) {
        if (!items.contains(key)) {
            items[key] = (newModelData.items[key]);
        }
    }

    delete newModelData.rootItem;
}

void FolderModel::takeUpdatedChildrenInfo(FolderItem *parent, const QModelIndex &parentModelIndex, FolderItem *updated)
{
    auto currentChildren = parent->children();
    auto updatedChildren = updated->children();

    int lenght = currentChildren.size();
    int lenghtUpdated = updatedChildren.size();

    int m; // index that reflects modifications on the actual model for this parent
    int i; // index of the original children before update
    int j; // index of the updated children
    for (m = 0, i = 0, j = 0; (i < lenght) && (j < lenghtUpdated);) {
        auto child = currentChildren[i];
        auto updatedChild = updatedChildren[j];

        // same folder
        auto sameFolderId = child->id == updatedChild->id; // and also same name
        if (sameFolderId) {
            // 1. check if child data needs to be udpated
            if (child->getData() != updatedChild->getData()) {
                auto modelIndexToUpdate = index(m, 0, parentModelIndex);

                child->setData(updatedChild->getData());

                emit dataChanged(modelIndexToUpdate, modelIndexToUpdate);
            }

            // 2. update children info
            takeUpdatedChildrenInfo(child, index(m, 0, parentModelIndex), updatedChild);

            m++;
            i++;
            j++;
            continue;
        }

        auto childName = child->data(Name).toString();
        auto childUpdatedName = updatedChild->data(Name).toString();

        // folder added
        if (!naturalSortLessThanCI(childName, childUpdatedName)) {
            beginInsertRows(parentModelIndex, m, m);

            parent->addChild(updatedChild, m);
            updated->removeChild(updatedChild);

            endInsertRows();

            m++;
            j++;
            continue;
        }

        // folder removed
        if (naturalSortLessThanCI(childName, childUpdatedName)) {
            beginRemoveRows(parentModelIndex, m, m);

            delete parent->child(m);
            parent->removeChild(m);

            endRemoveRows();

            i++;
            continue;
        }
    }

    // add remaining children
    for (; j < lenghtUpdated; j++) {
        auto updatedChild = updatedChildren[j];

        beginInsertRows(parentModelIndex, m, m);

        parent->addChild(updatedChild, m);
        updated->removeChild(updatedChild);

        endInsertRows();

        m++;
    }

    // remove remaining children
    for (; i < lenght; i++) {
        beginRemoveRows(parentModelIndex, m, m);

        delete parent->child(m);
        parent->removeChild(m);

        endRemoveRows();
    }
}

Folder FolderModel::folderFromItem(FolderItem *folderItem) const
{
    auto name = folderItem->data(FolderModel::Name).toString();
    auto parentItem = folderItem->parent();

    QString path;
    if (parentItem == nullptr) {
        parentItem = rootItem;
        path = "/";
    } else {
        path = parentItem->data(Columns::Path).toString() + "/" + name;
    }

    auto folder = Folder(folderItem->id,
                         parentItem->id,
                         name,
                         path,
                         folderItem->data(Columns::Completed).toBool(),
                         folderItem->data(Columns::Finished).toBool(),
                         folderItem->data(Columns::NumChildren).toInt(),
                         folderItem->data(Columns::FirstChildHash).toString(),
                         folderItem->data(Columns::CustomImage).toString(),
                         folderItem->data(Columns::Type).value<YACReader::FileType>(),
                         folderItem->data(Columns::Added).toLongLong(),
                         folderItem->data(Columns::Updated).toLongLong());

    return folder;
}

void FolderModel::reload(const QModelIndex &index)
{
    // TODO: reload just the content under index for better efficiency
    reload();
}

QVariant FolderModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid())
        return QVariant();

    auto item = static_cast<FolderItem *>(index.internalPointer());

    if (role == Qt::ToolTipRole) {
        QString toolTip = item->data(FolderModel::Name).toString();
        int totalNumOfChildren = item->childCount() + item->comicNames.size();
        if (totalNumOfChildren > 0) {
            toolTip = toolTip + " - " + QString::number(totalNumOfChildren);
        }

        return toolTip;
    }

    if (role == Qt::DecorationRole) {
        if (item->data(FolderModel::Finished).toBool())
            return QVariant(folderFinishedIcon);
        else
            return QVariant(folderIcon);
    }

    if (role == FolderModel::FolderNameRole) {
        return item->data(FolderModel::Name);
    }

    if (role == FolderModel::CompletedRole)
        return item->data(FolderModel::Completed);

    if (role == FolderModel::FinishedRole)
        return item->data(FolderModel::Finished);

    if (role == FolderModel::IdRole)
        return item->id;

    if (role == FolderModel::CoverPathRole) {
        if (item->data(FolderModel::CustomImage).toString().isEmpty())
            return getCoverUrlPathForComicHash(item->data(FirstChildHash).toString());
        else
            return getCoverUrlPathForFolderId(item->id);
    }

    if (role == FolderModel::NumChildrenRole)
        return item->data(NumChildren);

    if (role == FolderModel::TypeRole)
        return item->data(Type);

    if (role == FolderModel::AddedRole)
        return item->data(Added);

    if (role == FolderModel::UpdatedRole)
        return item->data(Updated);

    if (role == FolderModel::ShowRecentRole)
        return showRecent;

    if (role == FolderModel::RecentRangeRole)
        return recentDays * 86400;

    if (role != Qt::DisplayRole)
        return QVariant();

    return item->data(index.column());
}

Qt::ItemFlags FolderModel::flags(const QModelIndex &index) const
{
    if (!index.isValid())
        return { };

    return Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsDropEnabled | Qt::ItemIsDragEnabled;
}

QVariant FolderModel::headerData(int section,
                                 Qt::Orientation orientation,
                                 int role) const
{
    if (rootItem == nullptr) {
        return QVariant();
    }

    if (orientation == Qt::Horizontal && role == Qt::DisplayRole)
        return rootItem->data(section);

    return QVariant();
}

QModelIndex FolderModel::index(int row, int column, const QModelIndex &parent)
        const
{
    if (!hasIndex(row, column, parent))
        return QModelIndex();

    FolderItem *parentItem;

    if (!parent.isValid())
        parentItem = rootItem;
    else
        parentItem = static_cast<FolderItem *>(parent.internalPointer());

    FolderItem *childItem = parentItem->child(row);
    if (childItem)
        return createIndex(row, column, childItem);
    else
        return QModelIndex();
}

QModelIndex FolderModel::index(qulonglong folderId) const
{
    QModelIndex index;
    YACReader::iterate(QModelIndex(), this, [&](const QModelIndex &idx) {
        if (index.isValid()) {
            return false;
        }

        auto item = static_cast<FolderItem *>(idx.internalPointer());
        if (item->id == folderId) {
            index = idx;
            return false;
        }

        return true;
    });

    return index;
}

QModelIndex FolderModel::parent(const QModelIndex &index) const
{
    if (!index.isValid())
        return QModelIndex();

    auto childItem = static_cast<FolderItem *>(index.internalPointer());
    FolderItem *parentItem = childItem->parent();

    if (parentItem == rootItem)
        return QModelIndex();

    return createIndex(parentItem->row(), 0, parentItem);
}

int FolderModel::rowCount(const QModelIndex &parent) const
{
    FolderItem *parentItem;
    if (parent.column() > 0)
        return 0;

    if (!parent.isValid()) {
        if (rootItem == nullptr) {
            return 0;
        }
        parentItem = rootItem;
    } else {
        parentItem = static_cast<FolderItem *>(parent.internalPointer());
    }

    return parentItem->childCount();
}

void FolderModel::setupModelData(QString path)
{
    beginResetModel();

    if (rootItem != nullptr)
        delete rootItem; // TODO comprobar que se libera bien la memoria

    rootItem = nullptr;
    _databasePath = path;

    setModelData(createModelData(path));

    endResetModel();
}

void FolderModel::setModelData(const ModelData &modelData)
{
    rootItem = modelData.rootItem;
    items = modelData.items;
}

FolderModel::ModelData FolderModel::createModelData(const QString &path) const
{
    ModelData modelData;

    QString connectionName = "";
    {
        QSqlDatabase db = DataBaseManagement::loadDatabase(path);
        QSqlQuery selectQuery("select * from folder where id <> 1 order by parentId,name", db);

        auto root = createRoot(db);
        modelData = createModelData(selectQuery, root);

        connectionName = db.connectionName();
    }
    QSqlDatabase::removeDatabase(connectionName);

    return modelData;
}

FolderModel::ModelData FolderModel::createModelData(QSqlQuery &sqlquery, FolderItem *parent) const
{
    QMap<unsigned long long int, FolderItem *> itemsLookup;

    // add parent to the lookup
    itemsLookup.insert(parent->id, parent);

    auto columns = FolderColumns(sqlquery);

    while (sqlquery.next()) {
        auto item = new FolderItem(folderDataFromQuery(sqlquery, columns));

        item->id = sqlquery.value(columns.id).toULongLong();
        // la inserci�n de hijos se hace de forma ordenada
        FolderItem *parent = itemsLookup.value(sqlquery.value(columns.parentId).toULongLong());
        parent->appendChild(item);
        // se a�ade el item al map, de forma que se pueda encontrar como padre en siguientes iteraciones
        itemsLookup.insert(item->id, item);
    }

    return FolderModel::ModelData { parent, itemsLookup };
}

QString FolderModel::getDatabase()
{
    return _databasePath;
}

QString FolderModel::getFolderPath(const QModelIndex &folder)
{
    if (!folder.isValid()) // root folder
        return "/";
    return static_cast<FolderItem *>(folder.internalPointer())->data(FolderModel::Path).toString();
}

void FolderModel::updateFolderCompletedStatus(const QModelIndexList &list, bool status)
{
    if (list.isEmpty())
        return;

    QString connectionName = "";
    {
        QSqlDatabase db = DataBaseManagement::loadDatabase(_databasePath);
        db.transaction();
        for (const auto &mi : list) {
            auto item = static_cast<FolderItem *>(mi.internalPointer());
            item->setData(FolderModel::Completed, status);

            Folder f = DBHelper::loadFolder(item->id, db);
            f.completed = status;
            DBHelper::update(f, db);
        }
        db.commit();
        connectionName = db.connectionName();
    }
    QSqlDatabase::removeDatabase(connectionName);

    const auto parent = list.first().parent();
    emit dataChanged(index(list.first().row(), FolderModel::Name, parent), index(list.last().row(), FolderModel::Updated, parent));
}

void FolderModel::updateFolderFinishedStatus(const QModelIndexList &list, bool status)
{
    if (list.isEmpty())
        return;

    QString connectionName = "";
    {
        QSqlDatabase db = DataBaseManagement::loadDatabase(_databasePath);
        db.transaction();
        for (const auto &mi : list) {
            auto item = static_cast<FolderItem *>(mi.internalPointer());
            item->setData(FolderModel::Finished, status);

            Folder f = DBHelper::loadFolder(item->id, db);
            f.finished = status;
            DBHelper::update(f, db);
        }
        db.commit();
        connectionName = db.connectionName();
    }
    QSqlDatabase::removeDatabase(connectionName);

    const auto parent = list.first().parent();
    emit dataChanged(index(list.first().row(), FolderModel::Name, parent), index(list.last().row(), FolderModel::Updated, parent));
}

void FolderModel::updateFolderType(const QModelIndexList &list, YACReader::FileType type)
{
    if (list.isEmpty())
        return;

    QString connectionName = "";
    {
        QSqlDatabase db = DataBaseManagement::loadDatabase(_databasePath);
        db.transaction();
        for (const auto &mi : list) {
            auto item = static_cast<FolderItem *>(mi.internalPointer());

            std::function<void(FolderItem *, YACReader::FileType)> setType;
            setType = [&setType](FolderItem *item, YACReader::FileType type) -> void {
                item->setData(FolderModel::Type, QVariant::fromValue(type));

                const auto children = item->children();
                for (auto child : children) {
                    setType(child, type);
                }
            };

            setType(item, type);

            DBHelper::updateFolderTreeType(item->id, db, type);
        }
        db.commit();
        connectionName = db.connectionName();
    }
    QSqlDatabase::removeDatabase(connectionName);

    const auto parent = list.first().parent();
    emit dataChanged(index(list.first().row(), FolderModel::Name, parent), index(list.last().row(), FolderModel::Updated, parent));
}

bool FolderModel::renameFolder(const QModelIndex &folder, const QString &name, QString *error)
{
    if (!folder.isValid())
        return false;

    auto item = static_cast<FolderItem *>(folder.internalPointer());
    const auto oldPath = item->data(FolderModel::Path).toString();
    const auto parentPath = item->parent()->data(FolderModel::Path).toString();
    const auto newPath = QDir::cleanPath(parentPath + "/" + name);

    QString connectionName;
    bool success = false;
    {
        QSqlDatabase db = DataBaseManagement::loadDatabase(_databasePath);
        connectionName = db.connectionName();

        if (!db.isValid() || !db.isOpen()) {
            if (error != nullptr)
                *error = db.lastError().text();
        } else if (!db.transaction()) {
            if (error != nullptr)
                *error = db.lastError().text();
        } else if (!DBHelper::renameFolder(item->id, name, oldPath, newPath, db, error)) {
            db.rollback();
        } else if (!db.commit()) {
            if (error != nullptr)
                *error = db.lastError().text();
            db.rollback();
        } else {
            success = true;
        }
    }
    QSqlDatabase::removeDatabase(connectionName);

    if (!success)
        return false;

    item->setData(FolderModel::Name, name);

    const auto updatePath = [&oldPath, &newPath](auto &&self, FolderItem *folderItem) -> void {
        const auto path = folderItem->data(FolderModel::Path).toString();
        folderItem->setData(FolderModel::Path, newPath + path.mid(oldPath.size()));
        const auto children = folderItem->children();
        for (auto child : children)
            self(self, child);
    };
    updatePath(updatePath, item);

    auto parentItem = item->parent();
    const auto oldRow = item->row();
    auto newRow = 0;
    const auto siblings = parentItem->children();
    for (auto sibling : siblings) {
        if (sibling != item && !naturalSortLessThanCI(name, sibling->data(FolderModel::Name).toString()))
            ++newRow;
    }

    if (newRow != oldRow) {
        const auto destination = newRow > oldRow ? newRow + 1 : newRow;
        beginMoveRows(folder.parent(), oldRow, oldRow, folder.parent(), destination);
        parentItem->removeChild(item);
        parentItem->appendChild(item);
        endMoveRows();
    }

    const auto renamedIndex = index(item->row(), FolderModel::Name, folder.parent());
    emit dataChanged(renamedIndex, index(item->row(), FolderModel::Path, folder.parent()));
    return true;
}

void FolderModel::updateTreeType(YACReader::FileType type)
{
    QString connectionName = "";
    {
        QSqlDatabase db = DataBaseManagement::loadDatabase(_databasePath);
        db.transaction();

        auto item = rootItem;

        std::function<void(FolderItem *, YACReader::FileType)> setType;
        setType = [&setType](FolderItem *item, YACReader::FileType type) -> void {
            item->setData(FolderModel::Type, QVariant::fromValue(type));

            const auto children = item->children();
            for (auto child : children) {
                setType(child, type);
            }
        };

        setType(item, type);

        DBHelper::updateDBType(db, type);
        db.commit();
        connectionName = db.connectionName();
    }
    QSqlDatabase::removeDatabase(connectionName);
}

void FolderModel::setCustomFolderCover(const QModelIndex &index, const QString &path)
{
    QString connectionName = "";
    {
        QSqlDatabase db = DataBaseManagement::loadDatabase(_databasePath);
        db.transaction();

        auto item = static_cast<FolderItem *>(index.internalPointer());
        item->setData(FolderModel::CustomImage, path);

        Folder f = DBHelper::loadFolder(item->id, db);
        f.customImage = path;
        DBHelper::update(f, db);

        db.commit();
        connectionName = db.connectionName();
    }
    QSqlDatabase::removeDatabase(connectionName);

    ++coverRevisions[index.data(FolderModel::IdRole).toULongLong()];
    emit dataChanged(index, index, { CoverPathRole });
}

void FolderModel::resetFolderCover(const QModelIndex &index)
{
    QString connectionName = "";
    {
        QSqlDatabase db = DataBaseManagement::loadDatabase(_databasePath);
        db.transaction();

        auto item = static_cast<FolderItem *>(index.internalPointer());
        item->setData(FolderModel::CustomImage, "");

        Folder f = DBHelper::loadFolder(item->id, db);
        f.customImage = "";
        DBHelper::update(f, db);

        db.commit();
        connectionName = db.connectionName();
    }
    QSqlDatabase::removeDatabase(connectionName);

    emit dataChanged(index, index);
}

Folder FolderModel::getRootFolder() const
{
    if (this->rootItem == nullptr) {
        return Folder();
    }

    return folderFromItem(this->rootItem);
}

Folder FolderModel::getFolder(const QModelIndex &mi) const
{
    if (!mi.isValid()) {
        return Folder();
    }

    auto folderItem = static_cast<FolderItem *>(mi.internalPointer());
    return folderFromItem(folderItem);
}

QModelIndex FolderModel::getIndexFromFolderId(qulonglong folderId, const QModelIndex &parent)
{
    if (rootItem == nullptr) {
        return QModelIndex();
    }

    auto numRows = rowCount(parent);
    for (auto i = 0; i < numRows; i++) {
        auto modelIndex = index(i, 0, parent);

        if (modelIndex.isValid()) {
            auto folderItem = static_cast<FolderItem *>(modelIndex.internalPointer());

            if (folderItem->id == folderId) {
                return modelIndex;
            }

            auto childModelIndex = getIndexFromFolderId(folderId, modelIndex);

            if (childModelIndex.isValid()) {
                auto folderItem = static_cast<FolderItem *>(childModelIndex.internalPointer());

                if (folderItem->id == folderId) {
                    return childModelIndex;
                }
            }
        }
    }

    return QModelIndex();
}

QModelIndex FolderModel::getIndexFromFolder(const Folder &folder, const QModelIndex &parent)
{
    return getIndexFromFolderId(folder.id, parent);
}

QModelIndex FolderModel::addFolderAtParent(const QString &folderName, const QModelIndex &parent)
{
    FolderItem *parentItem;

    if (parent.isValid())
        parentItem = static_cast<FolderItem *>(parent.internalPointer());
    else
        parentItem = rootItem;

    Folder newFolder;
    newFolder.name = folderName;
    newFolder.parentId = parentItem->id;
    newFolder.path = parentItem->data(Columns::Path).toString() + "/" + folderName;
    newFolder.type = parentItem->data(Columns::Type).value<YACReader::FileType>();

    QString connectionName = "";
    {
        QSqlDatabase db = DataBaseManagement::loadDatabase(_databasePath);
        newFolder.id = DBHelper::insert(&newFolder, db);
        DBHelper::updateChildrenInfo(parentItem->id, db);
        connectionName = db.connectionName();
    }
    QSqlDatabase::removeDatabase(connectionName);

    int destRow = 0;

    QList<QVariant> data;
    data << newFolder.name;
    data << newFolder.path;
    data << false; // finished
    data << true; // completed
    data << 0; // numChildren
    data << QVariant(); // first child hash, new folder is empty
    data << QVariant(); // custom cover
    data << QVariant::fromValue(newFolder.type);
    data << newFolder.added;
    data << newFolder.updated;

    auto item = new FolderItem(data);
    item->id = newFolder.id;

    beginInsertRows(parent, 0, 0); // TODO calculate the destRow before inserting the new child

    parentItem->appendChild(item);
    destRow = parentItem->children().indexOf(item); // TODO optimize this, appendChild should return the index of the new item
    items.insert(item->id, item);

    endInsertRows();

    return index(destRow, 0, parent);
}

QUrl FolderModel::getCoverUrlPathForComicHash(const QString &hash) const
{
    auto coverPath = LibraryPaths::coverPathFromLibraryDataPath(_databasePath, hash);
    return QUrl::fromLocalFile(coverPath);
}

QUrl FolderModel::getCoverUrlPathForFolderId(qulonglong folderId) const
{
    auto coverPath = LibraryPaths::customFolderCoverPathFromDataPath(_databasePath, QString::number(folderId));
    auto coverUrl = QUrl::fromLocalFile(coverPath);
    const auto revision = coverRevisions.value(folderId);
    if (revision > 0)
        coverUrl.setQuery(QStringLiteral("revision=%1").arg(revision));
    return coverUrl;
}

void FolderModel::setShowRecent(bool showRecent)
{
    if (this->showRecent == showRecent)
        return;

    this->showRecent = showRecent;

    emitDataChangedRecursively({ }, FolderModel::ShowRecentRole);
}

void FolderModel::setRecentRange(int days)
{
    if (this->recentDays == days)
        return;

    this->recentDays = days;

    emitDataChangedRecursively({ }, FolderModel::RecentRangeRole);
}

void FolderModel::emitDataChangedRecursively(const QModelIndex &parent, int role)
{
    const auto rows = rowCount(parent);
    if (rows == 0)
        return;

    emit dataChanged(index(0, 0, parent), index(rows - 1, 0, parent), { role });
    for (int row = 0; row < rows; ++row)
        emitDataChangedRecursively(index(row, 0, parent), role);
}

void FolderModel::deleteFolder(const QModelIndex &mi)
{
    beginRemoveRows(mi.parent(), mi.row(), mi.row());

    auto item = static_cast<FolderItem *>(mi.internalPointer());

    FolderItem *parent = item->parent();
    parent->removeChild(mi.row());

    Folder f;
    f.setId(item->id);

    QString connectionName = "";
    {
        QSqlDatabase db = DataBaseManagement::loadDatabase(_databasePath);
        DBHelper::removeFromDB(&f, db);
        auto folder = DBHelper::updateChildrenInfo(item->parent()->id, db);
        DBHelper::propagateFolderUpdatesToParent(folder, db);
        connectionName = db.connectionName();
    }
    QSqlDatabase::removeDatabase(connectionName);

    endRemoveRows();
}

void FolderModel::updateFolderChildrenInfo(qulonglong folderId)
{
    QString connectionName = "";
    {
        QSqlDatabase db = DataBaseManagement::loadDatabase(_databasePath);
        auto folder = DBHelper::updateChildrenInfo(folderId, db);
        DBHelper::propagateFolderUpdatesToParent(folder, db);
        connectionName = db.connectionName();
    }
    QSqlDatabase::removeDatabase(connectionName);
}

// PROXY

FolderModelProxy::FolderModelProxy(QObject *parent)
    : QSortFilterProxyModel(parent), rootItem(0), filterEnabled(false)
{
}

FolderModelProxy::~FolderModelProxy()
{
}

bool FolderModelProxy::filterAcceptsRow(int source_row, const QModelIndex &source_parent) const
{
    if (!filterEnabled)
        return true;

    auto parent = static_cast<FolderItem *>(source_parent.internalPointer());

    if (parent == 0)
        parent = static_cast<FolderModel *>(sourceModel())->rootItem;

    FolderItem *item = parent->children().at(source_row);

    return filteredItems.contains(item->id);
}

void FolderModelProxy::setFilterData(QMap<unsigned long long, FolderItem *> *filteredItems, FolderItem *root)
{
    clear();
    filterEnabled = true;

    beginResetModel();

    if (rootItem != 0)
        delete rootItem; // TODO comprobar que se libera bien la memoria

    rootItem = root;

    this->filteredItems.insert(*filteredItems);

    endResetModel();

    delete filteredItems;
}

void FolderModelProxy::clear()
{
    filterEnabled = false;

    filteredItems.clear();

    QSortFilterProxyModel::invalidate();
}

void FolderModelProxy::setFolderSort(int comicSortKey, Qt::SortOrder order)
{
    folderSortKey = comicSortKey;

    if (YACReader::folderSortIsDefault(static_cast<ComicModel::SortKey>(comicSortKey), order)) {
        sort(-1); // keep the order of the source model
    } else {
        sort(0, order);
    }

    // sort() does nothing when only the criteria changed
    invalidate();
}

bool FolderModelProxy::lessThan(const QModelIndex &left, const QModelIndex &right) const
{
    return YACReader::folderLessThan(left, right, static_cast<ComicModel::SortKey>(folderSortKey));
}
