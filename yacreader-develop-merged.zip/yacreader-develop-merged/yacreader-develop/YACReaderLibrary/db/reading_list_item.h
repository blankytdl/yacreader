#ifndef READING_LIST_ITEM_H
#define READING_LIST_ITEM_H

#include "reading_list_model.h"

#include <QIcon>
#include <QVariant>
// TODO add propper constructors, using QList<QVariant> is not safe

class ListItem
{
public:
    ListItem(const QList<QVariant> &data);
    int columnCount();
    virtual QIcon getIcon() const = 0;
    QVariant data(int column) const;
    virtual qulonglong getId() const;
    QList<QVariant> itemData;
    virtual ~ListItem() { }
};

//------------------------------------------------------

class SpecialListItem : public ListItem
{
public:
    SpecialListItem(const QList<QVariant> &data);
    QIcon getIcon() const override;
    qulonglong getId() const override;
    ReadingListModel::TypeSpecialList getType() const;

private:
    enum DataIndexes {
        Name,
        Id
    };
};

//------------------------------------------------------

class LabelItem : public ListItem
{
public:
    LabelItem(const QList<QVariant> &data);
    QIcon getIcon() const override;
    YACReader::LabelColors colorid() const;
    QString name() const;
    void setName(const QString &name);
    qulonglong getId() const override;

private:
    enum DataIndexes {
        Name,
        Color,
        Id,
        Ordering
    };
};

//------------------------------------------------------

class ReadingListItem : public ListItem
{
public:
    ReadingListItem(const QList<QVariant> &data, ReadingListItem *parent = nullptr);
    QIcon getIcon() const override;
    ReadingListItem *parent;
    int childCount() const;
    int row() const;
    ReadingListItem *child(int row);
    void appendChild(ReadingListItem *item);
    void appendChild(ReadingListItem *item, int pos);
    void removeChild(ReadingListItem *item);
    qulonglong getId() const override;
    QString name() const;
    void setName(const QString &name);
    int getOrdering() const;
    void setOrdering(const int ordering);
    QList<ReadingListItem *> children();

private:
    QList<ReadingListItem *> childItems;

    enum DataIndexes {
        Name,
        Id,
        Finished,
        Completed,
        Ordering
    };
};

//------------------------------------------------------

class ReadingListSeparatorItem : public ListItem
{
public:
    ReadingListSeparatorItem();
    QIcon getIcon() const override;
};

#endif // READING_LIST_ITEM_H
