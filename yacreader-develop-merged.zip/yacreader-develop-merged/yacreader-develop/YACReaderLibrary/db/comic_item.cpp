
#include "comic_item.h"

#include <QStringList>

//! [0]
ComicItem::ComicItem(const QList<QVariant> &data)

{
    itemData = data;
}
//! [0]

//! [1]
ComicItem::~ComicItem()
{
}
//! [1]

//! [5]
int ComicItem::columnCount() const
{
    return itemData.count();
}

QList<QVariant> ComicItem::getData() const
{
    return itemData;
}

void ComicItem::setData(const QList<QVariant> &data)
{
    itemData = data;
}
//! [5]

//! [6]
QVariant ComicItem::data(int column) const
{
    return itemData.value(column);
}
//! [6]

void ComicItem::setData(int column, const QVariant &value)
{
    itemData[column] = value;
}

//! [8]
int ComicItem::row() const
{

    return 0;
}
//! [8]
