#ifndef FOLDER_SORT_H
#define FOLDER_SORT_H

#include "comic_model.h"
#include "folder_model.h"
#include "qnaturalsorting.h"

#include <QModelIndex>

namespace YACReader {

// Folders follow the sort chosen for the comics:
//   file name                         -> folder name
//   size / number of pages            -> number of items inside the folder
//   date added                        -> date the folder was added
//   last read / publication date      -> date the folder was last updated
// The default (name, ascending) keeps the order of the folder model.
inline bool folderSortIsDefault(ComicModel::SortKey key, Qt::SortOrder order)
{
    return key == ComicModel::SortDefault && order == Qt::AscendingOrder;
}

// `left` and `right` are indexes of a FolderModel. Returns true if `left` goes before `right` in ascending order.
inline bool folderLessThan(const QModelIndex &left, const QModelIndex &right, ComicModel::SortKey key)
{
    int role = -1;

    switch (key) {
    case ComicModel::SortSize:
    case ComicModel::SortPages:
        role = FolderModel::NumChildrenRole;
        break;
    case ComicModel::SortDateAdded:
        role = FolderModel::AddedRole;
        break;
    case ComicModel::SortLastRead:
    case ComicModel::SortPublicationDate:
        role = FolderModel::UpdatedRole;
        break;
    case ComicModel::SortDefault:
    case ComicModel::SortFileName:
        break;
    }

    if (role != -1) {
        const auto leftValue = left.data(role).toLongLong();
        const auto rightValue = right.data(role).toLongLong();
        if (leftValue != rightValue) {
            return leftValue < rightValue;
        }
    }

    return naturalSortLessThanCI(left.data(FolderModel::FolderNameRole).toString(), right.data(FolderModel::FolderNameRole).toString());
}

}

#endif // FOLDER_SORT_H
