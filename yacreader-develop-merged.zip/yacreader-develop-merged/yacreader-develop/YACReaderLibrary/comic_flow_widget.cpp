#include "comic_flow_widget.h"

#include "comics_view.h"
#include "cover_utils.h"

#include <QContextMenuEvent>
#include <QCoreApplication>
#include <QDragEnterEvent>
#include <QDropEvent>
#include <QMimeData>
#include <QVBoxLayout>

namespace {
bool canDropCustomCover(const QMimeData *mimeData)
{
    return mimeData->hasUrls() && !YACReader::droppedImagePath(mimeData->urls()).isEmpty();
}

// The comics view that imports the drops that are not a custom cover
ComicsView *importTarget(const QWidget *widget)
{
    for (QWidget *parent = widget->parentWidget(); parent != nullptr; parent = parent->parentWidget()) {
        if (auto *comicsView = qobject_cast<ComicsView *>(parent))
            return comicsView;
    }
    return nullptr;
}
} // namespace

ComicFlowWidget::ComicFlowWidget(QWidget *parent)
    : QWidget(parent)
{
    // The flow renders into its own native window. A render-to-texture widget would make
    // Qt compose the whole library window through RHI, which is slow on large screens.
    flow = new YACReaderComicFlow3D();
    flowContainer = QWidget::createWindowContainer(flow, this);
    flowContainer->setFocusPolicy(Qt::StrongFocus);
    setFocusProxy(flowContainer);
    // Events that the native window does not use do not propagate to the widgets.
    flow->installEventFilter(this);

    connect(flow, &YACReaderComicFlow3D::centerIndexChanged, this, &ComicFlowWidget::centerIndexChanged);
    connect(flow, &YACReaderComicFlow3D::selected, this, &ComicFlowWidget::selected);

    auto l = new QVBoxLayout;
    l->addWidget(flowContainer);
    l->setContentsMargins(0, 0, 0, 0);
    setLayout(l);

    setAutoFillBackground(true);
    setAcceptDrops(true);

    initTheme(this);
}

void ComicFlowWidget::applyTheme(const Theme &theme)
{
    setBackgroundColor(theme.comicFlow.backgroundColor);
    setTextColor(theme.comicFlow.textColor);
    flow->setRibbonImages(theme.comicFlow.readPixmap.toImage(), theme.comicFlow.readingPixmap.toImage());
}

void ComicFlowWidget::setBackgroundColor(const QColor &color)
{
    flow->setBackgroundColor(color);
}

void ComicFlowWidget::setTextColor(const QColor &color)
{
    flow->setTextColor(color);
}

QSize ComicFlowWidget::minimumSizeHint() const
{
    return QSize(320, 200);
}

QSize ComicFlowWidget::sizeHint() const
{
    // No preferred size, the same as the former QRhiWidget flow
    return QSize();
}

void ComicFlowWidget::setShowMarks(bool value)
{
    flow->setShowMarks(value);
}

void ComicFlowWidget::setMarks(QVector<YACReader::YACReaderComicReadStatus> marks)
{
    flow->setMarks(marks);
}

void ComicFlowWidget::setMarkImage(QImage &image)
{
    flow->setMarkImage(image);
}

void ComicFlowWidget::markSlide(int index, YACReader::YACReaderComicReadStatus status)
{
    flow->markSlide(index, status);
}

void ComicFlowWidget::unmarkSlide(int index)
{
    flow->unmarkSlide(index);
}

void ComicFlowWidget::setSlideSize(QSize size)
{
    flow->setSlideSize(size);
}

void ComicFlowWidget::clear()
{
    flow->clear();
}

void ComicFlowWidget::setImagePaths(QStringList paths)
{
    flow->setImagePaths(paths);
}

void ComicFlowWidget::setCenterIndex(int index)
{
    flow->setCenterIndex(index);
}

void ComicFlowWidget::setCenterIndexWithoutAnimation(int index)
{
    flow->setCurrentIndexWithoutAnimation(index);
}

void ComicFlowWidget::showSlide(int index)
{
    flow->showSlide(index);
}

int ComicFlowWidget::centerIndex()
{
    return flow->centerIndex();
}

void ComicFlowWidget::updateMarks()
{
    flow->updateMarks();
}

void ComicFlowWidget::setFlowType(YACReader::FlowType flowType)
{
    if (flowType == YACReader::CoverFlowLike)
        flow->setPreset(presetYACReaderFlowClassicConfig);
    else if (flowType == YACReader::Strip)
        flow->setPreset(presetYACReaderFlowStripeConfig);
    else if (flowType == YACReader::StripOverlapped)
        flow->setPreset(presetYACReaderFlowOverlappedStripeConfig);
    else
        flow->setPreset(defaultYACReaderFlowConfig);
}

void ComicFlowWidget::render()
{
    flow->render();
}

void ComicFlowWidget::keyPressEvent(QKeyEvent *event)
{
    flow->keyPressEvent(event);
}

void ComicFlowWidget::paintEvent(QPaintEvent *event)
{
    QWidget::paintEvent(event);
}

void ComicFlowWidget::mousePressEvent(QMouseEvent *event)
{
    flow->mousePressEvent(event);
}

void ComicFlowWidget::resizeEvent(QResizeEvent *event)
{
    flow->resizeGL(event->size().width(), event->size().height());
}

void ComicFlowWidget::mouseDoubleClickEvent(QMouseEvent *event)
{
    flow->mouseDoubleClickEvent(event);
}

void ComicFlowWidget::dragEnterEvent(QDragEnterEvent *event)
{
    if (canDropCustomCover(event->mimeData())) {
        event->setDropAction(Qt::CopyAction);
        event->accept();
    }
}

void ComicFlowWidget::dropEvent(QDropEvent *event)
{
    const auto imagePath = event->mimeData()->hasUrls() ? YACReader::droppedImagePath(event->mimeData()->urls()) : QString();
    const auto index = centerIndex();
    if (imagePath.isEmpty() || index < 0) {
        event->ignore();
        return;
    }

    emit customCoverDropped(imagePath, index);
    event->setDropAction(Qt::CopyAction);
    event->accept();
}

bool ComicFlowWidget::eventFilter(QObject *watched, QEvent *event)
{
    if (watched != flow)
        return QWidget::eventFilter(watched, event);

    switch (event->type()) {
    case QEvent::MouseButtonPress:
        // Keep the widget focus in sync with the flow window, which activates itself on click
        if (!flowContainer->hasFocus())
            flowContainer->setFocus(Qt::MouseFocusReason);
        return false;
    case QEvent::KeyPress: {
        // Keys that the flow does not use go up the widget hierarchy, as they did from the widget flow
        auto *keyEvent = static_cast<QKeyEvent *>(event);
        flow->keyPressEvent(keyEvent);
        if (!keyEvent->isAccepted() && parentWidget() != nullptr) {
            keyEvent->accept();
            QCoreApplication::sendEvent(parentWidget(), keyEvent);
        }
        return true;
    }
    case QEvent::ContextMenu:
        if (contextMenuPolicy() == Qt::CustomContextMenu) {
            const auto *menuEvent = static_cast<QContextMenuEvent *>(event);
            emit customContextMenuRequested(flowContainer->mapTo(this, menuEvent->pos()));
            event->accept();
            return true;
        }
        return false;
    // Drags are custom covers for the flow, or comics that the parent comics view imports
    // (a widget flow propagated the drags that it did not accept to its parents).
    case QEvent::DragEnter:
    case QEvent::DragMove: {
        auto *dragEvent = static_cast<QDragMoveEvent *>(event);
        auto *comicsView = importTarget(this);
        if (canDropCustomCover(dragEvent->mimeData())) {
            dragEvent->setDropAction(Qt::CopyAction);
            dragEvent->accept();
        } else if (comicsView != nullptr && comicsView->canImportDrop(dragEvent)) {
            dragEvent->acceptProposedAction();
        } else {
            dragEvent->ignore();
        }
        return true;
    }
    case QEvent::Drop: {
        auto *dropEvent = static_cast<QDropEvent *>(event);
        auto *comicsView = importTarget(this);
        if (canDropCustomCover(dropEvent->mimeData()))
            this->dropEvent(dropEvent);
        else if (comicsView != nullptr && comicsView->canImportDrop(dropEvent))
            comicsView->importDrop(dropEvent);
        else
            dropEvent->ignore();
        return true;
    }
    default:
        return false;
    }
}

void ComicFlowWidget::updateConfig(QSettings *settings)
{
    Performance performance = medium;

    switch (settings->value(PERFORMANCE).toInt()) {
    case 0:
        performance = low;
        break;
    case 1:
        performance = medium;
        break;
    case 2:
        performance = high;
        break;
    case 3:
        performance = ultraHigh;
        break;
    }

    flow->setPerformance(performance);
    if (!settings->contains(V_SYNC))
        flow->useVSync(false);
    else
        flow->useVSync(settings->value(V_SYNC).toBool());

    switch (settings->value(FLOW_TYPE_GL).toInt()) {
    case 0:
        flow->setPreset(presetYACReaderFlowClassicConfig);
        return;
    case 1:
        flow->setPreset(presetYACReaderFlowStripeConfig);
        return;
    case 2:
        flow->setPreset(presetYACReaderFlowOverlappedStripeConfig);
        return;
    case 3:
        flow->setPreset(defaultYACReaderFlowConfig);
        return;
    case 4:
        flow->setPreset(pressetYACReaderFlowDownConfig);
        return;
    }

    // custom config
    flow->setCF_RX(settings->value(X_ROTATION).toInt());
    flow->setCF_Y(settings->value(Y_POSITION).toInt());
    flow->setX_Distance(settings->value(COVER_DISTANCE).toInt());
    flow->setCenter_Distance(settings->value(CENTRAL_DISTANCE).toInt());
    flow->setCF_Z(settings->value(ZOOM_LEVEL).toInt());
    flow->setY_Distance(settings->value(Y_COVER_OFFSET).toInt());
    flow->setZ_Distance(settings->value(Z_COVER_OFFSET).toInt());
    flow->setRotation(settings->value(COVER_ROTATION).toInt());
    flow->setFadeOutDist(settings->value(FADE_OUT_DIST).toInt());
    flow->setLightStrenght(settings->value(LIGHT_STRENGTH).toInt());
    flow->setMaxAngle(settings->value(MAX_ANGLE).toInt());
}

void ComicFlowWidget::add(const QString &path, int index)
{
    flow->add(path, index);
}

void ComicFlowWidget::remove(int cover)
{
    flow->remove(cover);
}

void ComicFlowWidget::resortCovers(QList<int> newOrder)
{
    flow->resortCovers(newOrder);
}
