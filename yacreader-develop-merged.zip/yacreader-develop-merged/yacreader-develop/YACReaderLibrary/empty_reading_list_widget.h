#ifndef EMPTY_READING_LIST_WIDGET_H
#define EMPTY_READING_LIST_WIDGET_H

#include "empty_container_info.h"

class EmptyReadingListWidget : public EmptyContainerInfo
{
public:
    EmptyReadingListWidget(QWidget *parent = nullptr);

protected:
    void applyTheme(const Theme &theme) override;
};

#endif // EMPTY_READING_LIST_WIDGET_H
