#ifndef __LIBRARY_CREATOR_H
#define __LIBRARY_CREATOR_H

#include "comic_db.h"
#include "folder.h"

#include <QByteArray>
#include <QDir>
#include <QFile>
#include <QMutex>
#include <QObject>
#include <QProcess>
#include <QRegExp>
#include <QSqlDatabase>
#include <QString>
#include <QThread>
#include <QtCore>

class LibraryCreator : public QThread
{
    Q_OBJECT
public:
    LibraryCreator(QSettings *settings);
    void createLibrary(const QString &source, const QString &target);
    void updateLibrary(const QString &source, const QString &target);
    void updateFolder(const QString &source, const QString &target, const QString &folder, qulonglong folderId);
    void stop(); // used to stop the process and keep the changes
    void cancel(); // cancels this run and changes in the DB are rolled back

private:
    void processLibrary(const QString &source, const QString &target);
    enum Mode { CREATOR,
                UPDATER };
    // atributos "globales" durante el proceso de creación y actualización
    enum Mode _mode;
    QString _source;
    QString _target;
    QString _sourceFolder; // used for partial updates
    QStringList _nameFilter;
    QString _databaseConnection;
    QList<Folder> _currentPathFolders; // lista de folders en el orden en el que están siendo explorados, el último es el folder actual
    // recursive method
    void create(QDir currentDirectory);
    void update(QDir currentDirectory);
    void run() override;
    qulonglong insertFolders(); // devuelve el id del último folder añadido (último en la ruta)
    bool checkCover(const QString &hash);
    void insertComic(const QString &relativePath, const QFileInfo &fileInfo);
    void replaceComic(const QString &relativePath, const QFileInfo &fileInfo, ComicDB *comic);
    // qulonglong insertFolder(qulonglong parentId,const Folder & folder);
    // qulonglong insertComic(const Comic & comic);
    bool stopRunning;
    bool canceled;
    // LibraryCreator está en modo creación si creation == true;
    bool creation;
    bool partialUpdate;
    qulonglong _folderDestinationId;
    QSettings *settings;
    bool checkModifiedDatesOnUpdate;
    void cleanup(QSqlDatabase &db, const QString &target);

signals:
    void coverExtracted(QString);
    void folderUpdated(QString);
    void comicAdded(QString, QString);
    void updated();
    void created();
    void failedCreatingDB(QString);
    void failedOpeningDB(QString);
    void updatedCurrentFolder(qulonglong folderId);
};

#endif
