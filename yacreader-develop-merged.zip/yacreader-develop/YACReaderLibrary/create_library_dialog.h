#ifndef __CREATE_LIBRARY_DIALOG_H
#define __CREATE_LIBRARY_DIALOG_H

#include "themable.h"
#include "yacreader_libraries.h"

#include <QDialog>
#include <QLabel>
#include <QLineEdit>
#include <QProgressBar>
#include <QPushButton>
#include <QThread>

class CreateLibraryDialog : public QDialog, protected Themable
{
    Q_OBJECT
public:
    CreateLibraryDialog(QWidget *parent = nullptr);

protected:
    void applyTheme(const Theme &theme) override;

private:
    QLabel *imgLabel;
    QLabel *nameLabel;
    QLabel *textLabel;
    QLabel *message;
    QProgressBar *progressBar;
    QLineEdit *path;
    QLineEdit *nameEdit;
    QPushButton *find;
    QPushButton *accept;
    QPushButton *cancel;
    YACReaderLibraries libraries;
    void setupUI();
public slots:
    void create();
    void findPath();
    void close();
    void setDataAndStart(QString name, QString paht);
    void nameSetted(const QString &text);
    void pathSetted(const QString &text);
    void open(const YACReaderLibraries &libraries);
signals:
    void createLibrary(QString source, QString target, QString name);
    void cancelCreate();
    void libraryExists(const QString &name);
};

class UpdateLibraryDialog : public QDialog
{
    Q_OBJECT
public:
    UpdateLibraryDialog(QWidget *parent = nullptr);

private:
    QLabel *message;
    QLabel *currentFileLabel;
    QProgressBar *progressBar;
    QPushButton *cancel;
public slots:
    void showCurrentFile(QString file);
    void close();
signals:
    void cancelUpdate();
};

#endif
