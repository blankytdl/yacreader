
#include "libraries_update_coordinator.h"

#include "library_creator.h"
#include "xml_info_library_scanner.h"
#include "yacreader_global.h"
#include "yacreader_libraries.h"

using namespace YACReader;

LibrariesUpdateCoordinator::LibrariesUpdateCoordinator(QSettings *settings, YACReaderLibraries &libraries, const std::function<bool()> &canStartUpdateProvider, QObject *parent)
    : QObject(parent), libraries(libraries), canStartUpdateProvider(canStartUpdateProvider)
{
    libraries.load();

    this->settings = settings;

    timer.setInterval(1000 * 60);

    connect(&timer, &QTimer::timeout, this, &LibrariesUpdateCoordinator::checkUpdatePolicy);
}

void LibrariesUpdateCoordinator::init()
{
    timer.start();
    elapsedTimer.start();

    if (settings->value(UPDATE_LIBRARIES_AT_STARTUP, false).toBool()) {
        updateLibraries();
    }
}

void LibrariesUpdateCoordinator::checkUpdatePolicy()
{
    if (settings->value(UPDATE_LIBRARIES_PERIODICALLY, false).toBool()) {
        auto variant = settings->value(UPDATE_LIBRARIES_PERIODICALLY_INTERVAL, static_cast<typename std::underlying_type<YACReader::LibrariesUpdateInterval>::type>(YACReader::LibrariesUpdateInterval::Hours2));

        bool itIsDue = false;
        auto interval = static_cast<YACReader::LibrariesUpdateInterval>(variant.toInt());
        switch (interval) {
        case YACReader::LibrariesUpdateInterval::Minutes30:
            itIsDue = elapsedTimer.elapsed() >= 1000 * 60 * 30;
            break;
        case YACReader::LibrariesUpdateInterval::Hourly:
            itIsDue = elapsedTimer.elapsed() >= 1000 * 60 * 60;
            break;
        case YACReader::LibrariesUpdateInterval::Hours2:
            itIsDue = elapsedTimer.elapsed() >= 1000 * 60 * 60 * 2;
            break;
        case YACReader::LibrariesUpdateInterval::Hours4:
            itIsDue = elapsedTimer.elapsed() >= 1000 * 60 * 60 * 4;
            break;
        case YACReader::LibrariesUpdateInterval::Hours8:
            itIsDue = elapsedTimer.elapsed() >= 1000 * 60 * 60 * 8;
            break;
        case YACReader::LibrariesUpdateInterval::Hours12:
            itIsDue = elapsedTimer.elapsed() >= 1000 * 60 * 60 * 12;
            break;
        case YACReader::LibrariesUpdateInterval::Daily:
            itIsDue = elapsedTimer.elapsed() >= 1000 * 60 * 60 * 24;
            break;
        }

        if (itIsDue) {
            elapsedTimer.restart();
            updateLibraries();
            return;
        }
    }

    if (settings->value(UPDATE_LIBRARIES_AT_CERTAIN_TIME, false).toBool()) {
        QTime time = settings->value(UPDATE_LIBRARIES_AT_CERTAIN_TIME_TIME, "00:00").toTime();
        QTime currentTime = QTime::currentTime();

        if (currentTime.hour() == time.hour() && currentTime.minute() == time.minute()) {
            updateLibraries();
            return;
        }
    }
}

void LibrariesUpdateCoordinator::updateLibraries()
{
    requestLibrariesUpdate();
}

void LibrariesUpdateCoordinator::updateSingleLibrary(int id)
{
    requestSingleLibraryUpdate(id);
}

LibrariesUpdateCoordinator::UpdateRequestResult LibrariesUpdateCoordinator::requestLibrariesUpdate()
{
    if (isRunning()) {
        return UpdateRequestResult::AlreadyRunning;
    }

    if (!canStartUpdateProvider()) {
        return UpdateRequestResult::NotAllowed;
    }

    return startUpdate({ });
}

LibrariesUpdateCoordinator::UpdateRequestResult LibrariesUpdateCoordinator::requestSingleLibraryUpdate(int id)
{
    if (isRunning()) {
        return UpdateRequestResult::AlreadyRunning;
    }

    const QString path = libraries.getPath(id);
    if (path.isEmpty()) {
        return UpdateRequestResult::LibraryNotFound;
    }

    if (!canStartUpdateProvider()) {
        return UpdateRequestResult::NotAllowed;
    }

    return startUpdate({ path });
}

LibrariesUpdateCoordinator::UpdateRequestResult LibrariesUpdateCoordinator::requestSingleLibraryXmlRescan(int id)
{
    if (isRunning()) {
        return UpdateRequestResult::AlreadyRunning;
    }

    const QString path = libraries.getPath(id);
    if (path.isEmpty()) {
        return UpdateRequestResult::LibraryNotFound;
    }

    if (!canStartUpdateProvider()) {
        return UpdateRequestResult::NotAllowed;
    }

    return startXmlRescan(path);
}

bool LibrariesUpdateCoordinator::isRunning() const
{
    QMutexLocker locker(&futureMutex);
    return updateFuture.valid() && updateFuture.wait_for(std::chrono::seconds(0)) != std::future_status::ready;
}

LibrariesUpdateCoordinator::UpdateRequestResult LibrariesUpdateCoordinator::startUpdate(const QStringList &paths)
{
    QMutexLocker locker(&futureMutex);

    if (updateFuture.valid() && updateFuture.wait_for(std::chrono::seconds(0)) != std::future_status::ready) {
        return UpdateRequestResult::AlreadyRunning;
    }

    canceled = false;

    QStringList targets = paths;
    if (targets.isEmpty()) {
        const auto availableLibraries = libraries.getLibraries();
        for (const auto &library : availableLibraries) {
            targets.append(library.getPath());
        }
    }

    updateFuture = std::async(std::launch::async, [this, targets] {
        emit updateStarted();
        for (const auto &path : targets) {
            if (!canceled) {
                updateLibrary(path);
            }
        }
        emit updateEnded();
    });

    return UpdateRequestResult::Started;
}

LibrariesUpdateCoordinator::UpdateRequestResult LibrariesUpdateCoordinator::startXmlRescan(const QString &path)
{
    QMutexLocker locker(&futureMutex);

    if (updateFuture.valid() && updateFuture.wait_for(std::chrono::seconds(0)) != std::future_status::ready) {
        return UpdateRequestResult::AlreadyRunning;
    }

    canceled = false;
    updateFuture = std::async(std::launch::async, [this, path] {
        emit updateStarted();
        if (!canceled) {
            rescanLibraryXml(path);
        }
        emit updateEnded();
    });

    return UpdateRequestResult::Started;
}

void LibrariesUpdateCoordinator::updateLibrary(const QString &path)
{
    QDir pathDir(path);
    if (!pathDir.exists()) {
        return;
    }

    QEventLoop eventLoop;
    auto libraryCreator = new LibraryCreator(settings);
    std::shared_ptr<LibraryCreator> sharedPtr(libraryCreator);
    currentLibraryCreator = sharedPtr;

    QString cleanPath = QDir::cleanPath(pathDir.absolutePath());

    libraryCreator->updateLibrary(cleanPath, LibraryPaths::libraryDataPath(cleanPath));

    connect(libraryCreator, &LibraryCreator::finished, &eventLoop, &QEventLoop::quit);

    libraryCreator->start();
    eventLoop.exec();
}

void LibrariesUpdateCoordinator::rescanLibraryXml(const QString &path)
{
    QDir pathDir(path);
    if (!pathDir.exists()) {
        return;
    }

    QEventLoop eventLoop;
    auto scanner = new XMLInfoLibraryScanner();
    std::shared_ptr<XMLInfoLibraryScanner> sharedPtr(scanner);
    currentXmlInfoLibraryScanner = sharedPtr;

    const QString cleanPath = QDir::cleanPath(pathDir.absolutePath());
    connect(scanner, &XMLInfoLibraryScanner::finished, &eventLoop, &QEventLoop::quit);

    scanner->scanLibrary(cleanPath, LibraryPaths::libraryDataPath(cleanPath));
    eventLoop.exec();
}

void LibrariesUpdateCoordinator::stop()
{
    canceled = true;

    if (auto libraryCreator = currentLibraryCreator.lock()) {
        libraryCreator->stop();
    }

    if (auto scanner = currentXmlInfoLibraryScanner.lock()) {
        scanner->stop();
    }
}

void LibrariesUpdateCoordinator::cancel()
{
    canceled = true;

    if (auto libraryCreator = currentLibraryCreator.lock()) {
        libraryCreator->cancel();
    }

    if (auto scanner = currentXmlInfoLibraryScanner.lock()) {
        scanner->stop();
    }
}
