#ifndef UPDATECOMICCONTROLLER_V2_H
#define UPDATECOMICCONTROLLER_V2_H

#include "httprequest.h"
#include "httprequesthandler.h"
#include "httpresponse.h"

class UpdateComicControllerV2 : public stefanfrings::HttpRequestHandler
{
    Q_OBJECT
    Q_DISABLE_COPY(UpdateComicControllerV2)

public:
    UpdateComicControllerV2();

    /** Generates the response */
    void service(stefanfrings::HttpRequest &request, stefanfrings::HttpResponse &response) override;

    bool error;
    qulonglong updatedLibraryId;
    qulonglong updatedComicId;
};

#endif // UPDATECOMICCONTROLLER_H
