/**
  @file
  @author Stefan Frings
*/

#include "yacreader_http_server.h"

#include "static.h"
// #include "dualfilelogger.h"
#include "httplistener.h"
#include "requestmapper.h"
#include "staticfilecontroller.h"
#include "yacreader_global.h"

#include <QCoreApplication>
#include <QDir>

/** Name of this application */
#define APPNAME "YACReaderLibrary"

/** Publisher of this application */
#define ORGANISATION "YACReader"

/** Short description of this application */
#define DESCRIPTION "Comic reader and organizer"

using stefanfrings::HttpListener;
using stefanfrings::StaticFileController;

void YACReaderHttpServer::start(quint16 port)
{
    // Initialize the core application
    QCoreApplication *app = QCoreApplication::instance();
    QString configFileName = YACReader::getSettingsPath() + "/" + QCoreApplication::applicationName() + ".ini";

    Static::yacreaderSessionStore = new YACReaderHttpSessionStore(app);

    // Configure static file controller
    auto fileSettings = new QSettings(configFileName, QSettings::IniFormat, app);
    fileSettings->beginGroup("docroot");

    QString basedocroot = "./server/docroot";
    QString docroot;

#if defined Q_OS_UNIX && !defined Q_OS_MACOS
    QFileInfo configFile(QString(DATADIR) + "/yacreader");
    docroot = QFileInfo(QString(DATADIR) + "/yacreader", basedocroot).absoluteFilePath();
#else
    QFileInfo configFile(QCoreApplication::applicationDirPath());
    docroot = QFileInfo(QCoreApplication::applicationDirPath(), basedocroot).absoluteFilePath();
#endif

    // The WebUI is shipped with the application, so its document root must
    // follow the currently running binary. Persisting the generated path made
    // it point to stale build and installation directories after an upgrade.
    // TODO: do we really want to keep using this setting at all?
    fileSettings->setValue("path", docroot);

    Static::staticFileController = new StaticFileController(fileSettings, app);

    // Configure and start the TCP listener
    qDebug("ServiceHelper: Starting service");
    auto listenerSettings = new QSettings(configFileName, QSettings::IniFormat, app);
    listenerSettings->beginGroup("listener");

    if (listenerSettings->value("maxRequestSize").isNull())
        listenerSettings->setValue("maxRequestSize", "32000000");

    if (listenerSettings->value("maxMultiPartSize").isNull())
        listenerSettings->setValue("maxMultiPartSize", "32000000");

    if (listenerSettings->value("cleanupInterval").isNull())
        listenerSettings->setValue("cleanupInterval", 10000);

    if (listenerSettings->value("maxThreads").isNull())
        listenerSettings->setValue("maxThreads", 1000);

    if (listenerSettings->value("minThreads").isNull())
        listenerSettings->setValue("minThreads", 50);

    if (listenerSettings->value("port").isNull())
        listenerSettings->setValue("port", 8080);

    // start with a temporary port
    if (port != 0) {
        // cache saved port
        if (!listenerSettings->contains("cachedPort")) {
            listenerSettings->setValue("cachedPort", listenerSettings->value("port").toInt());
        }
        listenerSettings->setValue("port", port);
    } else {
        // restore saved port
        if (listenerSettings->contains("cachedPort")) {
            listenerSettings->setValue("port", listenerSettings->value("cachedPort"));
            listenerSettings->remove("cachedPort");
        }
    }
    // test if port is working
    {
        QTcpServer testServer;
        if (!testServer.listen(QHostAddress::Any, listenerSettings->value("port").toInt())) {
            qDebug("Port is busy.");
            // get random port
            testServer.listen(QHostAddress::Any, 0);
            listenerSettings->setValue("port", testServer.serverPort());
        }
        testServer.close();
    }

    auto requestMapper = new RequestMapper(app);
    listener = new HttpListener(listenerSettings, requestMapper, app);

    connect(requestMapper, &RequestMapper::comicUpdated, this, &YACReaderHttpServer::comicUpdated);
    connect(requestMapper, &RequestMapper::libraryContentChanged, this, &YACReaderHttpServer::libraryContentChanged);

    if (listener->isListening()) {
        qDebug("ServiceHelper: Service has started");
    } else {
        qDebug("ServiceHelper: Could not launch service");
    }
}

void YACReaderHttpServer::stop()
{
    qDebug("ServiceHelper: Service has been stopped");
    // QCoreApplication destroys all objects that have been created in start().
    if (listener != nullptr) {
        listener->close();
        delete listener;
        listener = nullptr;
    }
}

bool YACReaderHttpServer::isRunning()
{
    if (listener == nullptr) {
        return false;
    }

    return listener->isListening();
}

YACReaderHttpServer::YACReaderHttpServer()
    : QObject(nullptr), listener(nullptr)
{
}

QString YACReaderHttpServer::getPort()
{
    if (listener == nullptr) {
        return "-1";
    }

    return QString("%1").arg(listener->serverPort());
}

QString YACReaderHttpServer::errorString() const
{
    if (listener == nullptr) {
        return QString();
    }

    return listener->errorString();
}
