<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_HK">
<context>
    <name>ActionsShortcutsModel</name>
    <message>
        <location filename="../shortcuts_management/actions_shortcuts_model.cpp" line="74"/>
        <source>None</source>
        <translation>無</translation>
    </message>
</context>
<context>
    <name>AppearanceTabWidget</name>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="38"/>
        <source>Color scheme</source>
        <translation>配色方案</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="46"/>
        <source>System</source>
        <translation>系統</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="47"/>
        <source>Light</source>
        <translation>亮度</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="48"/>
        <source>Dark</source>
        <translation>黑暗的</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="49"/>
        <source>Custom</source>
        <translation>風俗</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="105"/>
        <source>Remove</source>
        <translation>消除</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="107"/>
        <source>Remove this user-imported theme</source>
        <translation>刪除此使用者匯入的主題</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="115"/>
        <source>Light:</source>
        <translation>光：</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="116"/>
        <source>Dark:</source>
        <translation>黑暗的：</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="117"/>
        <source>Custom:</source>
        <translation>自定義:</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="119"/>
        <source>Import theme...</source>
        <translation>導入主題...</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="121"/>
        <source>Theme</source>
        <translation>主題</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="173"/>
        <source>Theme editor</source>
        <translation>主題編輯器</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="175"/>
        <source>Open Theme Editor...</source>
        <translation>開啟主題編輯器...</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="184"/>
        <source>Theme editor error</source>
        <translation>主題編輯器錯誤</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="185"/>
        <source>The current theme JSON could not be loaded.</source>
        <translation>無法載入目前主題 JSON。</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="285"/>
        <source>Import theme</source>
        <translation>導入主題</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="285"/>
        <source>JSON files (*.json);;All files (*)</source>
        <translation>JSON 檔案 (*.json);;所有檔案 (*)</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="293"/>
        <source>Could not import theme from:
%1</source>
        <translation>無法從以下位置匯入主題：
%1</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="294"/>
        <source>Could not import theme from:
%1

%2</source>
        <translation>無法從以下位置匯入主題：
%1

%2</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="295"/>
        <source>Import failed</source>
        <translation>導入失敗</translation>
    </message>
</context>
<context>
    <name>BookmarksDialog</name>
    <message>
        <location filename="bookmarks_dialog.cpp" line="27"/>
        <source>Lastest Page</source>
        <translation>尾頁</translation>
    </message>
    <message>
        <location filename="bookmarks_dialog.cpp" line="77"/>
        <source>Close</source>
        <translation>關閉</translation>
    </message>
    <message>
        <location filename="bookmarks_dialog.cpp" line="87"/>
        <source>Click on any image to go to the bookmark</source>
        <translation>點擊任意圖片以跳轉至相應書簽位置</translation>
    </message>
    <message>
        <location filename="bookmarks_dialog.cpp" line="109"/>
        <location filename="bookmarks_dialog.cpp" line="126"/>
        <source>Loading...</source>
        <translation>載入中...</translation>
    </message>
</context>
<context>
    <name>ContinuousPageWidget</name>
    <message>
        <location filename="continuous_page_widget.cpp" line="272"/>
        <source>Loading page %1</source>
        <translation>正在載入頁面 %1</translation>
    </message>
</context>
<context>
    <name>EditShortcutsDialog</name>
    <message>
        <location filename="../shortcuts_management/edit_shortcuts_dialog.cpp" line="19"/>
        <source>Restore defaults</source>
        <translation>恢復默認</translation>
    </message>
    <message>
        <location filename="../shortcuts_management/edit_shortcuts_dialog.cpp" line="20"/>
        <source>To change a shortcut, double click in the key combination and type the new keys.</source>
        <translation>更改快捷鍵: 雙擊按鍵組合並輸入新的映射.</translation>
    </message>
    <message>
        <location filename="../shortcuts_management/edit_shortcuts_dialog.cpp" line="67"/>
        <source>Shortcuts settings</source>
        <translation>快捷鍵設置</translation>
    </message>
    <message>
        <location filename="../shortcuts_management/edit_shortcuts_dialog.cpp" line="118"/>
        <source>Shortcut in use</source>
        <translation>快捷鍵被佔用</translation>
    </message>
    <message>
        <location filename="../shortcuts_management/edit_shortcuts_dialog.cpp" line="118"/>
        <source>The shortcut &quot;%1&quot; is already assigned to other function</source>
        <translation>快捷鍵 &quot;%1&quot; 已被映射至其他功能</translation>
    </message>
</context>
<context>
    <name>FileComic</name>
    <message>
        <location filename="../common/comic.cpp" line="490"/>
        <source>CRC error on page (%1): some of the pages will not be displayed correctly</source>
        <translation>第 %1 頁 CRC 校驗失敗: 部分頁面將無法正確顯示</translation>
    </message>
    <message>
        <location filename="../common/comic.cpp" line="497"/>
        <source>Unknown error opening the file</source>
        <translation>打開檔時出現未知錯誤</translation>
    </message>
    <message>
        <location filename="../common/comic.cpp" line="604"/>
        <source>7z not found</source>
        <translation>未找到 7z</translation>
    </message>
    <message>
        <location filename="../common/comic.cpp" line="610"/>
        <location filename="../common/comic.cpp" line="626"/>
        <source>Format not supported</source>
        <translation>不支持的檔格式</translation>
    </message>
</context>
<context>
    <name>GoToDialog</name>
    <message>
        <location filename="goto_dialog.cpp" line="16"/>
        <source>Page : </source>
        <translation>頁碼 : </translation>
    </message>
    <message>
        <location filename="goto_dialog.cpp" line="24"/>
        <source>Go To</source>
        <translation>跳轉</translation>
    </message>
    <message>
        <location filename="goto_dialog.cpp" line="26"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="goto_dialog.cpp" line="40"/>
        <location filename="goto_dialog.cpp" line="70"/>
        <source>Total pages : </source>
        <translation>總頁數: </translation>
    </message>
    <message>
        <location filename="goto_dialog.cpp" line="52"/>
        <source>Go to...</source>
        <translation>跳轉至 ...</translation>
    </message>
</context>
<context>
    <name>GoToFlowToolBar</name>
    <message>
        <location filename="goto_flow_toolbar.cpp" line="32"/>
        <source>Page : </source>
        <translation>頁碼 : </translation>
    </message>
</context>
<context>
    <name>HelpAboutDialog</name>
    <message>
        <location filename="../custom_widgets/help_about_dialog.cpp" line="25"/>
        <source>About</source>
        <translation>關於</translation>
    </message>
    <message>
        <location filename="../custom_widgets/help_about_dialog.cpp" line="28"/>
        <source>Help</source>
        <translation>幫助</translation>
    </message>
    <message>
        <location filename="../custom_widgets/help_about_dialog.cpp" line="31"/>
        <source>System info</source>
        <translation>系統資訊</translation>
    </message>
    <message>
        <location filename="../custom_widgets/help_about_dialog.cpp" line="40"/>
        <source>Changelog</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <location filename="options_dialog.cpp" line="78"/>
        <source>&quot;Go to flow&quot; size</source>
        <translation>「前往 Comic Flow」大小</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="38"/>
        <source>My comics path</source>
        <translation>我的漫畫路徑</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="96"/>
        <source>Background color</source>
        <translation>背景顏色</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="99"/>
        <source>Choose</source>
        <translation>選擇</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="180"/>
        <source>Quick Navigation Mode</source>
        <translation>快速導航模式</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="181"/>
        <source>Disable mouse over activation</source>
        <translation>禁用滑鼠啟動</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="271"/>
        <source>Scaling</source>
        <translation>縮放</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="273"/>
        <source>Scaling method</source>
        <translation>縮放方法</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="275"/>
        <source>Nearest (fast, low quality)</source>
        <translation>最近（快速，低品質）</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="276"/>
        <source>Bilinear</source>
        <translation>雙線性</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="277"/>
        <source>Lanczos (better quality)</source>
        <translation>Lanczos（品質更好）</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="317"/>
        <source>Restart is needed</source>
        <translation>需要重啟</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="223"/>
        <source>Brightness</source>
        <translation>亮度</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="58"/>
        <source>Display</source>
        <translation>展示</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="60"/>
        <source>Show time in current page information label</source>
        <translation>在目前頁面資訊標籤中顯示時間</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="64"/>
        <source>Magnifying glass</source>
        <translation>放大鏡</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="66"/>
        <source>Circular magnifying glass</source>
        <translation>圓形放大鏡</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="67"/>
        <source>Draw a ring around the circular magnifying glass</source>
        <translation>在圓形放大鏡周圍繪製邊框</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="70"/>
        <source>Ease cursor movement toward the edges</source>
        <translation>平滑游標移向邊緣的移動</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="108"/>
        <source>Scroll behaviour</source>
        <translation>滾動效果</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="111"/>
        <source>Disable scroll animations and smooth scrolling</source>
        <translation>停用滾動動畫和平滑滾動</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="112"/>
        <source>Do not turn page using scroll</source>
        <translation>滾動時不翻頁</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="113"/>
        <source>Use single scroll step to turn page</source>
        <translation>使用單滾動步驟翻頁</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="121"/>
        <source>Mouse mode</source>
        <translation>滑鼠模式</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="124"/>
        <source>Only Back/Forward buttons can turn pages</source>
        <translation>只有後退/前進按鈕可以翻頁</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="125"/>
        <source>Use the Left/Right buttons to turn pages.</source>
        <translation>使用向左/向右按鈕翻頁。</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="126"/>
        <source>Click left or right half of the screen to turn pages.</source>
        <translation>點擊螢幕的左半部或右半部即可翻頁。</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="134"/>
        <source>Escape key</source>
        <translation>Esc 鍵</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="137"/>
        <source>Quit the reader</source>
        <translation>退出閱讀器</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="138"/>
        <source>Cancel the active mode</source>
        <translation>取消目前模式</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="140"/>
        <source>Escape closes the reader, even while a mode is active.</source>
        <translation>即使有模式正在使用，按 Esc 鍵仍會關閉閱讀器。</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="145"/>
        <source>Escape cancels the first of these that is active:

1. Magnifying glass
2. Dictionary
3. Go to page bar
4. Fullscreen

If none is active, Escape does nothing.</source>
        <extracomment>Tooltip listing the order in which modes are cancelled. Only the first active mode in the list is cancelled per Escape keypress.</extracomment>
        <translation>按 Esc 鍵會取消下列第一個正在使用的模式：

1. 放大鏡
2. 字典
3. 前往頁面列
4. 全螢幕

若沒有任何模式正在使用，按 Esc 鍵不會執行任何操作。</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="176"/>
        <source>Use software-rendered &quot;go to flow&quot; (requires restart)</source>
        <translation>使用軟件渲染的「前往 Comic Flow」（需要重新啟動）</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="177"/>
        <source>Use a simple horizontal list of page thumbnails instead of the GPU-rendered 3D flow. Enable this if reading is not smooth on your system.</source>
        <translation>使用簡單的水平頁面縮圖清單，取代由 GPU 渲染的 3D Flow。如果在您的系統上閱讀不流暢，請啟用此選項。</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="224"/>
        <source>Contrast</source>
        <translation>對比度</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="225"/>
        <source>Gamma</source>
        <translation>Gamma值</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="229"/>
        <source>Reset</source>
        <translation>重置</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="234"/>
        <source>Image options</source>
        <translation>圖片選項</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="238"/>
        <source>Fit options</source>
        <translation>適應項</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="240"/>
        <source>Enlarge images to fit width/height</source>
        <translation>放大圖片以適應寬度/高度</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="251"/>
        <source>Double Page options</source>
        <translation>雙頁選項</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="253"/>
        <source>Show covers as single page</source>
        <translation>顯示封面為單頁</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="259"/>
        <source>Show book fold shadow</source>
        <translation>顯示書頁摺疊陰影</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="307"/>
        <source>General</source>
        <translation>常規</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="310"/>
        <source>Appearance</source>
        <translation>外貌</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="45"/>
        <source>Language</source>
        <translation>語言</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="47"/>
        <source>Application language</source>
        <translation>應用程式語言</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="49"/>
        <source>System default</source>
        <translation>系統預設</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="100"/>
        <source>Clear</source>
        <translation>清空</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="308"/>
        <source>Page Flow</source>
        <translation>頁面流</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="309"/>
        <source>Image adjustment</source>
        <translation>圖像調整</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="326"/>
        <source>Options</source>
        <translation>選項</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="342"/>
        <source>Comics directory</source>
        <translation>漫畫目錄</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../common/exit_check.cpp" line="13"/>
        <source>7z lib not found</source>
        <translation>未找到 7z 庫檔</translation>
    </message>
    <message>
        <location filename="../common/exit_check.cpp" line="13"/>
        <source>unable to load 7z lib from ./utils</source>
        <translation>無法從 ./utils 載入 7z 庫檔</translation>
    </message>
    <message>
        <location filename="../common/yacreader_global_gui.cpp" line="95"/>
        <source>Select custom cover</source>
        <translation>選擇自訂封面</translation>
    </message>
    <message>
        <location filename="../common/yacreader_global_gui.cpp" line="95"/>
        <source>Images (%1)</source>
        <translation>圖片 (%1)</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_repository.cpp" line="152"/>
        <source>The file could not be read or is not valid JSON.</source>
        <translation>無法讀取該檔案或該檔案不是有效的 JSON。</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_repository.cpp" line="161"/>
        <source>This theme is for %1, not %2.</source>
        <translation>此主題適用於 %1，而不是 %2。</translation>
    </message>
</context>
<context>
    <name>ThemeEditorDialog</name>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="59"/>
        <source>Theme Editor</source>
        <translation>主題編輯器</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="63"/>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="64"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="65"/>
        <source>i</source>
        <translation>我</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="69"/>
        <source>Expand all</source>
        <translation>全部展開</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="70"/>
        <source>Collapse all</source>
        <translation>全部折疊</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="71"/>
        <source>Hold to flash the selected value in the UI (magenta / toggled / 0↔10). Releases restore the original.</source>
        <translation>按住可在 UI 中閃爍所選值（洋紅色/切換/0↔10）。發布後恢復原樣。</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="76"/>
        <source>Search…</source>
        <translation>搜尋…</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="94"/>
        <source>Light</source>
        <translation>亮度</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="95"/>
        <source>Dark</source>
        <translation>黑暗的</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="98"/>
        <source>ID:</source>
        <translation>ID：</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="99"/>
        <source>Display name:</source>
        <translation>顯示名稱：</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="100"/>
        <source>Variant:</source>
        <translation>變體：</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="102"/>
        <source>Theme info</source>
        <translation>主題訊息</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="125"/>
        <source>Parameter</source>
        <translation>範圍</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="125"/>
        <source>Value</source>
        <translation>價值</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="149"/>
        <source>Save and apply</source>
        <translation>儲存並應用</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="150"/>
        <source>Export to file...</source>
        <translation>匯出到文件...</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="151"/>
        <source>Load from file...</source>
        <translation>從檔案載入...</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="152"/>
        <source>Close</source>
        <translation>關閉</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="209"/>
        <source>Double-click to edit color</source>
        <translation>雙擊編輯顏色</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="211"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="264"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="265"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="459"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="464"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="495"/>
        <source>true</source>
        <translation>真的</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="211"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="265"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="464"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="495"/>
        <source>false</source>
        <translation>錯誤的</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="214"/>
        <source>Double-click to toggle</source>
        <translation>按兩下切換</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="218"/>
        <source>Double-click to edit value</source>
        <translation>雙擊編輯值</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="232"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="280"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="285"/>
        <source>Edit: %1</source>
        <translation>編輯：%1</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="399"/>
        <source>Save theme</source>
        <translation>儲存主題</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="399"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="414"/>
        <source>JSON files (*.json);;All files (*)</source>
        <translation>JSON 檔案 (*.json);;所有檔案 (*)</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="405"/>
        <source>Save failed</source>
        <translation>保存失敗</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="405"/>
        <source>Could not open file for writing:
%1</source>
        <translation>無法開啟文件進行寫入：
%1</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="414"/>
        <source>Load theme</source>
        <translation>載入主題</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="420"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="427"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="431"/>
        <source>Load failed</source>
        <translation>載入失敗</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="420"/>
        <source>Could not open file:
%1</source>
        <translation>無法開啟檔案：
%1</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="427"/>
        <source>Invalid JSON:
%1</source>
        <translation>無效的 JSON：
%1</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="431"/>
        <source>Expected a JSON object.</source>
        <translation>需要一個 JSON 物件。</translation>
    </message>
</context>
<context>
    <name>Viewer</name>
    <message>
        <location filename="viewer.cpp" line="125"/>
        <location filename="viewer.cpp" line="1815"/>
        <source>Press &apos;O&apos; to open comic.</source>
        <translation>按下 &apos;O&apos; 以打開漫畫.</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="372"/>
        <source>Not found</source>
        <translation>未找到</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="372"/>
        <source>Comic not found</source>
        <translation>未找到漫畫</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="378"/>
        <source>Error opening comic</source>
        <translation>打開漫畫時發生錯誤</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="384"/>
        <source>CRC Error</source>
        <translation>CRC 校驗失敗</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="1832"/>
        <source>Loading...please wait!</source>
        <translation>載入中... 請稍候!</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="1843"/>
        <source>Page not available!</source>
        <translation>頁面不可用!</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="2181"/>
        <source>Cover!</source>
        <translation>封面!</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="2195"/>
        <source>Last page!</source>
        <translation>尾頁!</translation>
    </message>
</context>
<context>
    <name>YACReader3DFlowConfigWidget</name>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="19"/>
        <source>Presets:</source>
        <translation>預設:</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="21"/>
        <source>Classic look</source>
        <translation>經典</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="24"/>
        <source>Stripe look</source>
        <translation>條狀</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="27"/>
        <source>Overlapped Stripe look</source>
        <translation>重疊條狀</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="30"/>
        <source>Modern look</source>
        <translation>現代</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="33"/>
        <source>Roulette look</source>
        <translation>輪盤</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="77"/>
        <source>Show advanced settings</source>
        <translation>顯示高級選項</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="86"/>
        <source>Custom:</source>
        <translation>自定義:</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="89"/>
        <source>View angle</source>
        <translation>視角</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="95"/>
        <source>Position</source>
        <translation>位置</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="101"/>
        <source>Cover gap</source>
        <translation>封面間距</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="107"/>
        <source>Central gap</source>
        <translation>中心間距</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="113"/>
        <source>Zoom</source>
        <translation>縮放</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="119"/>
        <source>Y offset</source>
        <translation>Y位移</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="125"/>
        <source>Z offset</source>
        <translation>Z位移</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="131"/>
        <source>Cover Angle</source>
        <translation>封面角度</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="137"/>
        <source>Visibility</source>
        <translation>透明度</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="143"/>
        <source>Light</source>
        <translation>亮度</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="149"/>
        <source>Max angle</source>
        <translation>最大角度</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="181"/>
        <source>Low Performance</source>
        <translation>低性能</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="183"/>
        <source>High Performance</source>
        <translation>高性能</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="194"/>
        <source>Use VSync (improve the image quality in fullscreen mode, worse performance)</source>
        <translation>使用VSync (在全屏模式下提高圖像品質, 性能更差)</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="202"/>
        <source>Performance:</source>
        <translation>性能:</translation>
    </message>
</context>
<context>
    <name>YACReader::MainWindowViewer</name>
    <message>
        <location filename="main_window_viewer.cpp" line="327"/>
        <source>&amp;Open</source>
        <translation>打開(&amp;O)</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="328"/>
        <source>Open a comic</source>
        <translation>打開漫畫</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="334"/>
        <source>New instance</source>
        <translation>新建實例</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="353"/>
        <source>Open Folder</source>
        <translation>打開檔夾</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="354"/>
        <source>Open image folder</source>
        <translation>打開圖片檔夾</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="359"/>
        <source>Open latest comic</source>
        <translation>打開最近的漫畫</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="360"/>
        <source>Open the latest comic opened in the previous reading session</source>
        <translation>打開最近閱讀漫畫</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="372"/>
        <source>Clear</source>
        <translation>清空</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="373"/>
        <source>Clear open recent list</source>
        <translation>清空最近訪問列表</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="376"/>
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="377"/>
        <location filename="main_window_viewer.cpp" line="1097"/>
        <location filename="main_window_viewer.cpp" line="1108"/>
        <location filename="main_window_viewer.cpp" line="1119"/>
        <source>Save current page</source>
        <translation>保存當前頁面</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="382"/>
        <location filename="main_window_viewer.cpp" line="1124"/>
        <location filename="main_window_viewer.cpp" line="1138"/>
        <location filename="main_window_viewer.cpp" line="1149"/>
        <location filename="main_window_viewer.cpp" line="1167"/>
        <source>Extract page(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="383"/>
        <source>Extract page(s) from the original source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="388"/>
        <source>Previous Comic</source>
        <translation>上一個漫畫</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="389"/>
        <location filename="main_window_viewer.cpp" line="1915"/>
        <location filename="main_window_viewer.cpp" line="1919"/>
        <source>Open previous comic</source>
        <translation>打開上一個漫畫</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="394"/>
        <source>Next Comic</source>
        <translation>下一個漫畫</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="395"/>
        <location filename="main_window_viewer.cpp" line="1914"/>
        <location filename="main_window_viewer.cpp" line="1920"/>
        <source>Open next comic</source>
        <translation>打開下一個漫畫</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="400"/>
        <source>&amp;Previous</source>
        <translation>上一頁(&amp;P)</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="402"/>
        <location filename="main_window_viewer.cpp" line="1917"/>
        <location filename="main_window_viewer.cpp" line="1921"/>
        <source>Go to previous page</source>
        <translation>轉至上一頁</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="407"/>
        <source>&amp;Next</source>
        <translation>下一頁(&amp;N)</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="409"/>
        <location filename="main_window_viewer.cpp" line="1916"/>
        <location filename="main_window_viewer.cpp" line="1922"/>
        <source>Go to next page</source>
        <translation>轉至下一頁</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="414"/>
        <source>Fit Height</source>
        <translation>適應高度</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="415"/>
        <source>Fit image to height</source>
        <translation>縮放圖片以適應高度</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="421"/>
        <source>Fit Width</source>
        <translation>適合寬度</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="422"/>
        <source>Fit image to width</source>
        <translation>縮放圖片以適應寬度</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="428"/>
        <source>Show full size</source>
        <translation>顯示全尺寸</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="435"/>
        <source>Fit to page</source>
        <translation>適應頁面</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="441"/>
        <source>Continuous scroll</source>
        <translation>連續滾動</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="442"/>
        <source>Switch to continuous scroll mode</source>
        <translation>切換到連續滾動模式</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="476"/>
        <source>Reset zoom</source>
        <translation>重置縮放</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="481"/>
        <source>Show zoom slider</source>
        <translation>顯示縮放滑塊</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="483"/>
        <source>Zoom+</source>
        <translation>放大</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="488"/>
        <source>Zoom-</source>
        <translation>縮小</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="493"/>
        <source>Rotate image to the left</source>
        <translation>向左旋轉圖片</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="498"/>
        <source>Rotate image to the right</source>
        <translation>向右旋轉圖片</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="503"/>
        <source>Double page mode</source>
        <translation>雙頁模式</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="504"/>
        <source>Switch to double page mode</source>
        <translation>切換至雙頁模式</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="512"/>
        <source>Double page manga mode</source>
        <translation>雙頁漫畫模式</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="513"/>
        <source>Reverse reading order in double page mode</source>
        <translation>雙頁模式 (逆序閱讀)</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="521"/>
        <source>Go To</source>
        <translation>跳轉</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="522"/>
        <source>Go to page ...</source>
        <translation>跳轉至頁面 ...</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="527"/>
        <source>Options</source>
        <translation>選項</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="528"/>
        <source>YACReader options</source>
        <translation>YACReader 選項</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="534"/>
        <location filename="main_window_viewer.cpp" line="841"/>
        <source>Help</source>
        <translation>幫助</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="535"/>
        <source>Help, About YACReader</source>
        <translation>幫助, 關於 YACReader</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="540"/>
        <source>Magnifying glass</source>
        <translation>放大鏡</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="541"/>
        <source>Switch Magnifying glass</source>
        <translation>切換放大鏡</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="547"/>
        <source>Set bookmark</source>
        <translation>設置書簽</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="548"/>
        <source>Set a bookmark on the current page</source>
        <translation>在當前頁面設置書簽</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="556"/>
        <source>Show bookmarks</source>
        <translation>顯示書簽</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="557"/>
        <source>Show the bookmarks of the current comic</source>
        <translation>顯示當前漫畫的書簽</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="562"/>
        <source>Show keyboard shortcuts</source>
        <translation>顯示鍵盤快捷鍵</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="567"/>
        <source>Show Info</source>
        <translation>顯示資訊</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="575"/>
        <source>Escape</source>
        <translation>Esc</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="578"/>
        <source>Escape key: quit, or cancel the active mode</source>
        <translation>Esc 鍵：退出或取消目前模式</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="583"/>
        <source>Close</source>
        <translation>關閉</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="586"/>
        <source>Show Dictionary</source>
        <translation>顯示字典</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="592"/>
        <source>Show go to flow</source>
        <translation>顯示「前往 Comic Flow」</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="597"/>
        <source>Edit shortcuts</source>
        <translation>編輯快捷鍵</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="618"/>
        <source>&amp;File</source>
        <translation>檔(&amp;F)</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="633"/>
        <location filename="main_window_viewer.cpp" line="795"/>
        <source>Open recent</source>
        <translation>最近打開的檔</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="783"/>
        <source>File</source>
        <translation>檔</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="805"/>
        <source>Edit</source>
        <translation>編輯</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="809"/>
        <source>View</source>
        <translation>查看</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="826"/>
        <source>Go</source>
        <translation>轉到</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="834"/>
        <source>Window</source>
        <translation>窗口</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="951"/>
        <source>Open Comic</source>
        <translation>打開漫畫</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="950"/>
        <source>Comic files</source>
        <translation>漫畫檔</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1038"/>
        <source>Open folder</source>
        <translation>打開檔夾</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1351"/>
        <location filename="main_window_viewer.cpp" line="1364"/>
        <source>Comics</source>
        <translation>漫畫</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1375"/>
        <source>Toggle fullscreen mode</source>
        <translation>切換全屏模式</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1378"/>
        <source>Hide/show toolbar</source>
        <translation>隱藏/顯示 工具欄</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1352"/>
        <location filename="main_window_viewer.cpp" line="1381"/>
        <source>General</source>
        <translation>常規</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1400"/>
        <source>Size up magnifying glass</source>
        <translation>增大放大鏡尺寸</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1403"/>
        <source>Size down magnifying glass</source>
        <translation>減小放大鏡尺寸</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1406"/>
        <source>Zoom in magnifying glass</source>
        <translation>增大縮放級別</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1409"/>
        <source>Zoom out magnifying glass</source>
        <translation>減小縮放級別</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1412"/>
        <source>Reset magnifying glass</source>
        <translation>重置放大鏡</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1353"/>
        <location filename="main_window_viewer.cpp" line="1419"/>
        <source>Magnifiying glass</source>
        <translation>放大鏡</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1426"/>
        <source>Toggle between fit to width and fit to height</source>
        <translation>切換顯示為&quot;適應寬度&quot;或&quot;適應高度&quot;</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1354"/>
        <location filename="main_window_viewer.cpp" line="1430"/>
        <source>Page adjustement</source>
        <translation>頁面調整</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1108"/>
        <source>The current page is not ready. Please try again later.</source>
        <translation>目前頁面尚未準備就緒。請稍後再試。</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1113"/>
        <source>Overwrite file?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1113"/>
        <source>The file already exists. Do you want to overwrite it?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1119"/>
        <source>The current page could not be saved.</source>
        <translation>無法儲存目前頁面。</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1138"/>
        <source>The selected pages are not ready. Please try again later.</source>
        <translation>所選頁面尚未準備就緒。請稍後再試。</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1149"/>
        <source>The current page could not be extracted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1154"/>
        <source>Overwrite files?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1154"/>
        <source>Some files already exist. Do you want to overwrite them?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1167"/>
        <source>Some pages could not be extracted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1448"/>
        <source>Autoscroll down</source>
        <translation>向下自動滾動</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1451"/>
        <source>Autoscroll up</source>
        <translation>向上自動滾動</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1454"/>
        <source>Autoscroll forward, horizontal first</source>
        <translation>向前自動滾動，水準優先</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1458"/>
        <source>Autoscroll backward, horizontal first</source>
        <translation>向後自動滾動，水準優先</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1462"/>
        <source>Autoscroll forward, vertical first</source>
        <translation>向前自動滾動，垂直優先</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1466"/>
        <source>Autoscroll backward, vertical first</source>
        <translation>向後自動滾動，垂直優先</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1470"/>
        <source>Move down</source>
        <translation>向下移動</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1473"/>
        <source>Move up</source>
        <translation>向上移動</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1476"/>
        <source>Move left</source>
        <translation>向左移動</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1479"/>
        <source>Move right</source>
        <translation>向右移動</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1482"/>
        <source>Go to the first page</source>
        <translation>轉到第一頁</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1485"/>
        <source>Go to the last page</source>
        <translation>轉到最後一頁</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1488"/>
        <source>Offset double page to the left</source>
        <translation>雙頁向左偏移</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1490"/>
        <source>Offset double page to the right</source>
        <translation>雙頁向右偏移</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1355"/>
        <location filename="main_window_viewer.cpp" line="1508"/>
        <source>Reading</source>
        <translation>閱讀</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1557"/>
        <source>There is a new version available</source>
        <translation>有新版本可用</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1558"/>
        <source>Do you want to download the new version?</source>
        <translation>你要下載新版本嗎?</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1561"/>
        <source>Remind me in 14 days</source>
        <translation>14天後提醒我</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1562"/>
        <source>Not now</source>
        <translation>現在不</translation>
    </message>
</context>
<context>
    <name>YACReader::WhatsNewDialog</name>
    <message>
        <location filename="../custom_widgets/whats_new_dialog.cpp" line="182"/>
        <source>Release notes are not available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../custom_widgets/whats_new_dialog.cpp" line="238"/>
        <source>Previous versions</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>YACReaderFieldEdit</name>
    <message>
        <location filename="../custom_widgets/yacreader_field_edit.cpp" line="9"/>
        <location filename="../custom_widgets/yacreader_field_edit.cpp" line="28"/>
        <source>Click to overwrite</source>
        <translation>點擊以覆蓋</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_field_edit.cpp" line="11"/>
        <source>Restore to default</source>
        <translation>恢復默認</translation>
    </message>
</context>
<context>
    <name>YACReaderFieldPlainTextEdit</name>
    <message>
        <location filename="../custom_widgets/yacreader_field_plain_text_edit.cpp" line="9"/>
        <location filename="../custom_widgets/yacreader_field_plain_text_edit.cpp" line="19"/>
        <location filename="../custom_widgets/yacreader_field_plain_text_edit.cpp" line="44"/>
        <location filename="../custom_widgets/yacreader_field_plain_text_edit.cpp" line="50"/>
        <source>Click to overwrite</source>
        <translation>點擊以覆蓋</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_field_plain_text_edit.cpp" line="10"/>
        <source>Restore to default</source>
        <translation>恢復默認</translation>
    </message>
</context>
<context>
    <name>YACReaderOptionsDialog</name>
    <message>
        <location filename="../custom_widgets/yacreader_options_dialog.cpp" line="21"/>
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_options_dialog.cpp" line="22"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_options_dialog.cpp" line="29"/>
        <source>Keyboard shortcuts</source>
        <translation>鍵盤快捷鍵</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_options_dialog.cpp" line="31"/>
        <source>Customize the keyboard shortcuts used by the application.</source>
        <translation>自訂應用程式使用的鍵盤快捷鍵。</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_options_dialog.cpp" line="32"/>
        <source>Edit shortcuts</source>
        <translation>編輯快捷鍵</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_options_dialog.cpp" line="27"/>
        <source>Shortcuts</source>
        <translation>快捷鍵</translation>
    </message>
</context>
<context>
    <name>YACReaderSlider</name>
    <message>
        <location filename="width_slider.cpp" line="52"/>
        <source>Reset</source>
        <translation>重置</translation>
    </message>
</context>
<context>
    <name>YACReaderTranslator</name>
    <message>
        <location filename="translator.cpp" line="40"/>
        <source>YACReader translator</source>
        <translation>YACReader 翻譯</translation>
    </message>
    <message>
        <location filename="translator.cpp" line="80"/>
        <location filename="translator.cpp" line="186"/>
        <source>Translation</source>
        <translation>翻譯</translation>
    </message>
    <message>
        <location filename="translator.cpp" line="100"/>
        <source>clear</source>
        <translation>清空</translation>
    </message>
    <message>
        <location filename="translator.cpp" line="195"/>
        <source>Service not available</source>
        <translation>服務不可用</translation>
    </message>
</context>
</TS>
