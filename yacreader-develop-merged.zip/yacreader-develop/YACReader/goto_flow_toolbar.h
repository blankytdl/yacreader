#ifndef GOTO_FLOW_TOOLBAR_H
#define GOTO_FLOW_TOOLBAR_H

#include "themable.h"

#include <QStackedWidget>
#include <QWidget>

class QLineEdit;
class QIntValidator;
class QPushButton;
class QSlider;
class QLabel;

class GoToFlowToolBar : public QStackedWidget, protected Themable
{
    Q_OBJECT
protected:
    void applyTheme(const Theme &theme) override;

private:
    QLineEdit *edit;
    QSlider *slider;
    QIntValidator *v;
    QPushButton *centerButton;
    QPushButton *goToButton;
    QPushButton *goToButton2;
    QLabel *pageHint;
    QWidget *bar;
    void paintEvent(QPaintEvent *) override;

public:
    GoToFlowToolBar(QWidget *parent = nullptr);

public slots:
    void setPage(int pageNumber);
    void setTop(int numPages);
    void goTo();
    void centerSlide();
    void updateOptions();
signals:
    void setCenter(unsigned int);
    void goToPage(unsigned int);
};

#endif
