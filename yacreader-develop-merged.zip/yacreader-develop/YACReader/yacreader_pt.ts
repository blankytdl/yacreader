<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_BR">
<context>
    <name>ActionsShortcutsModel</name>
    <message>
        <location filename="../shortcuts_management/actions_shortcuts_model.cpp" line="74"/>
        <source>None</source>
        <translation>Nenhum</translation>
    </message>
</context>
<context>
    <name>AppearanceTabWidget</name>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="38"/>
        <source>Color scheme</source>
        <translation>Esquema de cores</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="46"/>
        <source>System</source>
        <translation>Sistema</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="47"/>
        <source>Light</source>
        <translation>Luz</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="48"/>
        <source>Dark</source>
        <translation>Escuro</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="49"/>
        <source>Custom</source>
        <translation>Personalizado</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="105"/>
        <source>Remove</source>
        <translation>Remover</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="107"/>
        <source>Remove this user-imported theme</source>
        <translation>Remova este tema importado pelo usuário</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="115"/>
        <source>Light:</source>
        <translation>Luz:</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="116"/>
        <source>Dark:</source>
        <translation>Escuro:</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="117"/>
        <source>Custom:</source>
        <translation>Personalizado:</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="119"/>
        <source>Import theme...</source>
        <translation>Importar tema...</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="121"/>
        <source>Theme</source>
        <translation>Tema</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="173"/>
        <source>Theme editor</source>
        <translation>Editor de tema</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="175"/>
        <source>Open Theme Editor...</source>
        <translation>Abra o Editor de Tema...</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="184"/>
        <source>Theme editor error</source>
        <translation>Erro no editor de tema</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="185"/>
        <source>The current theme JSON could not be loaded.</source>
        <translation>O tema atual JSON não pôde ser carregado.</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="285"/>
        <source>Import theme</source>
        <translation>Importar tema</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="285"/>
        <source>JSON files (*.json);;All files (*)</source>
        <translation>Arquivos JSON (*.json);;Todos os arquivos (*)</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="293"/>
        <source>Could not import theme from:
%1</source>
        <translation>Não foi possível importar o tema de:
%1</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="294"/>
        <source>Could not import theme from:
%1

%2</source>
        <translation>Não foi possível importar o tema de:
%1

%2</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="295"/>
        <source>Import failed</source>
        <translation>Falha na importação</translation>
    </message>
</context>
<context>
    <name>BookmarksDialog</name>
    <message>
        <location filename="bookmarks_dialog.cpp" line="77"/>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <location filename="bookmarks_dialog.cpp" line="109"/>
        <location filename="bookmarks_dialog.cpp" line="126"/>
        <source>Loading...</source>
        <translation>Carregando...</translation>
    </message>
    <message>
        <location filename="bookmarks_dialog.cpp" line="87"/>
        <source>Click on any image to go to the bookmark</source>
        <translation>Clique em qualquer imagem para ir para o marcador</translation>
    </message>
    <message>
        <location filename="bookmarks_dialog.cpp" line="27"/>
        <source>Lastest Page</source>
        <translation>Última Página</translation>
    </message>
</context>
<context>
    <name>ContinuousPageWidget</name>
    <message>
        <location filename="continuous_page_widget.cpp" line="272"/>
        <source>Loading page %1</source>
        <translation>Carregando página %1</translation>
    </message>
</context>
<context>
    <name>EditShortcutsDialog</name>
    <message>
        <location filename="../shortcuts_management/edit_shortcuts_dialog.cpp" line="19"/>
        <source>Restore defaults</source>
        <translation>Restaurar padrões</translation>
    </message>
    <message>
        <location filename="../shortcuts_management/edit_shortcuts_dialog.cpp" line="20"/>
        <source>To change a shortcut, double click in the key combination and type the new keys.</source>
        <translation>Para alterar um atalho, clique duas vezes na combinação de teclas e digite as novas teclas.</translation>
    </message>
    <message>
        <location filename="../shortcuts_management/edit_shortcuts_dialog.cpp" line="67"/>
        <source>Shortcuts settings</source>
        <translation>Configurações de atalhos</translation>
    </message>
    <message>
        <location filename="../shortcuts_management/edit_shortcuts_dialog.cpp" line="118"/>
        <source>Shortcut in use</source>
        <translation>Atalho em uso</translation>
    </message>
    <message>
        <location filename="../shortcuts_management/edit_shortcuts_dialog.cpp" line="118"/>
        <source>The shortcut &quot;%1&quot; is already assigned to other function</source>
        <translation>O atalho &quot;%1&quot; já está atribuído a outra função</translation>
    </message>
</context>
<context>
    <name>FileComic</name>
    <message>
        <location filename="../common/comic.cpp" line="604"/>
        <source>7z not found</source>
        <translation>7z não encontrado</translation>
    </message>
    <message>
        <location filename="../common/comic.cpp" line="490"/>
        <source>CRC error on page (%1): some of the pages will not be displayed correctly</source>
        <translation>Erro CRC na página (%1): algumas páginas não serão exibidas corretamente</translation>
    </message>
    <message>
        <location filename="../common/comic.cpp" line="497"/>
        <source>Unknown error opening the file</source>
        <translation>Erro desconhecido ao abrir o arquivo</translation>
    </message>
    <message>
        <location filename="../common/comic.cpp" line="610"/>
        <location filename="../common/comic.cpp" line="626"/>
        <source>Format not supported</source>
        <translation>Formato não suportado</translation>
    </message>
</context>
<context>
    <name>GoToDialog</name>
    <message>
        <location filename="goto_dialog.cpp" line="24"/>
        <source>Go To</source>
        <translation>Ir Para</translation>
    </message>
    <message>
        <location filename="goto_dialog.cpp" line="52"/>
        <source>Go to...</source>
        <translation>Ir para...</translation>
    </message>
    <message>
        <location filename="goto_dialog.cpp" line="40"/>
        <location filename="goto_dialog.cpp" line="70"/>
        <source>Total pages : </source>
        <translation>Total de páginas : </translation>
    </message>
    <message>
        <location filename="goto_dialog.cpp" line="26"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="goto_dialog.cpp" line="16"/>
        <source>Page : </source>
        <translation>Página : </translation>
    </message>
</context>
<context>
    <name>GoToFlowToolBar</name>
    <message>
        <location filename="goto_flow_toolbar.cpp" line="32"/>
        <source>Page : </source>
        <translation>Página : </translation>
    </message>
</context>
<context>
    <name>HelpAboutDialog</name>
    <message>
        <location filename="../custom_widgets/help_about_dialog.cpp" line="28"/>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <location filename="../custom_widgets/help_about_dialog.cpp" line="31"/>
        <source>System info</source>
        <translation>Informações do sistema</translation>
    </message>
    <message>
        <location filename="../custom_widgets/help_about_dialog.cpp" line="40"/>
        <source>Changelog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../custom_widgets/help_about_dialog.cpp" line="25"/>
        <source>About</source>
        <translation>Sobre</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <location filename="options_dialog.cpp" line="38"/>
        <source>My comics path</source>
        <translation>Meu caminho de quadrinhos</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="78"/>
        <source>&quot;Go to flow&quot; size</source>
        <translation>Tamanho de &quot;Ir para Comic Flow&quot;</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="310"/>
        <source>Appearance</source>
        <translation>Aparência</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="326"/>
        <source>Options</source>
        <translation>Opções</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="45"/>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="47"/>
        <source>Application language</source>
        <translation>Idioma do aplicativo</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="49"/>
        <source>System default</source>
        <translation>Padrão do sistema</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="100"/>
        <source>Clear</source>
        <translation>Claro</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="342"/>
        <source>Comics directory</source>
        <translation>Diretório de quadrinhos</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="317"/>
        <source>Restart is needed</source>
        <translation>Reiniciar é necessário</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="58"/>
        <source>Display</source>
        <translation>Mostrar</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="60"/>
        <source>Show time in current page information label</source>
        <translation>Mostrar hora no rótulo de informações da página atual</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="64"/>
        <source>Magnifying glass</source>
        <translation>Lupa</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="66"/>
        <source>Circular magnifying glass</source>
        <translation>Lupa circular</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="67"/>
        <source>Draw a ring around the circular magnifying glass</source>
        <translation>Desenhar um anel ao redor da lupa circular</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="70"/>
        <source>Ease cursor movement toward the edges</source>
        <translation>Suavizar o movimento do cursor em direção às bordas</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="96"/>
        <source>Background color</source>
        <translation>Cor de fundo</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="99"/>
        <source>Choose</source>
        <translation>Escolher</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="108"/>
        <source>Scroll behaviour</source>
        <translation>Comportamento de rolagem</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="111"/>
        <source>Disable scroll animations and smooth scrolling</source>
        <translation>Desative animações de rolagem e rolagem suave</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="112"/>
        <source>Do not turn page using scroll</source>
        <translation>Não vire a página usando scroll</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="113"/>
        <source>Use single scroll step to turn page</source>
        <translation>Use uma única etapa de rolagem para virar a página</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="121"/>
        <source>Mouse mode</source>
        <translation>Modo mouse</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="124"/>
        <source>Only Back/Forward buttons can turn pages</source>
        <translation>Apenas os botões Voltar/Avançar podem virar páginas</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="125"/>
        <source>Use the Left/Right buttons to turn pages.</source>
        <translation>Use os botões Esquerda/Direita para virar as páginas.</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="126"/>
        <source>Click left or right half of the screen to turn pages.</source>
        <translation>Clique na metade esquerda ou direita da tela para virar as páginas.</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="134"/>
        <source>Escape key</source>
        <translation>Tecla Escape</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="137"/>
        <source>Quit the reader</source>
        <translation>Sair do leitor</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="138"/>
        <source>Cancel the active mode</source>
        <translation>Cancelar o modo ativo</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="140"/>
        <source>Escape closes the reader, even while a mode is active.</source>
        <translation>A tecla Escape fecha o leitor, mesmo quando existe um modo ativo.</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="145"/>
        <source>Escape cancels the first of these that is active:

1. Magnifying glass
2. Dictionary
3. Go to page bar
4. Fullscreen

If none is active, Escape does nothing.</source>
        <extracomment>Tooltip listing the order in which modes are cancelled. Only the first active mode in the list is cancelled per Escape keypress.</extracomment>
        <translation>A tecla Escape cancela o primeiro destes modos que estiver ativo:

1. Lupa
2. Dicionário
3. Barra Ir para a página
4. Ecrã inteiro

Se nenhum estiver ativo, a tecla Escape não faz nada.</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="176"/>
        <source>Use software-rendered &quot;go to flow&quot; (requires restart)</source>
        <translation>Usar &quot;Ir para Comic Flow&quot; renderizado por software (requer reinicialização)</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="177"/>
        <source>Use a simple horizontal list of page thumbnails instead of the GPU-rendered 3D flow. Enable this if reading is not smooth on your system.</source>
        <translation>Use uma lista horizontal simples de miniaturas de páginas em vez do fluxo 3D renderizado pela GPU. Ative esta opção se a leitura não for fluida no seu sistema.</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="180"/>
        <source>Quick Navigation Mode</source>
        <translation>Modo de navegação rápida</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="181"/>
        <source>Disable mouse over activation</source>
        <translation>Desativar ativação do mouse sobre</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="223"/>
        <source>Brightness</source>
        <translation>Brilho</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="224"/>
        <source>Contrast</source>
        <translation>Contraste</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="225"/>
        <source>Gamma</source>
        <translation>Gama</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="229"/>
        <source>Reset</source>
        <translation>Reiniciar</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="234"/>
        <source>Image options</source>
        <translation>Opções de imagem</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="238"/>
        <source>Fit options</source>
        <translation>Opções de ajuste</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="240"/>
        <source>Enlarge images to fit width/height</source>
        <translation>Amplie as imagens para caber na largura/altura</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="251"/>
        <source>Double Page options</source>
        <translation>Opções de página dupla</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="253"/>
        <source>Show covers as single page</source>
        <translation>Mostrar capas como página única</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="259"/>
        <source>Show book fold shadow</source>
        <translation>Mostrar sombra na dobra do livro</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="271"/>
        <source>Scaling</source>
        <translation>Dimensionamento</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="273"/>
        <source>Scaling method</source>
        <translation>Método de dimensionamento</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="275"/>
        <source>Nearest (fast, low quality)</source>
        <translation>Mais próximo (rápido, baixa qualidade)</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="276"/>
        <source>Bilinear</source>
        <translation>Interpola??o bilinear</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="277"/>
        <source>Lanczos (better quality)</source>
        <translation>Lanczos (melhor qualidade)</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="307"/>
        <source>General</source>
        <translation>Em geral</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="308"/>
        <source>Page Flow</source>
        <translation>Fluxo de página</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="309"/>
        <source>Image adjustment</source>
        <translation>Ajuste de imagem</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../common/exit_check.cpp" line="13"/>
        <source>7z lib not found</source>
        <translation>Biblioteca 7z não encontrada</translation>
    </message>
    <message>
        <location filename="../common/exit_check.cpp" line="13"/>
        <source>unable to load 7z lib from ./utils</source>
        <translation>não é possível carregar 7z lib de ./utils</translation>
    </message>
    <message>
        <location filename="../common/yacreader_global_gui.cpp" line="95"/>
        <source>Select custom cover</source>
        <translation>Selecione a capa personalizada</translation>
    </message>
    <message>
        <location filename="../common/yacreader_global_gui.cpp" line="95"/>
        <source>Images (%1)</source>
        <translation>Imagens (%1)</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_repository.cpp" line="152"/>
        <source>The file could not be read or is not valid JSON.</source>
        <translation>O arquivo não pôde ser lido ou não é JSON válido.</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_repository.cpp" line="161"/>
        <source>This theme is for %1, not %2.</source>
        <translation>Este tema é para %1, não %2.</translation>
    </message>
</context>
<context>
    <name>ThemeEditorDialog</name>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="59"/>
        <source>Theme Editor</source>
        <translation>Editor de Tema</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="63"/>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="64"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="65"/>
        <source>i</source>
        <translation>eu</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="69"/>
        <source>Expand all</source>
        <translation>Expandir tudo</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="70"/>
        <source>Collapse all</source>
        <translation>Recolher tudo</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="71"/>
        <source>Hold to flash the selected value in the UI (magenta / toggled / 0↔10). Releases restore the original.</source>
        <translation>Segure para piscar o valor selecionado na UI (magenta/alternado/0↔10). Os lançamentos restauram o original.</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="76"/>
        <source>Search…</source>
        <translation>Procurar…</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="94"/>
        <source>Light</source>
        <translation>Luz</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="95"/>
        <source>Dark</source>
        <translation>Escuro</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="98"/>
        <source>ID:</source>
        <translation>EU IA:</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="99"/>
        <source>Display name:</source>
        <translation>Nome de exibição:</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="100"/>
        <source>Variant:</source>
        <translation>Variante:</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="102"/>
        <source>Theme info</source>
        <translation>Informações do tema</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="125"/>
        <source>Parameter</source>
        <translation>Parâmetro</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="125"/>
        <source>Value</source>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="149"/>
        <source>Save and apply</source>
        <translation>Salvar e aplicar</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="150"/>
        <source>Export to file...</source>
        <translation>Exportar para arquivo...</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="151"/>
        <source>Load from file...</source>
        <translation>Carregar do arquivo...</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="152"/>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="209"/>
        <source>Double-click to edit color</source>
        <translation>Clique duas vezes para editar a cor</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="211"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="264"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="265"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="459"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="464"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="495"/>
        <source>true</source>
        <translation>verdadeiro</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="211"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="265"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="464"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="495"/>
        <source>false</source>
        <translation>falso</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="214"/>
        <source>Double-click to toggle</source>
        <translation>Clique duas vezes para alternar</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="218"/>
        <source>Double-click to edit value</source>
        <translation>Clique duas vezes para editar o valor</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="232"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="280"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="285"/>
        <source>Edit: %1</source>
        <translation>Editar: %1</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="399"/>
        <source>Save theme</source>
        <translation>Salvar tema</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="399"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="414"/>
        <source>JSON files (*.json);;All files (*)</source>
        <translation>Arquivos JSON (*.json);;Todos os arquivos (*)</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="405"/>
        <source>Save failed</source>
        <translation>Falha ao salvar</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="405"/>
        <source>Could not open file for writing:
%1</source>
        <translation>Não foi possível abrir o arquivo para gravação:
%1</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="414"/>
        <source>Load theme</source>
        <translation>Carregar tema</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="420"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="427"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="431"/>
        <source>Load failed</source>
        <translation>Falha no carregamento</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="420"/>
        <source>Could not open file:
%1</source>
        <translation>Não foi possível abrir o arquivo:
%1</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="427"/>
        <source>Invalid JSON:
%1</source>
        <translation>JSON inválido:
%1</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="431"/>
        <source>Expected a JSON object.</source>
        <translation>Esperava um objeto JSON.</translation>
    </message>
</context>
<context>
    <name>Viewer</name>
    <message>
        <location filename="viewer.cpp" line="125"/>
        <location filename="viewer.cpp" line="1815"/>
        <source>Press &apos;O&apos; to open comic.</source>
        <translation>Pressione &apos;O&apos; para abrir um quadrinho.</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="1832"/>
        <source>Loading...please wait!</source>
        <translation>Carregando... por favor, aguarde!</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="372"/>
        <source>Not found</source>
        <translation>Não encontrado</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="372"/>
        <source>Comic not found</source>
        <translation>Quadrinho não encontrado</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="378"/>
        <source>Error opening comic</source>
        <translation>Erro ao abrir quadrinho</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="384"/>
        <source>CRC Error</source>
        <translation>Erro CRC</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="1843"/>
        <source>Page not available!</source>
        <translation>Página não disponível!</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="2181"/>
        <source>Cover!</source>
        <translation>Cobrir!</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="2195"/>
        <source>Last page!</source>
        <translation>Última página!</translation>
    </message>
</context>
<context>
    <name>YACReader3DFlowConfigWidget</name>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="19"/>
        <source>Presets:</source>
        <translation>Predefinições:</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="21"/>
        <source>Classic look</source>
        <translation>Aparência clássica</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="24"/>
        <source>Stripe look</source>
        <translation>Olhar lista</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="27"/>
        <source>Overlapped Stripe look</source>
        <translation>Olhar lista sobreposta</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="30"/>
        <source>Modern look</source>
        <translation>Aparência moderna</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="33"/>
        <source>Roulette look</source>
        <translation>Aparência de roleta</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="77"/>
        <source>Show advanced settings</source>
        <translation>Mostrar configurações avançadas</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="86"/>
        <source>Custom:</source>
        <translation>Personalizado:</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="89"/>
        <source>View angle</source>
        <translation>Ângulo de visão</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="95"/>
        <source>Position</source>
        <translation>Posição</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="101"/>
        <source>Cover gap</source>
        <translation>Cubra a lacuna</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="107"/>
        <source>Central gap</source>
        <translation>Lacuna central</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="113"/>
        <source>Zoom</source>
        <translation>Amplia??o</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="119"/>
        <source>Y offset</source>
        <translation>Deslocamento Y</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="125"/>
        <source>Z offset</source>
        <translation>Deslocamento Z</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="131"/>
        <source>Cover Angle</source>
        <translation>Ângulo de cobertura</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="137"/>
        <source>Visibility</source>
        <translation>Visibilidade</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="143"/>
        <source>Light</source>
        <translation>Luz</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="149"/>
        <source>Max angle</source>
        <translation>Ângulo máximo</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="181"/>
        <source>Low Performance</source>
        <translation>Baixo desempenho</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="183"/>
        <source>High Performance</source>
        <translation>Alto desempenho</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="194"/>
        <source>Use VSync (improve the image quality in fullscreen mode, worse performance)</source>
        <translation>Use VSync (melhora a qualidade da imagem em modo tela cheia, pior desempenho)</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="202"/>
        <source>Performance:</source>
        <translation>Desempenho:</translation>
    </message>
</context>
<context>
    <name>YACReader::MainWindowViewer</name>
    <message>
        <location filename="main_window_viewer.cpp" line="327"/>
        <source>&amp;Open</source>
        <translation>&amp;Abrir</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="328"/>
        <source>Open a comic</source>
        <translation>Abrir um quadrinho</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="334"/>
        <source>New instance</source>
        <translation>Nova instância</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="353"/>
        <source>Open Folder</source>
        <translation>Abrir Pasta</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="354"/>
        <source>Open image folder</source>
        <translation>Abra a pasta de imagens</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="359"/>
        <source>Open latest comic</source>
        <translation>Abra o último quadrinho</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="360"/>
        <source>Open the latest comic opened in the previous reading session</source>
        <translation>Abra o último quadrinho aberto na sessão de leitura anterior</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="372"/>
        <source>Clear</source>
        <translation>Claro</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="373"/>
        <source>Clear open recent list</source>
        <translation>Limpar lista recente aberta</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="376"/>
        <source>Save</source>
        <translation>Salvar</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="377"/>
        <location filename="main_window_viewer.cpp" line="1097"/>
        <location filename="main_window_viewer.cpp" line="1108"/>
        <location filename="main_window_viewer.cpp" line="1119"/>
        <source>Save current page</source>
        <translation>Salvar página atual</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="382"/>
        <location filename="main_window_viewer.cpp" line="1124"/>
        <location filename="main_window_viewer.cpp" line="1138"/>
        <location filename="main_window_viewer.cpp" line="1149"/>
        <location filename="main_window_viewer.cpp" line="1167"/>
        <source>Extract page(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="383"/>
        <source>Extract page(s) from the original source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="388"/>
        <source>Previous Comic</source>
        <translation>Quadrinho Anterior</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="389"/>
        <location filename="main_window_viewer.cpp" line="1915"/>
        <location filename="main_window_viewer.cpp" line="1919"/>
        <source>Open previous comic</source>
        <translation>Abrir quadrinho anterior</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="394"/>
        <source>Next Comic</source>
        <translation>Próximo Quadrinho</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="395"/>
        <location filename="main_window_viewer.cpp" line="1914"/>
        <location filename="main_window_viewer.cpp" line="1920"/>
        <source>Open next comic</source>
        <translation>Abrir próximo quadrinho</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="400"/>
        <source>&amp;Previous</source>
        <translation>A&amp;nterior</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="402"/>
        <location filename="main_window_viewer.cpp" line="1917"/>
        <location filename="main_window_viewer.cpp" line="1921"/>
        <source>Go to previous page</source>
        <translation>Ir para a página anterior</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="407"/>
        <source>&amp;Next</source>
        <translation>&amp;Próxima</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="409"/>
        <location filename="main_window_viewer.cpp" line="1916"/>
        <location filename="main_window_viewer.cpp" line="1922"/>
        <source>Go to next page</source>
        <translation>Ir para a próxima página</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="414"/>
        <source>Fit Height</source>
        <translation>Ajustar Altura</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="415"/>
        <source>Fit image to height</source>
        <translation>Ajustar imagem à altura</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="421"/>
        <source>Fit Width</source>
        <translation>Ajustar à Largura</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="422"/>
        <source>Fit image to width</source>
        <translation>Ajustar imagem à largura</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="428"/>
        <source>Show full size</source>
        <translation>Mostrar tamanho grande</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="435"/>
        <source>Fit to page</source>
        <translation>Ajustar à página</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="441"/>
        <source>Continuous scroll</source>
        <translation>Rolagem contínua</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="442"/>
        <source>Switch to continuous scroll mode</source>
        <translation>Mudar para o modo de rolagem contínua</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="476"/>
        <source>Reset zoom</source>
        <translation>Redefinir zoom</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="481"/>
        <source>Show zoom slider</source>
        <translation>Mostrar controle deslizante de zoom</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="483"/>
        <source>Zoom+</source>
        <translation>Ampliar</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="488"/>
        <source>Zoom-</source>
        <translation>Reduzir</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="493"/>
        <source>Rotate image to the left</source>
        <translation>Girar imagem à esquerda</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="498"/>
        <source>Rotate image to the right</source>
        <translation>Girar imagem à direita</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="503"/>
        <source>Double page mode</source>
        <translation>Modo dupla página</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="504"/>
        <source>Switch to double page mode</source>
        <translation>Alternar para o modo dupla página</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="512"/>
        <source>Double page manga mode</source>
        <translation>Modo mangá de página dupla</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="513"/>
        <source>Reverse reading order in double page mode</source>
        <translation>Ordem de leitura inversa no modo de página dupla</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="521"/>
        <source>Go To</source>
        <translation>Ir Para</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="522"/>
        <source>Go to page ...</source>
        <translation>Ir para a página...</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="527"/>
        <source>Options</source>
        <translation>Opções</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="528"/>
        <source>YACReader options</source>
        <translation>Opções do YACReader</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="534"/>
        <location filename="main_window_viewer.cpp" line="841"/>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="535"/>
        <source>Help, About YACReader</source>
        <translation>Ajuda, Sobre o YACReader</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="540"/>
        <source>Magnifying glass</source>
        <translation>Lupa</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="541"/>
        <source>Switch Magnifying glass</source>
        <translation>Alternar Lupa</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="547"/>
        <source>Set bookmark</source>
        <translation>Definir marcador</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="548"/>
        <source>Set a bookmark on the current page</source>
        <translation>Definir um marcador na página atual</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="556"/>
        <source>Show bookmarks</source>
        <translation>Mostrar marcadores</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="557"/>
        <source>Show the bookmarks of the current comic</source>
        <translation>Mostrar os marcadores do quadrinho atual</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="562"/>
        <source>Show keyboard shortcuts</source>
        <translation>Mostrar teclas de atalhos</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="567"/>
        <source>Show Info</source>
        <translation>Mostrar Informações</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="575"/>
        <source>Escape</source>
        <translation>Escape</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="578"/>
        <source>Escape key: quit, or cancel the active mode</source>
        <translation>Tecla Escape: sair ou cancelar o modo ativo</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="583"/>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="586"/>
        <source>Show Dictionary</source>
        <translation>Mostrar dicionário</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="592"/>
        <source>Show go to flow</source>
        <translation>Mostrar &quot;Ir para Comic Flow&quot;</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="597"/>
        <source>Edit shortcuts</source>
        <translation>Editar atalhos</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="618"/>
        <source>&amp;File</source>
        <translation>&amp;Arquivo</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="633"/>
        <location filename="main_window_viewer.cpp" line="795"/>
        <source>Open recent</source>
        <translation>Abrir recente</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="783"/>
        <source>File</source>
        <translation>Arquivo</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="805"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="809"/>
        <source>View</source>
        <translation>Visualizar</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="826"/>
        <source>Go</source>
        <translation>Ir</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="834"/>
        <source>Window</source>
        <translation>Janela</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="951"/>
        <source>Open Comic</source>
        <translation>Abrir Quadrinho</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="950"/>
        <source>Comic files</source>
        <translation>Arquivos de quadrinhos</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1038"/>
        <source>Open folder</source>
        <translation>Abrir pasta</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1351"/>
        <location filename="main_window_viewer.cpp" line="1364"/>
        <source>Comics</source>
        <translation>Quadrinhos</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1375"/>
        <source>Toggle fullscreen mode</source>
        <translation>Alternar modo de tela cheia</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1378"/>
        <source>Hide/show toolbar</source>
        <translation>Ocultar/mostrar barra de ferramentas</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1352"/>
        <location filename="main_window_viewer.cpp" line="1381"/>
        <source>General</source>
        <translation>Em geral</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1400"/>
        <source>Size up magnifying glass</source>
        <translation>Dimensione a lupa</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1403"/>
        <source>Size down magnifying glass</source>
        <translation>Diminuir o tamanho da lupa</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1406"/>
        <source>Zoom in magnifying glass</source>
        <translation>Zoom na lupa</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1409"/>
        <source>Zoom out magnifying glass</source>
        <translation>Diminuir o zoom da lupa</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1412"/>
        <source>Reset magnifying glass</source>
        <translation>Redefinir lupa</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1353"/>
        <location filename="main_window_viewer.cpp" line="1419"/>
        <source>Magnifiying glass</source>
        <translation>Lupa</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1426"/>
        <source>Toggle between fit to width and fit to height</source>
        <translation>Alternar entre ajustar à largura e ajustar à altura</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1354"/>
        <location filename="main_window_viewer.cpp" line="1430"/>
        <source>Page adjustement</source>
        <translation>Ajuste de página</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1108"/>
        <source>The current page is not ready. Please try again later.</source>
        <translation>A página atual ainda não está pronta. Por favor, tente novamente mais tarde.</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1113"/>
        <source>Overwrite file?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1113"/>
        <source>The file already exists. Do you want to overwrite it?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1119"/>
        <source>The current page could not be saved.</source>
        <translation>Não foi possível guardar a página atual.</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1138"/>
        <source>The selected pages are not ready. Please try again later.</source>
        <translation>As páginas selecionadas ainda não estão prontas. Por favor, tente novamente mais tarde.</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1149"/>
        <source>The current page could not be extracted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1154"/>
        <source>Overwrite files?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1154"/>
        <source>Some files already exist. Do you want to overwrite them?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1167"/>
        <source>Some pages could not be extracted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1448"/>
        <source>Autoscroll down</source>
        <translation>Rolagem automática para baixo</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1451"/>
        <source>Autoscroll up</source>
        <translation>Rolagem automática para cima</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1454"/>
        <source>Autoscroll forward, horizontal first</source>
        <translation>Rolagem automática para frente, horizontal primeiro</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1458"/>
        <source>Autoscroll backward, horizontal first</source>
        <translation>Rolagem automática para trás, horizontal primeiro</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1462"/>
        <source>Autoscroll forward, vertical first</source>
        <translation>Rolagem automática para frente, vertical primeiro</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1466"/>
        <source>Autoscroll backward, vertical first</source>
        <translation>Rolagem automática para trás, vertical primeiro</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1470"/>
        <source>Move down</source>
        <translation>Mover para baixo</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1473"/>
        <source>Move up</source>
        <translation>Subir</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1476"/>
        <source>Move left</source>
        <translation>Mover para a esquerda</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1479"/>
        <source>Move right</source>
        <translation>Mover para a direita</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1482"/>
        <source>Go to the first page</source>
        <translation>Vá para a primeira página</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1485"/>
        <source>Go to the last page</source>
        <translation>Ir para a última página</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1488"/>
        <source>Offset double page to the left</source>
        <translation>Deslocar página dupla para a esquerda</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1490"/>
        <source>Offset double page to the right</source>
        <translation>Deslocar página dupla para a direita</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1355"/>
        <location filename="main_window_viewer.cpp" line="1508"/>
        <source>Reading</source>
        <translation>Leitura</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1557"/>
        <source>There is a new version available</source>
        <translation>Há uma nova versão disponível</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1558"/>
        <source>Do you want to download the new version?</source>
        <translation>Você deseja baixar a nova versão?</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1561"/>
        <source>Remind me in 14 days</source>
        <translation>Lembre-me em 14 dias</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1562"/>
        <source>Not now</source>
        <translation>Agora não</translation>
    </message>
</context>
<context>
    <name>YACReader::WhatsNewDialog</name>
    <message>
        <location filename="../custom_widgets/whats_new_dialog.cpp" line="182"/>
        <source>Release notes are not available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../custom_widgets/whats_new_dialog.cpp" line="238"/>
        <source>Previous versions</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>YACReaderFieldEdit</name>
    <message>
        <location filename="../custom_widgets/yacreader_field_edit.cpp" line="9"/>
        <location filename="../custom_widgets/yacreader_field_edit.cpp" line="28"/>
        <source>Click to overwrite</source>
        <translation>Clique para substituir</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_field_edit.cpp" line="11"/>
        <source>Restore to default</source>
        <translation>Restaurar para o padrão</translation>
    </message>
</context>
<context>
    <name>YACReaderFieldPlainTextEdit</name>
    <message>
        <location filename="../custom_widgets/yacreader_field_plain_text_edit.cpp" line="9"/>
        <location filename="../custom_widgets/yacreader_field_plain_text_edit.cpp" line="19"/>
        <location filename="../custom_widgets/yacreader_field_plain_text_edit.cpp" line="44"/>
        <location filename="../custom_widgets/yacreader_field_plain_text_edit.cpp" line="50"/>
        <source>Click to overwrite</source>
        <translation>Clique para substituir</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_field_plain_text_edit.cpp" line="10"/>
        <source>Restore to default</source>
        <translation>Restaurar para o padrão</translation>
    </message>
</context>
<context>
    <name>YACReaderOptionsDialog</name>
    <message>
        <location filename="../custom_widgets/yacreader_options_dialog.cpp" line="21"/>
        <source>Save</source>
        <translation>Salvar</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_options_dialog.cpp" line="22"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_options_dialog.cpp" line="29"/>
        <source>Keyboard shortcuts</source>
        <translation>Atalhos de teclado</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_options_dialog.cpp" line="31"/>
        <source>Customize the keyboard shortcuts used by the application.</source>
        <translation>Personalize os atalhos de teclado utilizados pela aplicação.</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_options_dialog.cpp" line="32"/>
        <source>Edit shortcuts</source>
        <translation>Editar atalhos</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_options_dialog.cpp" line="27"/>
        <source>Shortcuts</source>
        <translation>Atalhos</translation>
    </message>
</context>
<context>
    <name>YACReaderSlider</name>
    <message>
        <location filename="width_slider.cpp" line="52"/>
        <source>Reset</source>
        <translation>Reiniciar</translation>
    </message>
</context>
<context>
    <name>YACReaderTranslator</name>
    <message>
        <location filename="translator.cpp" line="40"/>
        <source>YACReader translator</source>
        <translation>Tradutor YACReader</translation>
    </message>
    <message>
        <location filename="translator.cpp" line="80"/>
        <location filename="translator.cpp" line="186"/>
        <source>Translation</source>
        <translation>Tradução</translation>
    </message>
    <message>
        <location filename="translator.cpp" line="100"/>
        <source>clear</source>
        <translation>claro</translation>
    </message>
    <message>
        <location filename="translator.cpp" line="195"/>
        <source>Service not available</source>
        <translation>Serviço não disponível</translation>
    </message>
</context>
</TS>
