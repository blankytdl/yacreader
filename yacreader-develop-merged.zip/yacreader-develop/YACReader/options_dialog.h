#ifndef __OPTIONS_DIALOG_H
#define __OPTIONS_DIALOG_H

#include "themable.h"
#include "yacreader_options_dialog.h"

#include <QPointer>

class QComboBox;
class QDialog;
class QLabel;
class QLineEdit;
class QPushButton;
class QSlider;
class QPushButton;
class QRadioButton;
class YACReaderSpinSliderWidget;

class OptionsDialog : public YACReaderOptionsDialog, protected Themable
{
    Q_OBJECT
public:
    OptionsDialog(QWidget *parent = nullptr);

protected:
    void applyTheme(const Theme &theme) override;

private:
    // QLabel * pathLabel;
    QLineEdit *pathEdit;
    QPushButton *pathFindButton;
    QComboBox *languageCombo;

    QCheckBox *showTimeInInformationLabel;

    QCheckBox *circularMagnifyingGlass;
    QCheckBox *magnifyingGlassRing;
    QCheckBox *magnifyingGlassEdgeEase;

    QCheckBox *useSoftwareGoToFlow;
    QCheckBox *quickNavi;
    QCheckBox *disableShowOnMouseOver;
    QCheckBox *scaleCheckbox;
    QCheckBox *coverSPCheckBox;
    QCheckBox *doublePageShadowCheckBox;

    QLabel *magGlassSizeLabel;

    QLabel *zoomLevel;

    // QLabel * slideSizeLabel;
    QSlider *slideSize;

    // QLabel * fitToWidthRatioLabel;
    // QSlider * fitToWidthRatioS;

    QLabel *backgroundColor;
    QPushButton *selectBackgroundColorButton;
    QPushButton *clearBackgroundColorButton;

    QCheckBox *doNotTurnPageOnScroll;
    QCheckBox *useSingleScrollStepToTurnPage;
    QCheckBox *disableScrollAnimations;

    YACReaderSpinSliderWidget *brightnessS;

    YACReaderSpinSliderWidget *contrastS;

    YACReaderSpinSliderWidget *gammaS;

    QColor currentColor;
    bool backgroundColorFollowsTheme = true;

    QComboBox *scalingMethodCombo;

    QRadioButton *normalMouseModeRadioButton;
    QRadioButton *leftRightNavigationMouseModeRadioButton;
    QRadioButton *hotAreasMouseModeRadioButton;

    QRadioButton *escapeQuitsRadioButton;
    QRadioButton *escapeCancelsModeRadioButton;

public slots:
    void saveOptions() override;
    void restoreOptions(QSettings *settings) override;
    void findFolder();
    void showColorDialog();
    void updateColor(const QColor &color);
    // void fitToWidthRatio(int value);
    void brightnessChanged(int value);
    void contrastChanged(int value);
    void gammaChanged(int value);
    void resetImageConfig();
    void show();
    void setFilters(int brightness, int contrast, int gamma);
    void clearBackgroundColor();

signals:
    void changedOptions();
    void changedImageOptions();
    void changedFilters(int brightness, int contrast, int gamma);
    // void fitToWidthRatioChanged(float ratio);
};

#endif
