<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="nl_NL">
<context>
    <name>ActionsShortcutsModel</name>
    <message>
        <location filename="../shortcuts_management/actions_shortcuts_model.cpp" line="74"/>
        <source>None</source>
        <translation>Geen</translation>
    </message>
</context>
<context>
    <name>AppearanceTabWidget</name>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="38"/>
        <source>Color scheme</source>
        <translation>Kleurenschema</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="46"/>
        <source>System</source>
        <translation>Systeem</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="47"/>
        <source>Light</source>
        <translation>Licht</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="48"/>
        <source>Dark</source>
        <translation>Donker</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="49"/>
        <source>Custom</source>
        <translation>Aangepast</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="105"/>
        <source>Remove</source>
        <translation>Verwijderen</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="107"/>
        <source>Remove this user-imported theme</source>
        <translation>Verwijder dit door de gebruiker geïmporteerde thema</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="115"/>
        <source>Light:</source>
        <translation>Licht:</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="116"/>
        <source>Dark:</source>
        <translation>Donker:</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="117"/>
        <source>Custom:</source>
        <translation>Aangepast:</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="119"/>
        <source>Import theme...</source>
        <translation>Thema importeren...</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="121"/>
        <source>Theme</source>
        <translation>Thema</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="173"/>
        <source>Theme editor</source>
        <translation>Thema-editor</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="175"/>
        <source>Open Theme Editor...</source>
        <translation>Thema-editor openen...</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="184"/>
        <source>Theme editor error</source>
        <translation>Fout in de thema-editor</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="185"/>
        <source>The current theme JSON could not be loaded.</source>
        <translation>De huidige thema-JSON kan niet worden geladen.</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="285"/>
        <source>Import theme</source>
        <translation>Thema importeren</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="285"/>
        <source>JSON files (*.json);;All files (*)</source>
        <translation>JSON-bestanden (*.json);;Alle bestanden (*)</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="293"/>
        <source>Could not import theme from:
%1</source>
        <translation>Kan thema niet importeren uit:
%1</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="294"/>
        <source>Could not import theme from:
%1

%2</source>
        <translation>Kan thema niet importeren uit:
%1

%2</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="295"/>
        <source>Import failed</source>
        <translation>Importeren is mislukt</translation>
    </message>
</context>
<context>
    <name>BookmarksDialog</name>
    <message>
        <location filename="bookmarks_dialog.cpp" line="77"/>
        <source>Close</source>
        <translation>Sluiten</translation>
    </message>
    <message>
        <location filename="bookmarks_dialog.cpp" line="109"/>
        <location filename="bookmarks_dialog.cpp" line="126"/>
        <source>Loading...</source>
        <translation>Inladen...</translation>
    </message>
    <message>
        <location filename="bookmarks_dialog.cpp" line="87"/>
        <source>Click on any image to go to the bookmark</source>
        <translation>Klik op een afbeelding om naar de bladwijzer te gaan </translation>
    </message>
    <message>
        <location filename="bookmarks_dialog.cpp" line="27"/>
        <source>Lastest Page</source>
        <translation>Laatste Pagina</translation>
    </message>
</context>
<context>
    <name>ContinuousPageWidget</name>
    <message>
        <location filename="continuous_page_widget.cpp" line="272"/>
        <source>Loading page %1</source>
        <translation>Pagina laden %1</translation>
    </message>
</context>
<context>
    <name>EditShortcutsDialog</name>
    <message>
        <location filename="../shortcuts_management/edit_shortcuts_dialog.cpp" line="19"/>
        <source>Restore defaults</source>
        <translation>Standaardwaarden herstellen</translation>
    </message>
    <message>
        <location filename="../shortcuts_management/edit_shortcuts_dialog.cpp" line="20"/>
        <source>To change a shortcut, double click in the key combination and type the new keys.</source>
        <translation>Om een ​​snelkoppeling te wijzigen, dubbelklikt u op de toetsencombinatie en typt u de nieuwe toetsen.</translation>
    </message>
    <message>
        <location filename="../shortcuts_management/edit_shortcuts_dialog.cpp" line="67"/>
        <source>Shortcuts settings</source>
        <translation>Instellingen voor snelkoppelingen</translation>
    </message>
    <message>
        <location filename="../shortcuts_management/edit_shortcuts_dialog.cpp" line="118"/>
        <source>Shortcut in use</source>
        <translation>Snelkoppeling in gebruik</translation>
    </message>
    <message>
        <location filename="../shortcuts_management/edit_shortcuts_dialog.cpp" line="118"/>
        <source>The shortcut &quot;%1&quot; is already assigned to other function</source>
        <translation>De sneltoets &quot;%1&quot; is al aan een andere functie toegewezen</translation>
    </message>
</context>
<context>
    <name>FileComic</name>
    <message>
        <location filename="../common/comic.cpp" line="604"/>
        <source>7z not found</source>
        <translation>7Z Archiefbestand niet gevonden</translation>
    </message>
    <message>
        <location filename="../common/comic.cpp" line="490"/>
        <source>CRC error on page (%1): some of the pages will not be displayed correctly</source>
        <translation>CRC-fout op pagina (%1): sommige pagina&apos;s worden niet correct weergegeven</translation>
    </message>
    <message>
        <location filename="../common/comic.cpp" line="497"/>
        <source>Unknown error opening the file</source>
        <translation>Onbekende fout bij het openen van het bestand</translation>
    </message>
    <message>
        <location filename="../common/comic.cpp" line="610"/>
        <location filename="../common/comic.cpp" line="626"/>
        <source>Format not supported</source>
        <translation>Formaat niet ondersteund</translation>
    </message>
</context>
<context>
    <name>GoToDialog</name>
    <message>
        <location filename="goto_dialog.cpp" line="24"/>
        <source>Go To</source>
        <translation>Ga Naar</translation>
    </message>
    <message>
        <location filename="goto_dialog.cpp" line="52"/>
        <source>Go to...</source>
        <translation>Ga naar...</translation>
    </message>
    <message>
        <location filename="goto_dialog.cpp" line="40"/>
        <location filename="goto_dialog.cpp" line="70"/>
        <source>Total pages : </source>
        <translation>Totaal aantal pagina&apos;s : </translation>
    </message>
    <message>
        <location filename="goto_dialog.cpp" line="26"/>
        <source>Cancel</source>
        <translation>Annuleren</translation>
    </message>
    <message>
        <location filename="goto_dialog.cpp" line="16"/>
        <source>Page : </source>
        <translation>Pagina : </translation>
    </message>
</context>
<context>
    <name>GoToFlowToolBar</name>
    <message>
        <location filename="goto_flow_toolbar.cpp" line="32"/>
        <source>Page : </source>
        <translation>Pagina : </translation>
    </message>
</context>
<context>
    <name>HelpAboutDialog</name>
    <message>
        <location filename="../custom_widgets/help_about_dialog.cpp" line="28"/>
        <source>Help</source>
        <translation>Hulp</translation>
    </message>
    <message>
        <location filename="../custom_widgets/help_about_dialog.cpp" line="31"/>
        <source>System info</source>
        <translation>Systeeminformatie</translation>
    </message>
    <message>
        <location filename="../custom_widgets/help_about_dialog.cpp" line="40"/>
        <source>Changelog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../custom_widgets/help_about_dialog.cpp" line="25"/>
        <source>About</source>
        <translation>Over</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <location filename="options_dialog.cpp" line="225"/>
        <source>Gamma</source>
        <translation>Gammawaarde</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="229"/>
        <source>Reset</source>
        <translation>Standaardwaarden terugzetten</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="38"/>
        <source>My comics path</source>
        <translation>Pad naar mijn strips</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="259"/>
        <source>Show book fold shadow</source>
        <translation>Schaduw bij de boekvouw weergeven</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="271"/>
        <source>Scaling</source>
        <translation>Schalen</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="273"/>
        <source>Scaling method</source>
        <translation>Schaalmethode</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="275"/>
        <source>Nearest (fast, low quality)</source>
        <translation>Dichtstbijzijnde (snel, lage kwaliteit)</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="276"/>
        <source>Bilinear</source>
        <translation>Bilineair</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="277"/>
        <source>Lanczos (better quality)</source>
        <translation>Lanczos (betere kwaliteit)</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="309"/>
        <source>Image adjustment</source>
        <translation>Beeldaanpassing</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="78"/>
        <source>&quot;Go to flow&quot; size</source>
        <translation>Grootte van &quot;Ga naar Comic Flow&quot;</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="99"/>
        <source>Choose</source>
        <translation>Kies</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="234"/>
        <source>Image options</source>
        <translation>Afbeelding opties</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="224"/>
        <source>Contrast</source>
        <translation>Contrastwaarde</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="310"/>
        <source>Appearance</source>
        <translation>Verschijning</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="326"/>
        <source>Options</source>
        <translation>Opties</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="45"/>
        <source>Language</source>
        <translation>Taal</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="47"/>
        <source>Application language</source>
        <translation>Applicatietaal</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="49"/>
        <source>System default</source>
        <translation>Standaard van het systeem</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="100"/>
        <source>Clear</source>
        <translation>Duidelijk</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="342"/>
        <source>Comics directory</source>
        <translation>Strips map</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="96"/>
        <source>Background color</source>
        <translation>Achtergrondkleur</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="308"/>
        <source>Page Flow</source>
        <translation>Omslagbrowser</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="307"/>
        <source>General</source>
        <translation>Algemeen</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="223"/>
        <source>Brightness</source>
        <translation>Helderheid</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="317"/>
        <source>Restart is needed</source>
        <translation>Herstart is nodig</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="180"/>
        <source>Quick Navigation Mode</source>
        <translation>Snelle navigatiemodus</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="58"/>
        <source>Display</source>
        <translation>Weergave</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="60"/>
        <source>Show time in current page information label</source>
        <translation>Toon de tijd in het informatielabel van de huidige pagina</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="64"/>
        <source>Magnifying glass</source>
        <translation>Vergrootglas</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="66"/>
        <source>Circular magnifying glass</source>
        <translation>Rond vergrootglas</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="67"/>
        <source>Draw a ring around the circular magnifying glass</source>
        <translation>Een rand rond het ronde vergrootglas tekenen</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="70"/>
        <source>Ease cursor movement toward the edges</source>
        <translation>Cursorbeweging naar de randen versoepelen</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="108"/>
        <source>Scroll behaviour</source>
        <translation>Scrollgedrag</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="111"/>
        <source>Disable scroll animations and smooth scrolling</source>
        <translation>Schakel scrollanimaties en soepel scrollen uit</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="112"/>
        <source>Do not turn page using scroll</source>
        <translation>Sla de pagina niet om met scrollen</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="113"/>
        <source>Use single scroll step to turn page</source>
        <translation>Gebruik een enkele scrollstap om de pagina om te slaan</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="121"/>
        <source>Mouse mode</source>
        <translation>Muismodus</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="124"/>
        <source>Only Back/Forward buttons can turn pages</source>
        <translation>Alleen de knoppen Terug/Vooruit kunnen pagina&apos;s omslaan</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="125"/>
        <source>Use the Left/Right buttons to turn pages.</source>
        <translation>Gebruik de knoppen Links/Rechts om pagina&apos;s om te slaan.</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="126"/>
        <source>Click left or right half of the screen to turn pages.</source>
        <translation>Klik op de linker- of rechterhelft van het scherm om pagina&apos;s om te slaan.</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="134"/>
        <source>Escape key</source>
        <translation>Escape-toets</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="137"/>
        <source>Quit the reader</source>
        <translation>Reader afsluiten</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="138"/>
        <source>Cancel the active mode</source>
        <translation>Actieve modus annuleren</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="140"/>
        <source>Escape closes the reader, even while a mode is active.</source>
        <translation>Met de Escape-toets wordt de reader afgesloten, ook als er een modus actief is.</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="145"/>
        <source>Escape cancels the first of these that is active:

1. Magnifying glass
2. Dictionary
3. Go to page bar
4. Fullscreen

If none is active, Escape does nothing.</source>
        <extracomment>Tooltip listing the order in which modes are cancelled. Only the first active mode in the list is cancelled per Escape keypress.</extracomment>
        <translation>De Escape-toets annuleert de eerste actieve modus in deze lijst:

1. Vergrootglas
2. Woordenboek
3. Ga naar pagina-balk
4. Volledig scherm

Als geen enkele modus actief is, doet de Escape-toets niets.</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="176"/>
        <source>Use software-rendered &quot;go to flow&quot; (requires restart)</source>
        <translation>Softwarematig gerenderde &quot;Ga naar Comic Flow&quot; gebruiken (opnieuw opstarten vereist)</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="177"/>
        <source>Use a simple horizontal list of page thumbnails instead of the GPU-rendered 3D flow. Enable this if reading is not smooth on your system.</source>
        <translation>Gebruik een eenvoudige horizontale lijst met paginaminiaturen in plaats van de door de GPU gerenderde 3D-flow. Schakel deze optie in als het lezen op uw systeem niet vloeiend verloopt.</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="181"/>
        <source>Disable mouse over activation</source>
        <translation>Schakel muis-over-activering uit</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="238"/>
        <source>Fit options</source>
        <translation>Pas opties</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="240"/>
        <source>Enlarge images to fit width/height</source>
        <translation>Vergroot afbeeldingen zodat ze in de breedte/hoogte passen</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="251"/>
        <source>Double Page options</source>
        <translation>Opties voor dubbele pagina&apos;s</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="253"/>
        <source>Show covers as single page</source>
        <translation>Toon omslagen als enkele pagina</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../common/exit_check.cpp" line="13"/>
        <source>7z lib not found</source>
        <translation>7z-lib niet gevonden</translation>
    </message>
    <message>
        <location filename="../common/exit_check.cpp" line="13"/>
        <source>unable to load 7z lib from ./utils</source>
        <translation>kan 7z lib niet laden vanuit ./utils</translation>
    </message>
    <message>
        <location filename="../common/yacreader_global_gui.cpp" line="95"/>
        <source>Select custom cover</source>
        <translation>Selecteer een aangepaste omslag</translation>
    </message>
    <message>
        <location filename="../common/yacreader_global_gui.cpp" line="95"/>
        <source>Images (%1)</source>
        <translation>Afbeeldingen (%1)</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_repository.cpp" line="152"/>
        <source>The file could not be read or is not valid JSON.</source>
        <translation>Het bestand kan niet worden gelezen of is geen geldige JSON.</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_repository.cpp" line="161"/>
        <source>This theme is for %1, not %2.</source>
        <translation>Dit thema is voor %1, niet voor %2.</translation>
    </message>
</context>
<context>
    <name>ThemeEditorDialog</name>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="59"/>
        <source>Theme Editor</source>
        <translation>Thema-editor</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="63"/>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="64"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="65"/>
        <source>i</source>
        <translation>?</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="69"/>
        <source>Expand all</source>
        <translation>Alles uitvouwen</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="70"/>
        <source>Collapse all</source>
        <translation>Alles samenvouwen</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="71"/>
        <source>Hold to flash the selected value in the UI (magenta / toggled / 0↔10). Releases restore the original.</source>
        <translation>Houd ingedrukt om de geselecteerde waarde in de gebruikersinterface te laten knipperen (magenta / geschakeld / 0↔10). Loslaten herstelt het origineel.</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="76"/>
        <source>Search…</source>
        <translation>Zoekopdracht…</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="94"/>
        <source>Light</source>
        <translation>Licht</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="95"/>
        <source>Dark</source>
        <translation>Donker</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="98"/>
        <source>ID:</source>
        <translation>Identiteitskaart:</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="99"/>
        <source>Display name:</source>
        <translation>Weergavenaam:</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="100"/>
        <source>Variant:</source>
        <translation>Variatie:</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="102"/>
        <source>Theme info</source>
        <translation>Thema-informatie</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="125"/>
        <source>Parameter</source>
        <translation>Instelwaarde</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="125"/>
        <source>Value</source>
        <translation>Waarde</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="149"/>
        <source>Save and apply</source>
        <translation>Opslaan en toepassen</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="150"/>
        <source>Export to file...</source>
        <translation>Exporteren naar bestand...</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="151"/>
        <source>Load from file...</source>
        <translation>Laden uit bestand...</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="152"/>
        <source>Close</source>
        <translation>Sluiten</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="209"/>
        <source>Double-click to edit color</source>
        <translation>Dubbelklik om de kleur te bewerken</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="211"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="264"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="265"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="459"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="464"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="495"/>
        <source>true</source>
        <translation>WAAR</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="211"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="265"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="464"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="495"/>
        <source>false</source>
        <translation>vals</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="214"/>
        <source>Double-click to toggle</source>
        <translation>Dubbelklik om te schakelen</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="218"/>
        <source>Double-click to edit value</source>
        <translation>Dubbelklik om de waarde te bewerken</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="232"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="280"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="285"/>
        <source>Edit: %1</source>
        <translation>Bewerken: %1</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="399"/>
        <source>Save theme</source>
        <translation>Thema opslaan</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="399"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="414"/>
        <source>JSON files (*.json);;All files (*)</source>
        <translation>JSON-bestanden (*.json);;Alle bestanden (*)</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="405"/>
        <source>Save failed</source>
        <translation>Opslaan mislukt</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="405"/>
        <source>Could not open file for writing:
%1</source>
        <translation>Kan bestand niet openen om te schrijven:
%1</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="414"/>
        <source>Load theme</source>
        <translation>Thema laden</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="420"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="427"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="431"/>
        <source>Load failed</source>
        <translation>Laden mislukt</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="420"/>
        <source>Could not open file:
%1</source>
        <translation>Kan bestand niet openen:
%1</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="427"/>
        <source>Invalid JSON:
%1</source>
        <translation>Ongeldige JSON:
%1</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="431"/>
        <source>Expected a JSON object.</source>
        <translation>Er werd een JSON-object verwacht.</translation>
    </message>
</context>
<context>
    <name>Viewer</name>
    <message>
        <location filename="viewer.cpp" line="125"/>
        <location filename="viewer.cpp" line="1815"/>
        <source>Press &apos;O&apos; to open comic.</source>
        <translation>Druk &apos;O&apos; om een strip te openen.</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="2181"/>
        <source>Cover!</source>
        <translation>Omslag!</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="372"/>
        <source>Comic not found</source>
        <translation>Strip niet gevonden</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="372"/>
        <source>Not found</source>
        <translation>Niet gevonden</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="2195"/>
        <source>Last page!</source>
        <translation>Laatste pagina!</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="1832"/>
        <source>Loading...please wait!</source>
        <translation>Inladen...even wachten!</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="378"/>
        <source>Error opening comic</source>
        <translation>Fout bij openen strip</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="384"/>
        <source>CRC Error</source>
        <translation>CRC-fout</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="1843"/>
        <source>Page not available!</source>
        <translation>Pagina niet beschikbaar!</translation>
    </message>
</context>
<context>
    <name>YACReader3DFlowConfigWidget</name>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="19"/>
        <source>Presets:</source>
        <translation>Voorinstellingen:</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="21"/>
        <source>Classic look</source>
        <translation>Klassiek</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="24"/>
        <source>Stripe look</source>
        <translation>Brede band </translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="27"/>
        <source>Overlapped Stripe look</source>
        <translation>Overlappende band</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="30"/>
        <source>Modern look</source>
        <translation>Modern</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="33"/>
        <source>Roulette look</source>
        <translation>Roulette</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="77"/>
        <source>Show advanced settings</source>
        <translation>Toon geavanceerde instellingen</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="86"/>
        <source>Custom:</source>
        <translation>Aangepast:</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="89"/>
        <source>View angle</source>
        <translation>Kijkhoek</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="95"/>
        <source>Position</source>
        <translation>Positie</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="101"/>
        <source>Cover gap</source>
        <translation>Ruimte tss Omslag</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="107"/>
        <source>Central gap</source>
        <translation>Centrale ruimte</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="113"/>
        <source>Zoom</source>
        <translation>Vergroting</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="119"/>
        <source>Y offset</source>
        <translation>Y-positie</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="125"/>
        <source>Z offset</source>
        <translation>Z- positie</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="131"/>
        <source>Cover Angle</source>
        <translation>Omslag hoek</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="137"/>
        <source>Visibility</source>
        <translation>Zichtbaarheid</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="143"/>
        <source>Light</source>
        <translation>Licht</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="149"/>
        <source>Max angle</source>
        <translation>Maximale hoek</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="181"/>
        <source>Low Performance</source>
        <translation>Lage Prestaties</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="183"/>
        <source>High Performance</source>
        <translation>Hoge Prestaties</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="194"/>
        <source>Use VSync (improve the image quality in fullscreen mode, worse performance)</source>
        <translation>Gebruik VSync (verbetering van de beeldkwaliteit in de modus volledig scherm, slechtere prestatie)</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="202"/>
        <source>Performance:</source>
        <translation>Prestatie:</translation>
    </message>
</context>
<context>
    <name>YACReader::MainWindowViewer</name>
    <message>
        <location filename="main_window_viewer.cpp" line="327"/>
        <source>&amp;Open</source>
        <translation>&amp;Openen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="328"/>
        <source>Open a comic</source>
        <translation>Open een strip</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="334"/>
        <source>New instance</source>
        <translation>Nieuw exemplaar</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="353"/>
        <source>Open Folder</source>
        <translation>Map Openen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="354"/>
        <source>Open image folder</source>
        <translation>Open afbeeldings map</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="359"/>
        <source>Open latest comic</source>
        <translation>Open de nieuwste strip</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="360"/>
        <source>Open the latest comic opened in the previous reading session</source>
        <translation>Open de nieuwste strip die in de vorige leessessie is geopend</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="372"/>
        <source>Clear</source>
        <translation>Duidelijk</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="373"/>
        <source>Clear open recent list</source>
        <translation>Wis geopende recente lijst</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="376"/>
        <source>Save</source>
        <translation>Bewaar</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="377"/>
        <location filename="main_window_viewer.cpp" line="1097"/>
        <location filename="main_window_viewer.cpp" line="1108"/>
        <location filename="main_window_viewer.cpp" line="1119"/>
        <source>Save current page</source>
        <translation>Bewaren huidige pagina</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="382"/>
        <location filename="main_window_viewer.cpp" line="1124"/>
        <location filename="main_window_viewer.cpp" line="1138"/>
        <location filename="main_window_viewer.cpp" line="1149"/>
        <location filename="main_window_viewer.cpp" line="1167"/>
        <source>Extract page(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="383"/>
        <source>Extract page(s) from the original source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="388"/>
        <source>Previous Comic</source>
        <translation>Vorige Strip</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="389"/>
        <location filename="main_window_viewer.cpp" line="1915"/>
        <location filename="main_window_viewer.cpp" line="1919"/>
        <source>Open previous comic</source>
        <translation>Open de vorige strip</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="394"/>
        <source>Next Comic</source>
        <translation>Volgende Strip</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="395"/>
        <location filename="main_window_viewer.cpp" line="1914"/>
        <location filename="main_window_viewer.cpp" line="1920"/>
        <source>Open next comic</source>
        <translation>Open volgende strip</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="400"/>
        <source>&amp;Previous</source>
        <translation>&amp;Vorige</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="402"/>
        <location filename="main_window_viewer.cpp" line="1917"/>
        <location filename="main_window_viewer.cpp" line="1921"/>
        <source>Go to previous page</source>
        <translation>Ga naar de vorige pagina</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="407"/>
        <source>&amp;Next</source>
        <translation>&amp;Volgende</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="409"/>
        <location filename="main_window_viewer.cpp" line="1916"/>
        <location filename="main_window_viewer.cpp" line="1922"/>
        <source>Go to next page</source>
        <translation>Ga naar de volgende pagina</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="414"/>
        <source>Fit Height</source>
        <translation>Geschikte hoogte</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="415"/>
        <source>Fit image to height</source>
        <translation>Afbeelding aanpassen aan hoogte</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="421"/>
        <source>Fit Width</source>
        <translation>Vensterbreedte aanpassen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="422"/>
        <source>Fit image to width</source>
        <translation>Afbeelding aanpassen aan breedte</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="428"/>
        <source>Show full size</source>
        <translation>Volledig Scherm </translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="435"/>
        <source>Fit to page</source>
        <translation>Aanpassen aan pagina</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="441"/>
        <source>Continuous scroll</source>
        <translation>Continu scrollen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="442"/>
        <source>Switch to continuous scroll mode</source>
        <translation>Schakel over naar de continue scrollmodus</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="476"/>
        <source>Reset zoom</source>
        <translation>Zoom opnieuw instellen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="481"/>
        <source>Show zoom slider</source>
        <translation>Zoomschuifregelaar tonen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="483"/>
        <source>Zoom+</source>
        <translation>Inzoomen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="488"/>
        <source>Zoom-</source>
        <translation>Uitzoomen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="493"/>
        <source>Rotate image to the left</source>
        <translation>Links omdraaien</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="498"/>
        <source>Rotate image to the right</source>
        <translation>Rechts omdraaien</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="503"/>
        <source>Double page mode</source>
        <translation>Dubbele bladzijde modus</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="504"/>
        <source>Switch to double page mode</source>
        <translation>Naar dubbele bladzijde modus</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="512"/>
        <source>Double page manga mode</source>
        <translation>Manga-modus met dubbele pagina</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="513"/>
        <source>Reverse reading order in double page mode</source>
        <translation>Omgekeerde leesvolgorde in dubbele paginamodus</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="521"/>
        <source>Go To</source>
        <translation>Ga Naar</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="522"/>
        <source>Go to page ...</source>
        <translation>Ga naar bladzijde ...</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="527"/>
        <source>Options</source>
        <translation>Opties</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="528"/>
        <source>YACReader options</source>
        <translation>YACReader opties</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="534"/>
        <location filename="main_window_viewer.cpp" line="841"/>
        <source>Help</source>
        <translation>Hulp</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="535"/>
        <source>Help, About YACReader</source>
        <translation>Help, Over YACReader</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="540"/>
        <source>Magnifying glass</source>
        <translation>Vergrootglas</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="541"/>
        <source>Switch Magnifying glass</source>
        <translation>Overschakelen naar Vergrootglas</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="547"/>
        <source>Set bookmark</source>
        <translation>Bladwijzer instellen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="548"/>
        <source>Set a bookmark on the current page</source>
        <translation>Een bladwijzer toevoegen aan de huidige pagina</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="556"/>
        <source>Show bookmarks</source>
        <translation>Bladwijzers weergeven</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="557"/>
        <source>Show the bookmarks of the current comic</source>
        <translation>Toon de bladwijzers van de huidige strip</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="562"/>
        <source>Show keyboard shortcuts</source>
        <translation>Toon de sneltoetsen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="567"/>
        <source>Show Info</source>
        <translation>Info tonen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="575"/>
        <source>Escape</source>
        <translation>Escape</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="578"/>
        <source>Escape key: quit, or cancel the active mode</source>
        <translation>Escape-toets: afsluiten of actieve modus annuleren</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="583"/>
        <source>Close</source>
        <translation>Sluiten</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="586"/>
        <source>Show Dictionary</source>
        <translation>Woordenlijst weergeven</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="592"/>
        <source>Show go to flow</source>
        <translation>&quot;Ga naar Comic Flow&quot; tonen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="597"/>
        <source>Edit shortcuts</source>
        <translation>Snelkoppelingen bewerken</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="618"/>
        <source>&amp;File</source>
        <translation>&amp;Bestand</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="633"/>
        <location filename="main_window_viewer.cpp" line="795"/>
        <source>Open recent</source>
        <translation>Recent geopend</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="783"/>
        <source>File</source>
        <translation>Bestand</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="805"/>
        <source>Edit</source>
        <translation>Bewerken</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="809"/>
        <source>View</source>
        <translation>Weergave</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="826"/>
        <source>Go</source>
        <translation>Gaan</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="834"/>
        <source>Window</source>
        <translation>Raam</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="951"/>
        <source>Open Comic</source>
        <translation>Open een Strip</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="950"/>
        <source>Comic files</source>
        <translation>Strip bestanden</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1038"/>
        <source>Open folder</source>
        <translation>Open een Map</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1351"/>
        <location filename="main_window_viewer.cpp" line="1364"/>
        <source>Comics</source>
        <translation>Strips</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1375"/>
        <source>Toggle fullscreen mode</source>
        <translation>Schakel de modus Volledig scherm in</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1378"/>
        <source>Hide/show toolbar</source>
        <translation>Werkbalk verbergen/tonen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1352"/>
        <location filename="main_window_viewer.cpp" line="1381"/>
        <source>General</source>
        <translation>Algemeen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1400"/>
        <source>Size up magnifying glass</source>
        <translation>Vergrootglas vergroten</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1403"/>
        <source>Size down magnifying glass</source>
        <translation>Vergrootglas kleiner maken</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1406"/>
        <source>Zoom in magnifying glass</source>
        <translation>Zoom in vergrootglas</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1409"/>
        <source>Zoom out magnifying glass</source>
        <translation>Uitzoomen vergrootglas</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1412"/>
        <source>Reset magnifying glass</source>
        <translation>Vergrootglas opnieuw instellen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1353"/>
        <location filename="main_window_viewer.cpp" line="1419"/>
        <source>Magnifiying glass</source>
        <translation>Vergrootglas</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1426"/>
        <source>Toggle between fit to width and fit to height</source>
        <translation>Schakel tussen Aanpassen aan breedte en Aanpassen aan hoogte</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1354"/>
        <location filename="main_window_viewer.cpp" line="1430"/>
        <source>Page adjustement</source>
        <translation>Pagina-aanpassing</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1108"/>
        <source>The current page is not ready. Please try again later.</source>
        <translation>De huidige pagina is nog niet klaar. Probeer het later opnieuw.</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1113"/>
        <source>Overwrite file?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1113"/>
        <source>The file already exists. Do you want to overwrite it?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1119"/>
        <source>The current page could not be saved.</source>
        <translation>De huidige pagina kon niet worden opgeslagen.</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1138"/>
        <source>The selected pages are not ready. Please try again later.</source>
        <translation>De geselecteerde pagina’s zijn nog niet klaar. Probeer het later opnieuw.</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1149"/>
        <source>The current page could not be extracted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1154"/>
        <source>Overwrite files?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1154"/>
        <source>Some files already exist. Do you want to overwrite them?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1167"/>
        <source>Some pages could not be extracted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1448"/>
        <source>Autoscroll down</source>
        <translation>Automatisch naar beneden scrollen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1451"/>
        <source>Autoscroll up</source>
        <translation>Automatisch omhoog scrollen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1454"/>
        <source>Autoscroll forward, horizontal first</source>
        <translation>Automatisch vooruit scrollen, eerst horizontaal</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1458"/>
        <source>Autoscroll backward, horizontal first</source>
        <translation>Automatisch achteruit scrollen, eerst horizontaal</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1462"/>
        <source>Autoscroll forward, vertical first</source>
        <translation>Automatisch vooruit scrollen, eerst verticaal</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1466"/>
        <source>Autoscroll backward, vertical first</source>
        <translation>Automatisch achteruit scrollen, eerst verticaal</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1470"/>
        <source>Move down</source>
        <translation>Ga naar beneden</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1473"/>
        <source>Move up</source>
        <translation>Ga omhoog</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1476"/>
        <source>Move left</source>
        <translation>Ga naar links</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1479"/>
        <source>Move right</source>
        <translation>Ga naar rechts</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1482"/>
        <source>Go to the first page</source>
        <translation>Ga naar de eerste pagina</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1485"/>
        <source>Go to the last page</source>
        <translation>Ga naar de laatste pagina</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1488"/>
        <source>Offset double page to the left</source>
        <translation>Dubbele pagina naar links verschoven</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1490"/>
        <source>Offset double page to the right</source>
        <translation>Offset dubbele pagina naar rechts</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1355"/>
        <location filename="main_window_viewer.cpp" line="1508"/>
        <source>Reading</source>
        <translation>Lezing</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1557"/>
        <source>There is a new version available</source>
        <translation>Er is een nieuwe versie beschikbaar</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1558"/>
        <source>Do you want to download the new version?</source>
        <translation>Wilt u de nieuwe versie downloaden?</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1561"/>
        <source>Remind me in 14 days</source>
        <translation>Herinner mij er over 14 dagen aan</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1562"/>
        <source>Not now</source>
        <translation>Niet nu</translation>
    </message>
</context>
<context>
    <name>YACReader::WhatsNewDialog</name>
    <message>
        <location filename="../custom_widgets/whats_new_dialog.cpp" line="182"/>
        <source>Release notes are not available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../custom_widgets/whats_new_dialog.cpp" line="238"/>
        <source>Previous versions</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>YACReaderFieldEdit</name>
    <message>
        <location filename="../custom_widgets/yacreader_field_edit.cpp" line="11"/>
        <source>Restore to default</source>
        <translation>Standaardwaarden herstellen</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_field_edit.cpp" line="9"/>
        <location filename="../custom_widgets/yacreader_field_edit.cpp" line="28"/>
        <source>Click to overwrite</source>
        <translation>Klik hier om te overschrijven</translation>
    </message>
</context>
<context>
    <name>YACReaderFieldPlainTextEdit</name>
    <message>
        <location filename="../custom_widgets/yacreader_field_plain_text_edit.cpp" line="10"/>
        <source>Restore to default</source>
        <translation>Standaardwaarden herstellen</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_field_plain_text_edit.cpp" line="9"/>
        <location filename="../custom_widgets/yacreader_field_plain_text_edit.cpp" line="19"/>
        <location filename="../custom_widgets/yacreader_field_plain_text_edit.cpp" line="44"/>
        <location filename="../custom_widgets/yacreader_field_plain_text_edit.cpp" line="50"/>
        <source>Click to overwrite</source>
        <translation>Klik hier om te overschrijven</translation>
    </message>
</context>
<context>
    <name>YACReaderOptionsDialog</name>
    <message>
        <location filename="../custom_widgets/yacreader_options_dialog.cpp" line="21"/>
        <source>Save</source>
        <translation>Bewaar</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_options_dialog.cpp" line="22"/>
        <source>Cancel</source>
        <translation>Annuleren</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_options_dialog.cpp" line="29"/>
        <source>Keyboard shortcuts</source>
        <translation>Sneltoetsen</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_options_dialog.cpp" line="31"/>
        <source>Customize the keyboard shortcuts used by the application.</source>
        <translation>Pas de sneltoetsen aan die door de toepassing worden gebruikt.</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_options_dialog.cpp" line="32"/>
        <source>Edit shortcuts</source>
        <translation>Snelkoppelingen bewerken</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_options_dialog.cpp" line="27"/>
        <source>Shortcuts</source>
        <translation>Snelkoppelingen</translation>
    </message>
</context>
<context>
    <name>YACReaderSlider</name>
    <message>
        <location filename="width_slider.cpp" line="52"/>
        <source>Reset</source>
        <translation>Standaardwaarden terugzetten</translation>
    </message>
</context>
<context>
    <name>YACReaderTranslator</name>
    <message>
        <location filename="translator.cpp" line="40"/>
        <source>YACReader translator</source>
        <translation>YACReader-vertaler</translation>
    </message>
    <message>
        <location filename="translator.cpp" line="80"/>
        <location filename="translator.cpp" line="186"/>
        <source>Translation</source>
        <translation>Vertaling</translation>
    </message>
    <message>
        <location filename="translator.cpp" line="100"/>
        <source>clear</source>
        <translation>duidelijk</translation>
    </message>
    <message>
        <location filename="translator.cpp" line="195"/>
        <source>Service not available</source>
        <translation>Dienst niet beschikbaar</translation>
    </message>
</context>
</TS>
