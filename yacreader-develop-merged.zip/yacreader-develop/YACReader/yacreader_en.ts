<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en">
<context>
    <name>ActionsShortcutsModel</name>
    <message>
        <location filename="../shortcuts_management/actions_shortcuts_model.cpp" line="74"/>
        <source>None</source>
        <translation>None</translation>
    </message>
</context>
<context>
    <name>AppearanceTabWidget</name>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="38"/>
        <source>Color scheme</source>
        <translation>Color scheme</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="46"/>
        <source>System</source>
        <translation>System</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="47"/>
        <source>Light</source>
        <translation>Light</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="48"/>
        <source>Dark</source>
        <translation>Dark</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="49"/>
        <source>Custom</source>
        <translation>Custom</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="105"/>
        <source>Remove</source>
        <translation>Remove</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="107"/>
        <source>Remove this user-imported theme</source>
        <translation>Remove this user-imported theme</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="115"/>
        <source>Light:</source>
        <translation>Light:</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="116"/>
        <source>Dark:</source>
        <translation>Dark:</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="117"/>
        <source>Custom:</source>
        <translation>Custom:</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="119"/>
        <source>Import theme...</source>
        <translation>Import theme...</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="121"/>
        <source>Theme</source>
        <translation>Theme</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="173"/>
        <source>Theme editor</source>
        <translation>Theme editor</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="175"/>
        <source>Open Theme Editor...</source>
        <translation>Open Theme Editor...</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="184"/>
        <source>Theme editor error</source>
        <translation>Theme editor error</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="185"/>
        <source>The current theme JSON could not be loaded.</source>
        <translation>The current theme JSON could not be loaded.</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="285"/>
        <source>Import theme</source>
        <translation>Import theme</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="285"/>
        <source>JSON files (*.json);;All files (*)</source>
        <translation>JSON files (*.json);;All files (*)</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="293"/>
        <source>Could not import theme from:
%1</source>
        <translation>Could not import theme from:
%1</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="294"/>
        <source>Could not import theme from:
%1

%2</source>
        <translation>Could not import theme from:
%1

%2</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="295"/>
        <source>Import failed</source>
        <translation>Import failed</translation>
    </message>
</context>
<context>
    <name>BookmarksDialog</name>
    <message>
        <location filename="bookmarks_dialog.cpp" line="27"/>
        <source>Lastest Page</source>
        <translation>Lastest Page</translation>
    </message>
    <message>
        <location filename="bookmarks_dialog.cpp" line="77"/>
        <source>Close</source>
        <translation>Close</translation>
    </message>
    <message>
        <location filename="bookmarks_dialog.cpp" line="87"/>
        <source>Click on any image to go to the bookmark</source>
        <translation>Click on any image to go to the bookmark</translation>
    </message>
    <message>
        <location filename="bookmarks_dialog.cpp" line="109"/>
        <location filename="bookmarks_dialog.cpp" line="126"/>
        <source>Loading...</source>
        <translation>Loading...</translation>
    </message>
</context>
<context>
    <name>ContinuousPageWidget</name>
    <message>
        <location filename="continuous_page_widget.cpp" line="272"/>
        <source>Loading page %1</source>
        <translation>Loading page %1</translation>
    </message>
</context>
<context>
    <name>EditShortcutsDialog</name>
    <message>
        <location filename="../shortcuts_management/edit_shortcuts_dialog.cpp" line="19"/>
        <source>Restore defaults</source>
        <translation>Restore defaults</translation>
    </message>
    <message>
        <location filename="../shortcuts_management/edit_shortcuts_dialog.cpp" line="20"/>
        <source>To change a shortcut, double click in the key combination and type the new keys.</source>
        <translation>To change a shortcut, double click in the key combination and type the new keys.</translation>
    </message>
    <message>
        <location filename="../shortcuts_management/edit_shortcuts_dialog.cpp" line="67"/>
        <source>Shortcuts settings</source>
        <translation>Shortcuts settings</translation>
    </message>
    <message>
        <location filename="../shortcuts_management/edit_shortcuts_dialog.cpp" line="118"/>
        <source>Shortcut in use</source>
        <translation>Shortcut in use</translation>
    </message>
    <message>
        <location filename="../shortcuts_management/edit_shortcuts_dialog.cpp" line="118"/>
        <source>The shortcut &quot;%1&quot; is already assigned to other function</source>
        <translation>The shortcut &quot;%1&quot; is already assigned to other function</translation>
    </message>
</context>
<context>
    <name>FileComic</name>
    <message>
        <location filename="../common/comic.cpp" line="490"/>
        <source>CRC error on page (%1): some of the pages will not be displayed correctly</source>
        <translation>CRC error on page (%1): some of the pages will not be displayed correctly</translation>
    </message>
    <message>
        <location filename="../common/comic.cpp" line="497"/>
        <source>Unknown error opening the file</source>
        <translation>Unknown error opening the file</translation>
    </message>
    <message>
        <location filename="../common/comic.cpp" line="604"/>
        <source>7z not found</source>
        <translation>7z not found</translation>
    </message>
    <message>
        <location filename="../common/comic.cpp" line="610"/>
        <location filename="../common/comic.cpp" line="626"/>
        <source>Format not supported</source>
        <translation>Format not supported</translation>
    </message>
</context>
<context>
    <name>GoToDialog</name>
    <message>
        <location filename="goto_dialog.cpp" line="16"/>
        <source>Page : </source>
        <translation>Page : </translation>
    </message>
    <message>
        <location filename="goto_dialog.cpp" line="24"/>
        <source>Go To</source>
        <translation>Go To</translation>
    </message>
    <message>
        <location filename="goto_dialog.cpp" line="26"/>
        <source>Cancel</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="goto_dialog.cpp" line="40"/>
        <location filename="goto_dialog.cpp" line="70"/>
        <source>Total pages : </source>
        <translation>Total pages : </translation>
    </message>
    <message>
        <location filename="goto_dialog.cpp" line="52"/>
        <source>Go to...</source>
        <translation>Go to...</translation>
    </message>
</context>
<context>
    <name>GoToFlowToolBar</name>
    <message>
        <location filename="goto_flow_toolbar.cpp" line="32"/>
        <source>Page : </source>
        <translation>Page : </translation>
    </message>
</context>
<context>
    <name>HelpAboutDialog</name>
    <message>
        <location filename="../custom_widgets/help_about_dialog.cpp" line="25"/>
        <source>About</source>
        <translation>About</translation>
    </message>
    <message>
        <location filename="../custom_widgets/help_about_dialog.cpp" line="28"/>
        <source>Help</source>
        <translation>Help</translation>
    </message>
    <message>
        <location filename="../custom_widgets/help_about_dialog.cpp" line="31"/>
        <source>System info</source>
        <translation>System info</translation>
    </message>
    <message>
        <location filename="../custom_widgets/help_about_dialog.cpp" line="40"/>
        <source>Changelog</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <location filename="options_dialog.cpp" line="78"/>
        <source>&quot;Go to flow&quot; size</source>
        <translation>&quot;Go to flow&quot; size</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="38"/>
        <source>My comics path</source>
        <translation>My comics path</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="96"/>
        <source>Background color</source>
        <translation>Background color</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="99"/>
        <source>Choose</source>
        <translation>Choose</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="180"/>
        <source>Quick Navigation Mode</source>
        <translation>Quick Navigation Mode</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="181"/>
        <source>Disable mouse over activation</source>
        <translation>Disable mouse over activation</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="271"/>
        <source>Scaling</source>
        <translation>Scaling</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="273"/>
        <source>Scaling method</source>
        <translation>Scaling method</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="275"/>
        <source>Nearest (fast, low quality)</source>
        <translation>Nearest (fast, low quality)</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="276"/>
        <source>Bilinear</source>
        <translation>Bilinear</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="277"/>
        <source>Lanczos (better quality)</source>
        <translation>Lanczos (better quality)</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="317"/>
        <source>Restart is needed</source>
        <translation>Restart is needed</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="223"/>
        <source>Brightness</source>
        <translation>Brightness</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="45"/>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="47"/>
        <source>Application language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="49"/>
        <source>System default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="58"/>
        <source>Display</source>
        <translation>Display</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="60"/>
        <source>Show time in current page information label</source>
        <translation>Show time in current page information label</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="64"/>
        <source>Magnifying glass</source>
        <translation>Magnifying glass</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="66"/>
        <source>Circular magnifying glass</source>
        <translation>Circular magnifying glass</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="67"/>
        <source>Draw a ring around the circular magnifying glass</source>
        <translation>Draw a ring around the circular magnifying glass</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="70"/>
        <source>Ease cursor movement toward the edges</source>
        <translation>Ease cursor movement toward the edges</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="108"/>
        <source>Scroll behaviour</source>
        <translation>Scroll behaviour</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="111"/>
        <source>Disable scroll animations and smooth scrolling</source>
        <translation>Disable scroll animations and smooth scrolling</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="112"/>
        <source>Do not turn page using scroll</source>
        <translation>Do not turn page using scroll</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="113"/>
        <source>Use single scroll step to turn page</source>
        <translation>Use single scroll step to turn page</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="121"/>
        <source>Mouse mode</source>
        <translation>Mouse mode</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="124"/>
        <source>Only Back/Forward buttons can turn pages</source>
        <translation>Only Back/Forward buttons can turn pages</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="125"/>
        <source>Use the Left/Right buttons to turn pages.</source>
        <translation>Use the Left/Right buttons to turn pages.</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="126"/>
        <source>Click left or right half of the screen to turn pages.</source>
        <translation>Click left or right half of the screen to turn pages.</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="134"/>
        <source>Escape key</source>
        <translation>Escape key</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="137"/>
        <source>Quit the reader</source>
        <translation>Quit the reader</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="138"/>
        <source>Cancel the active mode</source>
        <translation>Cancel the active mode</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="140"/>
        <source>Escape closes the reader, even while a mode is active.</source>
        <translation>Escape closes the reader, even while a mode is active.</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="145"/>
        <source>Escape cancels the first of these that is active:

1. Magnifying glass
2. Dictionary
3. Go to page bar
4. Fullscreen

If none is active, Escape does nothing.</source>
        <extracomment>Tooltip listing the order in which modes are cancelled. Only the first active mode in the list is cancelled per Escape keypress.</extracomment>
        <translation>Escape cancels the first of these that is active:

1. Magnifying glass
2. Dictionary
3. Go to page bar
4. Fullscreen

If none is active, Escape does nothing.</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="176"/>
        <source>Use software-rendered &quot;go to flow&quot; (requires restart)</source>
        <translation>Use software-rendered &quot;go to flow&quot; (requires restart)</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="177"/>
        <source>Use a simple horizontal list of page thumbnails instead of the GPU-rendered 3D flow. Enable this if reading is not smooth on your system.</source>
        <translation>Use a simple horizontal list of page thumbnails instead of the GPU-rendered 3D flow. Enable this if reading is not smooth on your system.</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="224"/>
        <source>Contrast</source>
        <translation>Contrast</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="225"/>
        <source>Gamma</source>
        <translation>Gamma</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="229"/>
        <source>Reset</source>
        <translation>Reset</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="234"/>
        <source>Image options</source>
        <translation>Image options</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="238"/>
        <source>Fit options</source>
        <translation>Fit options</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="240"/>
        <source>Enlarge images to fit width/height</source>
        <translation>Enlarge images to fit width/height</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="251"/>
        <source>Double Page options</source>
        <translation>Double Page options</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="253"/>
        <source>Show covers as single page</source>
        <translation>Show covers as single page</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="259"/>
        <source>Show book fold shadow</source>
        <translation>Show book fold shadow</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="307"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="310"/>
        <source>Appearance</source>
        <translation>Appearance</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="100"/>
        <source>Clear</source>
        <translation>Clear</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="308"/>
        <source>Page Flow</source>
        <translation>Page Flow</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="309"/>
        <source>Image adjustment</source>
        <translation>Image adjustment</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="326"/>
        <source>Options</source>
        <translation>Options</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="342"/>
        <source>Comics directory</source>
        <translation>Comics directory</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../common/exit_check.cpp" line="13"/>
        <source>7z lib not found</source>
        <translation>7z lib not found</translation>
    </message>
    <message>
        <location filename="../common/exit_check.cpp" line="13"/>
        <source>unable to load 7z lib from ./utils</source>
        <translation>unable to load 7z lib from ./utils</translation>
    </message>
    <message>
        <location filename="../common/yacreader_global_gui.cpp" line="95"/>
        <source>Select custom cover</source>
        <translation>Select custom cover</translation>
    </message>
    <message>
        <location filename="../common/yacreader_global_gui.cpp" line="95"/>
        <source>Images (%1)</source>
        <translation>Images (%1)</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_repository.cpp" line="152"/>
        <source>The file could not be read or is not valid JSON.</source>
        <translation>The file could not be read or is not valid JSON.</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_repository.cpp" line="161"/>
        <source>This theme is for %1, not %2.</source>
        <translation>This theme is for %1, not %2.</translation>
    </message>
</context>
<context>
    <name>ThemeEditorDialog</name>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="59"/>
        <source>Theme Editor</source>
        <translation>Theme Editor</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="63"/>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="64"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="65"/>
        <source>i</source>
        <translation>i</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="69"/>
        <source>Expand all</source>
        <translation>Expand all</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="70"/>
        <source>Collapse all</source>
        <translation>Collapse all</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="71"/>
        <source>Hold to flash the selected value in the UI (magenta / toggled / 0↔10). Releases restore the original.</source>
        <translation>Hold to flash the selected value in the UI (magenta / toggled / 0↔10). Releases restore the original.</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="76"/>
        <source>Search…</source>
        <translation>Search…</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="94"/>
        <source>Light</source>
        <translation>Light</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="95"/>
        <source>Dark</source>
        <translation>Dark</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="98"/>
        <source>ID:</source>
        <translation>ID:</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="99"/>
        <source>Display name:</source>
        <translation>Display name:</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="100"/>
        <source>Variant:</source>
        <translation>Variant:</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="102"/>
        <source>Theme info</source>
        <translation>Theme info</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="125"/>
        <source>Parameter</source>
        <translation>Parameter</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="125"/>
        <source>Value</source>
        <translation>Value</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="149"/>
        <source>Save and apply</source>
        <translation>Save and apply</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="150"/>
        <source>Export to file...</source>
        <translation>Export to file...</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="151"/>
        <source>Load from file...</source>
        <translation>Load from file...</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="152"/>
        <source>Close</source>
        <translation>Close</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="209"/>
        <source>Double-click to edit color</source>
        <translation>Double-click to edit color</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="211"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="264"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="265"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="459"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="464"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="495"/>
        <source>true</source>
        <translation>true</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="211"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="265"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="464"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="495"/>
        <source>false</source>
        <translation>false</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="214"/>
        <source>Double-click to toggle</source>
        <translation>Double-click to toggle</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="218"/>
        <source>Double-click to edit value</source>
        <translation>Double-click to edit value</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="232"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="280"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="285"/>
        <source>Edit: %1</source>
        <translation>Edit: %1</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="399"/>
        <source>Save theme</source>
        <translation>Save theme</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="399"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="414"/>
        <source>JSON files (*.json);;All files (*)</source>
        <translation>JSON files (*.json);;All files (*)</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="405"/>
        <source>Save failed</source>
        <translation>Save failed</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="405"/>
        <source>Could not open file for writing:
%1</source>
        <translation>Could not open file for writing:
%1</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="414"/>
        <source>Load theme</source>
        <translation>Load theme</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="420"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="427"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="431"/>
        <source>Load failed</source>
        <translation>Load failed</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="420"/>
        <source>Could not open file:
%1</source>
        <translation>Could not open file:
%1</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="427"/>
        <source>Invalid JSON:
%1</source>
        <translation>Invalid JSON:
%1</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="431"/>
        <source>Expected a JSON object.</source>
        <translation>Expected a JSON object.</translation>
    </message>
</context>
<context>
    <name>Viewer</name>
    <message>
        <location filename="viewer.cpp" line="125"/>
        <location filename="viewer.cpp" line="1815"/>
        <source>Press &apos;O&apos; to open comic.</source>
        <translation>Press &apos;O&apos; to open comic.</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="372"/>
        <source>Not found</source>
        <translation>Not found</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="372"/>
        <source>Comic not found</source>
        <translation>Comic not found</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="378"/>
        <source>Error opening comic</source>
        <translation>Error opening comic</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="384"/>
        <source>CRC Error</source>
        <translation>CRC Error</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="1832"/>
        <source>Loading...please wait!</source>
        <translation>Loading...please wait!</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="1843"/>
        <source>Page not available!</source>
        <translation>Page not available!</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="2181"/>
        <source>Cover!</source>
        <translation>Cover!</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="2195"/>
        <source>Last page!</source>
        <translation>Last page!</translation>
    </message>
</context>
<context>
    <name>YACReader3DFlowConfigWidget</name>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="19"/>
        <source>Presets:</source>
        <translation>Presets:</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="21"/>
        <source>Classic look</source>
        <translation>Classic look</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="24"/>
        <source>Stripe look</source>
        <translation>Stripe look</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="27"/>
        <source>Overlapped Stripe look</source>
        <translation>Overlapped Stripe look</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="30"/>
        <source>Modern look</source>
        <translation>Modern look</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="33"/>
        <source>Roulette look</source>
        <translation>Roulette look</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="77"/>
        <source>Show advanced settings</source>
        <translation>Show advanced settings</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="86"/>
        <source>Custom:</source>
        <translation>Custom:</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="89"/>
        <source>View angle</source>
        <translation>View angle</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="95"/>
        <source>Position</source>
        <translation>Position</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="101"/>
        <source>Cover gap</source>
        <translation>Cover gap</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="107"/>
        <source>Central gap</source>
        <translation>Central gap</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="113"/>
        <source>Zoom</source>
        <translation>Zoom</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="119"/>
        <source>Y offset</source>
        <translation>Y offset</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="125"/>
        <source>Z offset</source>
        <translation>Z offset</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="131"/>
        <source>Cover Angle</source>
        <translation>Cover Angle</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="137"/>
        <source>Visibility</source>
        <translation>Visibility</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="143"/>
        <source>Light</source>
        <translation>Light</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="149"/>
        <source>Max angle</source>
        <translation>Max angle</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="181"/>
        <source>Low Performance</source>
        <translation>Low Performance</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="183"/>
        <source>High Performance</source>
        <translation>High Performance</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="194"/>
        <source>Use VSync (improve the image quality in fullscreen mode, worse performance)</source>
        <translation>Use VSync (improve the image quality in fullscreen mode, worse performance)</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="202"/>
        <source>Performance:</source>
        <translation>Performance:</translation>
    </message>
</context>
<context>
    <name>YACReader::MainWindowViewer</name>
    <message>
        <location filename="main_window_viewer.cpp" line="327"/>
        <source>&amp;Open</source>
        <translation>&amp;Open</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="328"/>
        <source>Open a comic</source>
        <translation>Open a comic</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="334"/>
        <source>New instance</source>
        <translation>New instance</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="353"/>
        <source>Open Folder</source>
        <translation>Open Folder</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="354"/>
        <source>Open image folder</source>
        <translation>Open image folder</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="359"/>
        <source>Open latest comic</source>
        <translation>Open latest comic</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="360"/>
        <source>Open the latest comic opened in the previous reading session</source>
        <translation>Open the latest comic opened in the previous reading session</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="372"/>
        <source>Clear</source>
        <translation>Clear</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="373"/>
        <source>Clear open recent list</source>
        <translation>Clear open recent list</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="376"/>
        <source>Save</source>
        <translation>Save</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="377"/>
        <location filename="main_window_viewer.cpp" line="1097"/>
        <location filename="main_window_viewer.cpp" line="1108"/>
        <location filename="main_window_viewer.cpp" line="1119"/>
        <source>Save current page</source>
        <translation>Save current page</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="382"/>
        <location filename="main_window_viewer.cpp" line="1124"/>
        <location filename="main_window_viewer.cpp" line="1138"/>
        <location filename="main_window_viewer.cpp" line="1149"/>
        <location filename="main_window_viewer.cpp" line="1167"/>
        <source>Extract page(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="383"/>
        <source>Extract page(s) from the original source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="388"/>
        <source>Previous Comic</source>
        <translation>Previous Comic</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="389"/>
        <location filename="main_window_viewer.cpp" line="1915"/>
        <location filename="main_window_viewer.cpp" line="1919"/>
        <source>Open previous comic</source>
        <translation>Open previous comic</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="394"/>
        <source>Next Comic</source>
        <translation>Next Comic</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="395"/>
        <location filename="main_window_viewer.cpp" line="1914"/>
        <location filename="main_window_viewer.cpp" line="1920"/>
        <source>Open next comic</source>
        <translation>Open next comic</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="400"/>
        <source>&amp;Previous</source>
        <translation>&amp;Previous</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="402"/>
        <location filename="main_window_viewer.cpp" line="1917"/>
        <location filename="main_window_viewer.cpp" line="1921"/>
        <source>Go to previous page</source>
        <translation>Go to previous page</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="407"/>
        <source>&amp;Next</source>
        <translation>&amp;Next</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="409"/>
        <location filename="main_window_viewer.cpp" line="1916"/>
        <location filename="main_window_viewer.cpp" line="1922"/>
        <source>Go to next page</source>
        <translation>Go to next page</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="414"/>
        <source>Fit Height</source>
        <translation>Fit Height</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="415"/>
        <source>Fit image to height</source>
        <translation>Fit image to height</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="421"/>
        <source>Fit Width</source>
        <translation>Fit Width</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="422"/>
        <source>Fit image to width</source>
        <translation>Fit image to width</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="428"/>
        <source>Show full size</source>
        <translation>Show full size</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="435"/>
        <source>Fit to page</source>
        <translation>Fit to page</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="441"/>
        <source>Continuous scroll</source>
        <translation>Continuous scroll</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="442"/>
        <source>Switch to continuous scroll mode</source>
        <translation>Switch to continuous scroll mode</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="476"/>
        <source>Reset zoom</source>
        <translation>Reset zoom</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="481"/>
        <source>Show zoom slider</source>
        <translation>Show zoom slider</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="483"/>
        <source>Zoom+</source>
        <translation>Zoom+</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="488"/>
        <source>Zoom-</source>
        <translation>Zoom-</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="493"/>
        <source>Rotate image to the left</source>
        <translation>Rotate image to the left</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="498"/>
        <source>Rotate image to the right</source>
        <translation>Rotate image to the right</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="503"/>
        <source>Double page mode</source>
        <translation>Double page mode</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="504"/>
        <source>Switch to double page mode</source>
        <translation>Switch to double page mode</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="512"/>
        <source>Double page manga mode</source>
        <translation>Double page manga mode</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="513"/>
        <source>Reverse reading order in double page mode</source>
        <translation>Reverse reading order in double page mode</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="521"/>
        <source>Go To</source>
        <translation>Go To</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="522"/>
        <source>Go to page ...</source>
        <translation>Go to page ...</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="527"/>
        <source>Options</source>
        <translation>Options</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="528"/>
        <source>YACReader options</source>
        <translation>YACReader options</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="534"/>
        <location filename="main_window_viewer.cpp" line="841"/>
        <source>Help</source>
        <translation>Help</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="535"/>
        <source>Help, About YACReader</source>
        <translation>Help, About YACReader</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="540"/>
        <source>Magnifying glass</source>
        <translation>Magnifying glass</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="541"/>
        <source>Switch Magnifying glass</source>
        <translation>Switch Magnifying glass</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="547"/>
        <source>Set bookmark</source>
        <translation>Set bookmark</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="548"/>
        <source>Set a bookmark on the current page</source>
        <translation>Set a bookmark on the current page</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="556"/>
        <source>Show bookmarks</source>
        <translation>Show bookmarks</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="557"/>
        <source>Show the bookmarks of the current comic</source>
        <translation>Show the bookmarks of the current comic</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="562"/>
        <source>Show keyboard shortcuts</source>
        <translation>Show keyboard shortcuts</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="567"/>
        <source>Show Info</source>
        <translation>Show Info</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="575"/>
        <source>Escape</source>
        <translation>Escape</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="578"/>
        <source>Escape key: quit, or cancel the active mode</source>
        <translation>Escape key: quit, or cancel the active mode</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="583"/>
        <source>Close</source>
        <translation>Close</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="586"/>
        <source>Show Dictionary</source>
        <translation>Show Dictionary</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="592"/>
        <source>Show go to flow</source>
        <translation>Show go to flow</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="597"/>
        <source>Edit shortcuts</source>
        <translation>Edit shortcuts</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="618"/>
        <source>&amp;File</source>
        <translation>&amp;File</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="633"/>
        <location filename="main_window_viewer.cpp" line="795"/>
        <source>Open recent</source>
        <translation>Open recent</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="783"/>
        <source>File</source>
        <translation>File</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="805"/>
        <source>Edit</source>
        <translation>Edit</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="809"/>
        <source>View</source>
        <translation>View</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="826"/>
        <source>Go</source>
        <translation>Go</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="834"/>
        <source>Window</source>
        <translation>Window</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="951"/>
        <source>Open Comic</source>
        <translation>Open Comic</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="950"/>
        <source>Comic files</source>
        <translation>Comic files</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1038"/>
        <source>Open folder</source>
        <translation>Open folder</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1351"/>
        <location filename="main_window_viewer.cpp" line="1364"/>
        <source>Comics</source>
        <translation>Comics</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1375"/>
        <source>Toggle fullscreen mode</source>
        <translation>Toggle fullscreen mode</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1378"/>
        <source>Hide/show toolbar</source>
        <translation>Hide/show toolbar</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1352"/>
        <location filename="main_window_viewer.cpp" line="1381"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1400"/>
        <source>Size up magnifying glass</source>
        <translation>Size up magnifying glass</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1403"/>
        <source>Size down magnifying glass</source>
        <translation>Size down magnifying glass</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1406"/>
        <source>Zoom in magnifying glass</source>
        <translation>Zoom in magnifying glass</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1409"/>
        <source>Zoom out magnifying glass</source>
        <translation>Zoom out magnifying glass</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1412"/>
        <source>Reset magnifying glass</source>
        <translation>Reset magnifying glass</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1353"/>
        <location filename="main_window_viewer.cpp" line="1419"/>
        <source>Magnifiying glass</source>
        <translation>Magnifiying glass</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1426"/>
        <source>Toggle between fit to width and fit to height</source>
        <translation>Toggle between fit to width and fit to height</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1354"/>
        <location filename="main_window_viewer.cpp" line="1430"/>
        <source>Page adjustement</source>
        <translation>Page adjustement</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1108"/>
        <source>The current page is not ready. Please try again later.</source>
        <translation>The current page is not ready. Please try again later.</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1113"/>
        <source>Overwrite file?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1113"/>
        <source>The file already exists. Do you want to overwrite it?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1119"/>
        <source>The current page could not be saved.</source>
        <translation>The current page could not be saved.</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1138"/>
        <source>The selected pages are not ready. Please try again later.</source>
        <translation>The selected pages are not ready. Please try again later.</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1149"/>
        <source>The current page could not be extracted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1154"/>
        <source>Overwrite files?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1154"/>
        <source>Some files already exist. Do you want to overwrite them?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1167"/>
        <source>Some pages could not be extracted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1448"/>
        <source>Autoscroll down</source>
        <translation>Autoscroll down</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1451"/>
        <source>Autoscroll up</source>
        <translation>Autoscroll up</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1454"/>
        <source>Autoscroll forward, horizontal first</source>
        <translation>Autoscroll forward, horizontal first</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1458"/>
        <source>Autoscroll backward, horizontal first</source>
        <translation>Autoscroll backward, horizontal first</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1462"/>
        <source>Autoscroll forward, vertical first</source>
        <translation>Autoscroll forward, vertical first</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1466"/>
        <source>Autoscroll backward, vertical first</source>
        <translation>Autoscroll backward, vertical first</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1470"/>
        <source>Move down</source>
        <translation>Move down</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1473"/>
        <source>Move up</source>
        <translation>Move up</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1476"/>
        <source>Move left</source>
        <translation>Move left</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1479"/>
        <source>Move right</source>
        <translation>Move right</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1482"/>
        <source>Go to the first page</source>
        <translation>Go to the first page</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1485"/>
        <source>Go to the last page</source>
        <translation>Go to the last page</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1488"/>
        <source>Offset double page to the left</source>
        <translation>Offset double page to the left</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1490"/>
        <source>Offset double page to the right</source>
        <translation>Offset double page to the right</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1355"/>
        <location filename="main_window_viewer.cpp" line="1508"/>
        <source>Reading</source>
        <translation>Reading</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1557"/>
        <source>There is a new version available</source>
        <translation>There is a new version available</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1558"/>
        <source>Do you want to download the new version?</source>
        <translation>Do you want to download the new version?</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1561"/>
        <source>Remind me in 14 days</source>
        <translation>Remind me in 14 days</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1562"/>
        <source>Not now</source>
        <translation>Not now</translation>
    </message>
</context>
<context>
    <name>YACReader::WhatsNewDialog</name>
    <message>
        <location filename="../custom_widgets/whats_new_dialog.cpp" line="182"/>
        <source>Release notes are not available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../custom_widgets/whats_new_dialog.cpp" line="238"/>
        <source>Previous versions</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>YACReaderFieldEdit</name>
    <message>
        <location filename="../custom_widgets/yacreader_field_edit.cpp" line="9"/>
        <location filename="../custom_widgets/yacreader_field_edit.cpp" line="28"/>
        <source>Click to overwrite</source>
        <translation>Click to overwrite</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_field_edit.cpp" line="11"/>
        <source>Restore to default</source>
        <translation>Restore to default</translation>
    </message>
</context>
<context>
    <name>YACReaderFieldPlainTextEdit</name>
    <message>
        <location filename="../custom_widgets/yacreader_field_plain_text_edit.cpp" line="9"/>
        <location filename="../custom_widgets/yacreader_field_plain_text_edit.cpp" line="19"/>
        <location filename="../custom_widgets/yacreader_field_plain_text_edit.cpp" line="44"/>
        <location filename="../custom_widgets/yacreader_field_plain_text_edit.cpp" line="50"/>
        <source>Click to overwrite</source>
        <translation>Click to overwrite</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_field_plain_text_edit.cpp" line="10"/>
        <source>Restore to default</source>
        <translation>Restore to default</translation>
    </message>
</context>
<context>
    <name>YACReaderOptionsDialog</name>
    <message>
        <location filename="../custom_widgets/yacreader_options_dialog.cpp" line="21"/>
        <source>Save</source>
        <translation>Save</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_options_dialog.cpp" line="22"/>
        <source>Cancel</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_options_dialog.cpp" line="29"/>
        <source>Keyboard shortcuts</source>
        <translation>Keyboard shortcuts</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_options_dialog.cpp" line="31"/>
        <source>Customize the keyboard shortcuts used by the application.</source>
        <translation>Customize the keyboard shortcuts used by the application.</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_options_dialog.cpp" line="32"/>
        <source>Edit shortcuts</source>
        <translation>Edit shortcuts</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_options_dialog.cpp" line="27"/>
        <source>Shortcuts</source>
        <translation>Shortcuts</translation>
    </message>
</context>
<context>
    <name>YACReaderSlider</name>
    <message>
        <location filename="width_slider.cpp" line="52"/>
        <source>Reset</source>
        <translation>Reset</translation>
    </message>
</context>
<context>
    <name>YACReaderTranslator</name>
    <message>
        <location filename="translator.cpp" line="40"/>
        <source>YACReader translator</source>
        <translation>YACReader translator</translation>
    </message>
    <message>
        <location filename="translator.cpp" line="80"/>
        <location filename="translator.cpp" line="186"/>
        <source>Translation</source>
        <translation>Translation</translation>
    </message>
    <message>
        <location filename="translator.cpp" line="100"/>
        <source>clear</source>
        <translation>clear</translation>
    </message>
    <message>
        <location filename="translator.cpp" line="195"/>
        <source>Service not available</source>
        <translation>Service not available</translation>
    </message>
</context>
</TS>
