#ifndef __VIEWER_H
#define __VIEWER_H

#include "mouse_handler.h"
#include "scroll_management.h"
#include "themable.h"

#include <QAction>
#include <QBuffer>
#include <QByteArray>
#include <QCloseEvent>
#include <QElapsedTimer>
#include <QGestureEvent>
#include <QLabel>
#include <QList>
#include <QMainWindow>
#include <QMouseEvent>
#include <QMovie>
#include <QParallelAnimationGroup>
#include <QPixmap>
#include <QPropertyAnimation>
#include <QResizeEvent>
#include <QScrollArea>
#include <QSettings>
#include <QSize>
#include <QTimer>
#include <QWheelEvent>

class ComicPageLabel;
class ComicDB;
class Comic;
class MagnifyingGlass;
class GoToFlow;
class BookmarksDialog;
class Render;
class GoToDialog;
class YACReaderTranslator;
class GoToFlowWidget;
class Bookmarks;
class ContinuousPageWidget;
class ContinuousPageProvider;
class ContinuousViewModel;
class PageLabelWidget;
class NotificationsLabelWidget;

class Viewer : public QScrollArea, public ScrollManagement, protected Themable
{
    Q_OBJECT
public:
    bool fullscreen; // TODO, change by the right use of windowState();
public slots:
    void increaseZoomFactor();
    void decreaseZoomFactor();
    void setZoomFactor(int);
    int getZoomFactor();

    void prepareForOpening();
    void open(QString pathFile, int atPage = -1);
    void open(QString pathFile, const ComicDB &comic);
    void prev();
    void next();
    void left();
    void right();
    void showGoToDialog();
    void goToFirstPage();
    void goToLastPage();
    void goTo(unsigned int page);
    void updatePage();
    void onImageOptionsChanged();
    void updateContentSize();
    void updateVerticalScrollBar();
    void updateOptions();
    void scrollDown();
    void scrollUp();
    void scrollForward();
    void scrollBackward();
    void scrollForwardHorizontalFirst();
    void scrollBackwardHorizontalFirst();
    void scrollForwardVerticalFirst();
    void scrollBackwardVerticalFirst();
    void magnifyingGlassSwitch();
    void showMagnifyingGlass();
    void hideMagnifyingGlass();
    void informationSwitch();
    void updateInformation();
    void goToFlowSwitch();
    void showGoToFlow();
    void moveCursoToGoToFlow();
    void animateShowGoToFlow();
    void animateHideGoToFlow();
    void rotateLeft();
    void rotateRight();
    bool magnifyingGlassIsVisible() const { return magnifyingGlassShown; }
    bool translatorIsVisible() const;
    bool goToFlowIsVisible() const;
    void setBookmark(bool);
    void save();
    void doublePageSwitch();
    void setMangaWithoutStoringSetting(bool manga);
    void setContinuousScrollWithoutStoringSetting(bool enabled);
    void doubleMangaPageSwitch();
    void resetContent();
    void setLoadingMessage();
    void setPageUnavailableMessage();
    void configureContent(QString msg);
    void hideCursor();
    void showCursor();
    void createConnections();
    void translatorSwitch();
    void animateShowTranslator();
    void animateHideTranslator();
    void mousePressEvent(QMouseEvent *event) override;
    void mouseReleaseEvent(QMouseEvent *event) override;
    void updateBackgroundColor(const QColor &color);
    void updateConfig(QSettings *settings);
    void showMessageErrorOpening();
    void showMessageErrorOpening(QString);
    void processCRCError(QString message);
    void setBookmarks();
    void offsetDoublePageToTheLeft();
    void offsetDoublePageToTheRight();
    // deprecated
    void updateImageOptions();
    void updateFilters(int brightness, int contrast, int gamma);
    void showIsCoverMessage();
    void showIsLastMessage();
    int getCurrentPageNumber();
    void updateZoomRatio(int ratio);
    bool getIsMangaMode();
    void setContinuousScroll(bool enabled);

private:
    bool information;
    bool doublePage;
    bool doubleMangaPage;
    bool continuousScroll;
    bool currentPageHasDoublePageSeam = false;
    qreal doublePageSeamRatio = 0.5;
    Qt::Orientation doublePageSeamOrientation = Qt::Vertical;

    int zoom;

    PageLabelWidget *informationLabel;
    // QTimer * scroller;
    QPropertyAnimation *verticalScroller;
    QPropertyAnimation *horizontalScroller;
    QParallelAnimationGroup *groupScroller;
    int nextPos;
    GoToFlowWidget *goToFlow;
    QPropertyAnimation *showGoToFlowAnimation;
    GoToDialog *goToDialog;
    //! Image properties
    //!  Comic
    // Comic * comic;
    int index;
    QPixmap *currentPage;
    BookmarksDialog *bd;
    bool wheelStop;
    Render *render;
    QTimer *hideCursorTimer;
    int direction;
    bool drag;

    //! Widgets
    ComicPageLabel *content;
    QLabel *messageLabel;
    ContinuousPageWidget *continuousWidget;
    ContinuousPageProvider *continuousPageProvider;
    ContinuousViewModel *continuousViewModel;
    int lastCenterPage = -1;
    int continuousRotation = 0;
    bool syncingRenderFromContinuousScroll = false;
    bool applyingContinuousModelState = false;

    YACReaderTranslator *translator;
    int translatorXPos;
    QPropertyAnimation *translatorAnimation;

    NotificationsLabelWidget *notificationsLabel;

    bool shouldOpenNext;
    bool shouldOpenPrevious;

private:
    //! Magnifying glass
    MagnifyingGlass *mglass;
    bool magnifyingGlassShown;
    bool restoreMagnifyingGlass;
    void setMagnifyingGlassShown(bool shown);
    //! When true, the loupe's sampled-region center is pushed non-linearly toward the
    //! viewport edges so edge content is reachable with less cursor travel.
    //! The push is applied per axis until the page is letterboxed by more than a fraction of
    //! its own size on that axis (a thin margin, an exact fit, or an overflowing page still
    //! ease); past that threshold the background beside the page is wide enough that easing
    //! would mostly reveal it, so the axis is left at 1:1.
    bool magnifierEdgeEase;

    //! Event handlers:
    void resizeEvent(QResizeEvent *event) override;
    void wheelEvent(QWheelEvent *event) override;
    void wheelEventMouse(QWheelEvent *event);
    void wheelEventTrackpad(QWheelEvent *event);
    void wheelEventZoom(QWheelEvent *event);
    void mouseMoveEvent(QMouseEvent *event) override;
    bool event(QEvent *event) override;
    bool gestureEvent(QGestureEvent *event);
    void captureZoomAnchor();
    bool applyZoomAtAnchor(int newZoom);
    void restoreZoomAnchor();
    void cancelZoomPreview();
    void renderFinalZoomImage();
    void positionZoomHud();

    int pinchStartZoom;
    QPoint zoomAnchorViewport;
    double zoomAnchorNormX;
    double zoomAnchorNormY;
    QLabel *zoomHud;
    QTimer *zoomHudHideTimer;
    QTimer *zoomPreviewFinishTimer;
    bool zoomPreviewActive = false;
    bool scaledContentsBeforeZoomPreview = false;
    QSize zoomPreviewBaseSize;
    int zoomPreviewBaseZoom = 100;
    int wheelZoomAccumulator = 0;
    QElapsedTimer wheelZoomTimer;

    int verticalScrollStep() const;
    int horizontalScrollStep() const;

    //! ZigzagScroll
    enum scrollDirection { UP,
                           DOWN,
                           LEFT,
                           RIGHT };
    bool isEdge(scrollDirection d);
    void scrollZigzag(scrollDirection d1, scrollDirection d2, bool forward);
    void scrollTo(int x, int y);

    // Zero when animations are disabled
    int animationDuration() const;
    void animateScroll(QPropertyAnimation &scroller, const QScrollBar &scrollBar, int delta);
    void onContinuousScroll(int value);
    void onContinuousViewModelChanged();
    void onContinuousPageRendered(int absolutePageIndex);
    void probeContinuousBufferedPages();
    void applyContinuousStateToUi();
    void scrollToCurrentContinuousPage();
    void syncRenderToContinuousReadingProgress();
    // Brings Render's current page in line with the continuous-scroll reading
    // position. Continuous mode never calls render->goTo() while scrolling, so
    // this is used lazily (on save / leaving continuous mode) to keep Render
    // state correct. It can block briefly, so it is kept off the scroll path.
    void syncRenderToContinuousPage();
    void onNumPagesReady(unsigned int numPages);
    void onRenderPageChanged(int page);
    void setActiveWidget(QWidget *w);

    //! Animated GIF playback (single page mode only)
    QMovie *animatedPage = nullptr;
    QBuffer *animatedPageBuffer = nullptr;
    QByteArray animatedPageData;
    void startAnimatedPageIfNeeded();
    void stopAnimatedPage();
    void showAnimatedFrame();
    void setContinuousScrollImpl(bool enabled, bool persistSettings);
    void setMangaModeImpl(bool manga, bool persistSettings);

    //! Mouse handler
    std::unique_ptr<YACReader::MouseHandler> mouseHandler;

protected:
    void applyTheme(const Theme &theme) override;
    bool eventFilter(QObject *obj, QEvent *event) override;

public:
    Viewer(QWidget *parent = nullptr);
    ~Viewer();
    QPixmap pixmap() const;
    QByteArray rawPage(int page) const;
    QList<int> currentRenderedPages() const;
    QList<int> currentVisiblePages() const;
    QImage grabMagnifiedRegion(const QPoint &viewerPos, const QSize &glassSize, float zoomLevel) const;
    //! Eases a cursor position (viewport coords) toward the edges to give the loupe's
    //! *content* its sampled-region center, normalized against the viewport. The outward push
    //! is bounded by the loupe's own half-size (per-axis for a rect, radially for a circle),
    //! so the cursor's point stays inside the loupe view and the strength scales with loupe
    //! size; it is skipped on an axis only where the page is letterboxed beyond a fraction of
    //! its own size.
    QPoint easeViewerPos(const QPoint &viewerPos, const QSize &glassSize, bool circular) const;
    // Comic * getComic(){return comic;}
    const BookmarksDialog *getBookmarksDialog() { return bd; }
    // returns the current index starting in 1 [1,nPages]
    unsigned int getIndex();
    void updateComic(ComicDB &comic);
    void moveView(Qt::Key directionKey);
    QString renderingSystemInfo() const;

signals:
    void backgroundChanges();
    void pageAvailable(bool);
    void pageIsBookmark(bool);
    void comicLoaded();
    void reset();
    void openNextComic();
    void openPreviousComic();
    void zoomUpdated(int);
    void magnifyingGlassVisibilityChanged(bool visible);

    // The following signals are emitted by users of this class and propagated to mglass.
    void magnifyingGlassSizeUp();
    void magnifyingGlassSizeDown();
    void magnifyingGlassZoomIn();
    void magnifyingGlassZoomOut();
    void resetMagnifyingGlass();

    friend class YACReader::MouseHandler;
};

#endif
