<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>ActionsShortcutsModel</name>
    <message>
        <location filename="../shortcuts_management/actions_shortcuts_model.cpp" line="74"/>
        <source>None</source>
        <translation>Keine</translation>
    </message>
</context>
<context>
    <name>AppearanceTabWidget</name>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="38"/>
        <source>Color scheme</source>
        <translation>Farbschema</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="46"/>
        <source>System</source>
        <translation>Systemumgebung</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="47"/>
        <source>Light</source>
        <translation>Licht</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="48"/>
        <source>Dark</source>
        <translation>Dunkel</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="49"/>
        <source>Custom</source>
        <translation>Brauch</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="105"/>
        <source>Remove</source>
        <translation>Entfernen</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="107"/>
        <source>Remove this user-imported theme</source>
        <translation>Entfernen Sie dieses vom Benutzer importierte Design</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="115"/>
        <source>Light:</source>
        <translation>Licht:</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="116"/>
        <source>Dark:</source>
        <translation>Dunkel:</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="117"/>
        <source>Custom:</source>
        <translation>Benutzerdefiniert:</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="119"/>
        <source>Import theme...</source>
        <translation>Theme importieren...</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="121"/>
        <source>Theme</source>
        <translation>Thema</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="173"/>
        <source>Theme editor</source>
        <translation>Theme-Editor</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="175"/>
        <source>Open Theme Editor...</source>
        <translation>Theme-Editor öffnen...</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="184"/>
        <source>Theme editor error</source>
        <translation>Fehler im Theme-Editor</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="185"/>
        <source>The current theme JSON could not be loaded.</source>
        <translation>Der aktuelle Theme-JSON konnte nicht geladen werden.</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="285"/>
        <source>Import theme</source>
        <translation>Thema importieren</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="285"/>
        <source>JSON files (*.json);;All files (*)</source>
        <translation>JSON-Dateien (*.json);;Alle Dateien (*)</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="293"/>
        <source>Could not import theme from:
%1</source>
        <translation>Theme konnte nicht importiert werden von:
%1</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="294"/>
        <source>Could not import theme from:
%1

%2</source>
        <translation>Theme konnte nicht importiert werden von:
%1

%2</translation>
    </message>
    <message>
        <location filename="../common/themes/appearance_tab_widget.cpp" line="295"/>
        <source>Import failed</source>
        <translation>Der Import ist fehlgeschlagen</translation>
    </message>
</context>
<context>
    <name>BookmarksDialog</name>
    <message>
        <location filename="bookmarks_dialog.cpp" line="77"/>
        <source>Close</source>
        <translation>Schliessen</translation>
    </message>
    <message>
        <location filename="bookmarks_dialog.cpp" line="109"/>
        <location filename="bookmarks_dialog.cpp" line="126"/>
        <source>Loading...</source>
        <translation>Laden...</translation>
    </message>
    <message>
        <location filename="bookmarks_dialog.cpp" line="87"/>
        <source>Click on any image to go to the bookmark</source>
        <translation>Klicke auf ein beliebiges Bild, um zum Lesezeichen zu gehen</translation>
    </message>
    <message>
        <location filename="bookmarks_dialog.cpp" line="27"/>
        <source>Lastest Page</source>
        <translation>Neueste Seite</translation>
    </message>
</context>
<context>
    <name>ContinuousPageWidget</name>
    <message>
        <location filename="continuous_page_widget.cpp" line="272"/>
        <source>Loading page %1</source>
        <translation>Seite wird geladen %1</translation>
    </message>
</context>
<context>
    <name>EditShortcutsDialog</name>
    <message>
        <location filename="../shortcuts_management/edit_shortcuts_dialog.cpp" line="19"/>
        <source>Restore defaults</source>
        <translation>Standardwerte wiederherstellen</translation>
    </message>
    <message>
        <location filename="../shortcuts_management/edit_shortcuts_dialog.cpp" line="20"/>
        <source>To change a shortcut, double click in the key combination and type the new keys.</source>
        <translation>Um ein Kürzel zu ändern, klicke doppelt auf die Tastenkombination und füge die neuen Tasten ein.</translation>
    </message>
    <message>
        <location filename="../shortcuts_management/edit_shortcuts_dialog.cpp" line="67"/>
        <source>Shortcuts settings</source>
        <translation>Kürzel-Einstellungen</translation>
    </message>
    <message>
        <location filename="../shortcuts_management/edit_shortcuts_dialog.cpp" line="118"/>
        <source>Shortcut in use</source>
        <translation>Genutzte Kürzel</translation>
    </message>
    <message>
        <location filename="../shortcuts_management/edit_shortcuts_dialog.cpp" line="118"/>
        <source>The shortcut &quot;%1&quot; is already assigned to other function</source>
        <translation>Das Kürzel &quot;%1&quot; ist bereits für eine andere Funktion in Verwendung</translation>
    </message>
</context>
<context>
    <name>FileComic</name>
    <message>
        <location filename="../common/comic.cpp" line="610"/>
        <location filename="../common/comic.cpp" line="626"/>
        <source>Format not supported</source>
        <translation>Format wird nicht unterstützt</translation>
    </message>
    <message>
        <location filename="../common/comic.cpp" line="604"/>
        <source>7z not found</source>
        <translation>7z nicht gefunden</translation>
    </message>
    <message>
        <location filename="../common/comic.cpp" line="497"/>
        <source>Unknown error opening the file</source>
        <translation>Unbekannter Fehler beim Öffnen des Files</translation>
    </message>
    <message>
        <location filename="../common/comic.cpp" line="490"/>
        <source>CRC error on page (%1): some of the pages will not be displayed correctly</source>
        <translation>CRC Error auf Seite (%1): Einige Seiten werden nicht korrekt dargestellt</translation>
    </message>
</context>
<context>
    <name>GoToDialog</name>
    <message>
        <location filename="goto_dialog.cpp" line="24"/>
        <source>Go To</source>
        <translation>Gehe zu</translation>
    </message>
    <message>
        <location filename="goto_dialog.cpp" line="52"/>
        <source>Go to...</source>
        <translation>Gehe zu...</translation>
    </message>
    <message>
        <location filename="goto_dialog.cpp" line="40"/>
        <location filename="goto_dialog.cpp" line="70"/>
        <source>Total pages : </source>
        <translation>Seiten gesamt :</translation>
    </message>
    <message>
        <location filename="goto_dialog.cpp" line="26"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <location filename="goto_dialog.cpp" line="16"/>
        <source>Page : </source>
        <translation>Seite :</translation>
    </message>
</context>
<context>
    <name>GoToFlowToolBar</name>
    <message>
        <location filename="goto_flow_toolbar.cpp" line="32"/>
        <source>Page : </source>
        <translation>Seite :</translation>
    </message>
</context>
<context>
    <name>HelpAboutDialog</name>
    <message>
        <location filename="../custom_widgets/help_about_dialog.cpp" line="28"/>
        <source>Help</source>
        <translation>Hilfe</translation>
    </message>
    <message>
        <location filename="../custom_widgets/help_about_dialog.cpp" line="31"/>
        <source>System info</source>
        <translation>Systeminformationen</translation>
    </message>
    <message>
        <location filename="../custom_widgets/help_about_dialog.cpp" line="40"/>
        <source>Changelog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../custom_widgets/help_about_dialog.cpp" line="25"/>
        <source>About</source>
        <translation>Über</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <location filename="options_dialog.cpp" line="225"/>
        <source>Gamma</source>
        <translation>Gammawert</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="229"/>
        <source>Reset</source>
        <translation>Zurücksetzen</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="38"/>
        <source>My comics path</source>
        <translation>Meine Comics-Pfad</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="259"/>
        <source>Show book fold shadow</source>
        <translation>Schatten am Buchfalz anzeigen</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="271"/>
        <source>Scaling</source>
        <translation>Skalierung</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="273"/>
        <source>Scaling method</source>
        <translation>Skalierungsmethode</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="275"/>
        <source>Nearest (fast, low quality)</source>
        <translation>Am nächsten (schnell, niedrige Qualität)</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="276"/>
        <source>Bilinear</source>
        <translation>Bilinear-Filter</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="277"/>
        <source>Lanczos (better quality)</source>
        <translation>Lanczos (bessere Qualität)</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="309"/>
        <source>Image adjustment</source>
        <translation>Bildanpassung</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="78"/>
        <source>&quot;Go to flow&quot; size</source>
        <translation>Größe von &quot;Gehe zu Comic Flow&quot;</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="99"/>
        <source>Choose</source>
        <translation>Auswählen</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="234"/>
        <source>Image options</source>
        <translation>Bilderoptionen</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="224"/>
        <source>Contrast</source>
        <translation>Kontrast</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="310"/>
        <source>Appearance</source>
        <translation>Aussehen</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="326"/>
        <source>Options</source>
        <translation>Optionen</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="45"/>
        <source>Language</source>
        <translation>Sprache</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="47"/>
        <source>Application language</source>
        <translation>Anwendungssprache</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="49"/>
        <source>System default</source>
        <translation>Systemstandard</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="100"/>
        <source>Clear</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="342"/>
        <source>Comics directory</source>
        <translation>Comics-Verzeichnis</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="96"/>
        <source>Background color</source>
        <translation>Hintergrundfarbe</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="308"/>
        <source>Page Flow</source>
        <translation>Seitenfluss</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="307"/>
        <source>General</source>
        <translation>Allgemein</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="223"/>
        <source>Brightness</source>
        <translation>Helligkeit</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="317"/>
        <source>Restart is needed</source>
        <translation>Neustart erforderlich</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="180"/>
        <source>Quick Navigation Mode</source>
        <translation>Schnellnavigations-Modus</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="58"/>
        <source>Display</source>
        <translation>Anzeige</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="60"/>
        <source>Show time in current page information label</source>
        <translation>Zeit im Informationsetikett der aktuellen Seite anzeigen</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="64"/>
        <source>Magnifying glass</source>
        <translation>Vergrößerungsglas</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="66"/>
        <source>Circular magnifying glass</source>
        <translation>Kreisförmiges Vergrößerungsglas</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="67"/>
        <source>Draw a ring around the circular magnifying glass</source>
        <translation>Einen Ring um das kreisförmige Vergrößerungsglas zeichnen</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="70"/>
        <source>Ease cursor movement toward the edges</source>
        <translation>Cursorbewegung zu den Rändern hin abfedern</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="108"/>
        <source>Scroll behaviour</source>
        <translation>Scrollverhalten</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="111"/>
        <source>Disable scroll animations and smooth scrolling</source>
        <translation>Scroll-Animationen und sanftes Scrollen deaktivieren</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="112"/>
        <source>Do not turn page using scroll</source>
        <translation>Blättern Sie nicht mit dem Scrollen um</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="113"/>
        <source>Use single scroll step to turn page</source>
        <translation>Verwenden Sie einen einzelnen Bildlaufschritt, um die Seite umzublättern</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="121"/>
        <source>Mouse mode</source>
        <translation>Mausmodus</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="124"/>
        <source>Only Back/Forward buttons can turn pages</source>
        <translation>Nur mit den Zurück-/Vorwärts-Tasten können Seiten umgeblättert werden</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="125"/>
        <source>Use the Left/Right buttons to turn pages.</source>
        <translation>Verwenden Sie die Links-/Rechts-Tasten, um Seiten umzublättern.</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="126"/>
        <source>Click left or right half of the screen to turn pages.</source>
        <translation>Klicken Sie auf die linke oder rechte Hälfte des Bildschirms, um die Seiten umzublättern.</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="134"/>
        <source>Escape key</source>
        <translation>Escape-Taste</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="137"/>
        <source>Quit the reader</source>
        <translation>Reader beenden</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="138"/>
        <source>Cancel the active mode</source>
        <translation>Aktiven Modus abbrechen</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="140"/>
        <source>Escape closes the reader, even while a mode is active.</source>
        <translation>Die Escape-Taste schließt den Reader, auch wenn ein Modus aktiv ist.</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="145"/>
        <source>Escape cancels the first of these that is active:

1. Magnifying glass
2. Dictionary
3. Go to page bar
4. Fullscreen

If none is active, Escape does nothing.</source>
        <extracomment>Tooltip listing the order in which modes are cancelled. Only the first active mode in the list is cancelled per Escape keypress.</extracomment>
        <translation>Die Escape-Taste beendet den ersten aktiven Modus in dieser Reihenfolge:

1. Lupe
2. Wörterbuch
3. „Gehe zu Seite“-Leiste
4. Vollbildmodus

Wenn keiner aktiv ist, geschieht beim Drücken der Escape-Taste nichts.</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="176"/>
        <source>Use software-rendered &quot;go to flow&quot; (requires restart)</source>
        <translation>Softwaregerenderten &quot;Gehe zu Comic Flow&quot; verwenden (Neustart erforderlich)</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="177"/>
        <source>Use a simple horizontal list of page thumbnails instead of the GPU-rendered 3D flow. Enable this if reading is not smooth on your system.</source>
        <translation>Verwenden Sie anstelle des GPU-gerenderten 3D-Flows eine einfache horizontale Liste mit Seitenminiaturen. Aktivieren Sie diese Option, wenn das Lesen auf Ihrem System nicht flüssig ist.</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="181"/>
        <source>Disable mouse over activation</source>
        <translation>Aktivierung durch Maus deaktivieren</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="238"/>
        <source>Fit options</source>
        <translation>Anpassungsoptionen</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="240"/>
        <source>Enlarge images to fit width/height</source>
        <translation>Bilder vergrößern, um sie Breite/Höhe anzupassen</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="251"/>
        <source>Double Page options</source>
        <translation>Doppelseiten-Einstellungen</translation>
    </message>
    <message>
        <location filename="options_dialog.cpp" line="253"/>
        <source>Show covers as single page</source>
        <translation>Cover als eine Seite darstellen</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../common/exit_check.cpp" line="13"/>
        <source>7z lib not found</source>
        <translation>7z-Verzeichnis nicht gefunden</translation>
    </message>
    <message>
        <location filename="../common/exit_check.cpp" line="13"/>
        <source>unable to load 7z lib from ./utils</source>
        <translation>7z -erzeichnis kann von ./utils nicht geladen werden</translation>
    </message>
    <message>
        <location filename="../common/yacreader_global_gui.cpp" line="95"/>
        <source>Select custom cover</source>
        <translation>Wählen Sie ein benutzerdefiniertes Cover</translation>
    </message>
    <message>
        <location filename="../common/yacreader_global_gui.cpp" line="95"/>
        <source>Images (%1)</source>
        <translation>Bilder (%1)</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_repository.cpp" line="152"/>
        <source>The file could not be read or is not valid JSON.</source>
        <translation>Die Datei konnte nicht gelesen werden oder ist kein gültiges JSON.</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_repository.cpp" line="161"/>
        <source>This theme is for %1, not %2.</source>
        <translation>Dieses Thema ist für %1, nicht für %2.</translation>
    </message>
</context>
<context>
    <name>ThemeEditorDialog</name>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="59"/>
        <source>Theme Editor</source>
        <translation>Theme-Editor</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="63"/>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="64"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="65"/>
        <source>i</source>
        <translation>ich</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="69"/>
        <source>Expand all</source>
        <translation>Alles erweitern</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="70"/>
        <source>Collapse all</source>
        <translation>Alles einklappen</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="71"/>
        <source>Hold to flash the selected value in the UI (magenta / toggled / 0↔10). Releases restore the original.</source>
        <translation>Halten Sie gedrückt, um den ausgewählten Wert in der Benutzeroberfläche zu blinken (Magenta / umgeschaltet / 0↔10). Loslassen stellt das Original wieder her.</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="76"/>
        <source>Search…</source>
        <translation>Suchen…</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="94"/>
        <source>Light</source>
        <translation>Licht</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="95"/>
        <source>Dark</source>
        <translation>Dunkel</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="98"/>
        <source>ID:</source>
        <translation>AUSWEIS:</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="99"/>
        <source>Display name:</source>
        <translation>Anzeigename:</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="100"/>
        <source>Variant:</source>
        <translation>Variante:</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="102"/>
        <source>Theme info</source>
        <translation>Themeninfo</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="125"/>
        <source>Parameter</source>
        <translation>Parameterwert</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="125"/>
        <source>Value</source>
        <translation>Wert</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="149"/>
        <source>Save and apply</source>
        <translation>Speichern und anwenden</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="150"/>
        <source>Export to file...</source>
        <translation>In Datei exportieren...</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="151"/>
        <source>Load from file...</source>
        <translation>Aus Datei laden...</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="152"/>
        <source>Close</source>
        <translation>Schliessen</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="209"/>
        <source>Double-click to edit color</source>
        <translation>Doppelklicken Sie, um die Farbe zu bearbeiten</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="211"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="264"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="265"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="459"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="464"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="495"/>
        <source>true</source>
        <translation>WAHR</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="211"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="265"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="464"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="495"/>
        <source>false</source>
        <translation>FALSCH</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="214"/>
        <source>Double-click to toggle</source>
        <translation>Zum Umschalten doppelklicken</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="218"/>
        <source>Double-click to edit value</source>
        <translation>Doppelklicken Sie, um den Wert zu bearbeiten</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="232"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="280"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="285"/>
        <source>Edit: %1</source>
        <translation>Bearbeiten: %1</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="399"/>
        <source>Save theme</source>
        <translation>Thema speichern</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="399"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="414"/>
        <source>JSON files (*.json);;All files (*)</source>
        <translation>JSON-Dateien (*.json);;Alle Dateien (*)</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="405"/>
        <source>Save failed</source>
        <translation>Speichern fehlgeschlagen</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="405"/>
        <source>Could not open file for writing:
%1</source>
        <translation>Die Datei konnte nicht zum Schreiben geöffnet werden:
%1</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="414"/>
        <source>Load theme</source>
        <translation>Theme laden</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="420"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="427"/>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="431"/>
        <source>Load failed</source>
        <translation>Das Laden ist fehlgeschlagen</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="420"/>
        <source>Could not open file:
%1</source>
        <translation>Datei konnte nicht geöffnet werden:
%1</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="427"/>
        <source>Invalid JSON:
%1</source>
        <translation>Ungültiger JSON:
%1</translation>
    </message>
    <message>
        <location filename="../common/themes/theme_editor_dialog.cpp" line="431"/>
        <source>Expected a JSON object.</source>
        <translation>Es wurde ein JSON-Objekt erwartet.</translation>
    </message>
</context>
<context>
    <name>Viewer</name>
    <message>
        <location filename="viewer.cpp" line="1843"/>
        <source>Page not available!</source>
        <translation>Seite nicht verfügbar!</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="125"/>
        <location filename="viewer.cpp" line="1815"/>
        <source>Press &apos;O&apos; to open comic.</source>
        <translation>&apos;O&apos; drücken, um Comic zu öffnen.</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="378"/>
        <source>Error opening comic</source>
        <translation>Fehler beim Öffnen des Comics</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="2181"/>
        <source>Cover!</source>
        <translation>Titelseite!</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="384"/>
        <source>CRC Error</source>
        <translation>CRC Fehler</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="372"/>
        <source>Comic not found</source>
        <translation>Comic nicht gefunden</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="372"/>
        <source>Not found</source>
        <translation>Nicht gefunden</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="2195"/>
        <source>Last page!</source>
        <translation>Letzte Seite!</translation>
    </message>
    <message>
        <location filename="viewer.cpp" line="1832"/>
        <source>Loading...please wait!</source>
        <translation>Ladevorgang... Bitte warten!</translation>
    </message>
</context>
<context>
    <name>YACReader3DFlowConfigWidget</name>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="19"/>
        <source>Presets:</source>
        <translation>Voreinstellungen:</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="21"/>
        <source>Classic look</source>
        <translation>Klassische Ansicht</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="24"/>
        <source>Stripe look</source>
        <translation>Streifen-Ansicht</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="27"/>
        <source>Overlapped Stripe look</source>
        <translation>Überlappende Streifen-Ansicht</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="30"/>
        <source>Modern look</source>
        <translation>Moderne Ansicht</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="33"/>
        <source>Roulette look</source>
        <translation>Zufalls-Ansicht</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="77"/>
        <source>Show advanced settings</source>
        <translation>Zeige erweiterte Einstellungen</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="86"/>
        <source>Custom:</source>
        <translation>Benutzerdefiniert:</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="89"/>
        <source>View angle</source>
        <translation>Anzeige-Winkel</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="95"/>
        <source>Position</source>
        <translation>Lage</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="101"/>
        <source>Cover gap</source>
        <translation>Titelbild-Abstand</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="107"/>
        <source>Central gap</source>
        <translation>Mittiger Abstand</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="113"/>
        <source>Zoom</source>
        <translation>Vergrößern</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="119"/>
        <source>Y offset</source>
        <translation>Y-Anpassung</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="125"/>
        <source>Z offset</source>
        <translation>Z-Anpassung</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="131"/>
        <source>Cover Angle</source>
        <translation>Titelbild Ansichtswinkel</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="137"/>
        <source>Visibility</source>
        <translation>Sichtbarkeit</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="143"/>
        <source>Light</source>
        <translation>Licht</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="149"/>
        <source>Max angle</source>
        <translation>Maximaler Winkel</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="181"/>
        <source>Low Performance</source>
        <translation>Niedrige Leistung</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="183"/>
        <source>High Performance</source>
        <translation>Hohe Leistung</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="194"/>
        <source>Use VSync (improve the image quality in fullscreen mode, worse performance)</source>
        <translation>Benutze VSync (verbessert die Bildqualität im Vollanzeigemodus, schlechtere Leistung)</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_3d_flow_config_widget.cpp" line="202"/>
        <source>Performance:</source>
        <translation>Leistung:</translation>
    </message>
</context>
<context>
    <name>YACReader::MainWindowViewer</name>
    <message>
        <location filename="main_window_viewer.cpp" line="327"/>
        <source>&amp;Open</source>
        <translation>&amp;Öffnen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="328"/>
        <source>Open a comic</source>
        <translation>Comic öffnen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="334"/>
        <source>New instance</source>
        <translation>Neuer Fall</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="353"/>
        <source>Open Folder</source>
        <translation>Ordner öffnen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="354"/>
        <source>Open image folder</source>
        <translation>Bilder-Ordner öffnen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="359"/>
        <source>Open latest comic</source>
        <translation>Neuesten Comic öffnen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="360"/>
        <source>Open the latest comic opened in the previous reading session</source>
        <translation>Öffne den neuesten Comic deiner letzten Sitzung</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="372"/>
        <source>Clear</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="373"/>
        <source>Clear open recent list</source>
        <translation>Lösche Liste zuletzt geöffneter Elemente</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="376"/>
        <source>Save</source>
        <translation>Speichern</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="377"/>
        <location filename="main_window_viewer.cpp" line="1097"/>
        <location filename="main_window_viewer.cpp" line="1108"/>
        <location filename="main_window_viewer.cpp" line="1119"/>
        <source>Save current page</source>
        <translation>Aktuelle Seite speichern</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="382"/>
        <location filename="main_window_viewer.cpp" line="1124"/>
        <location filename="main_window_viewer.cpp" line="1138"/>
        <location filename="main_window_viewer.cpp" line="1149"/>
        <location filename="main_window_viewer.cpp" line="1167"/>
        <source>Extract page(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="383"/>
        <source>Extract page(s) from the original source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="388"/>
        <source>Previous Comic</source>
        <translation>Voheriger Comic</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="389"/>
        <location filename="main_window_viewer.cpp" line="1915"/>
        <location filename="main_window_viewer.cpp" line="1919"/>
        <source>Open previous comic</source>
        <translation>Vorherigen Comic öffnen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="394"/>
        <source>Next Comic</source>
        <translation>Nächster Comic</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="395"/>
        <location filename="main_window_viewer.cpp" line="1914"/>
        <location filename="main_window_viewer.cpp" line="1920"/>
        <source>Open next comic</source>
        <translation>Nächsten Comic öffnen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="400"/>
        <source>&amp;Previous</source>
        <translation>&amp;Vorherige</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="402"/>
        <location filename="main_window_viewer.cpp" line="1917"/>
        <location filename="main_window_viewer.cpp" line="1921"/>
        <source>Go to previous page</source>
        <translation>Zur vorherigen Seite gehen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="407"/>
        <source>&amp;Next</source>
        <translation>&amp;Nächstes</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="409"/>
        <location filename="main_window_viewer.cpp" line="1916"/>
        <location filename="main_window_viewer.cpp" line="1922"/>
        <source>Go to next page</source>
        <translation>Zur nächsten Seite gehen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="414"/>
        <source>Fit Height</source>
        <translation>Höhe anpassen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="415"/>
        <source>Fit image to height</source>
        <translation>Bild an Höhe anpassen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="421"/>
        <source>Fit Width</source>
        <translation>Breite anpassen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="422"/>
        <source>Fit image to width</source>
        <translation>Bildbreite anpassen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="428"/>
        <source>Show full size</source>
        <translation>Vollansicht anzeigen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="435"/>
        <source>Fit to page</source>
        <translation>An Seite anpassen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="441"/>
        <source>Continuous scroll</source>
        <translation>Kontinuierliches Scrollen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="442"/>
        <source>Switch to continuous scroll mode</source>
        <translation>Wechseln Sie in den kontinuierlichen Bildlaufmodus</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="476"/>
        <source>Reset zoom</source>
        <translation>Zoom zurücksetzen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="481"/>
        <source>Show zoom slider</source>
        <translation>Zoomleiste anzeigen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="483"/>
        <source>Zoom+</source>
        <translation>Vergr??ern+</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="488"/>
        <source>Zoom-</source>
        <translation>Verkleinern-</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="493"/>
        <source>Rotate image to the left</source>
        <translation>Bild nach links drehen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="498"/>
        <source>Rotate image to the right</source>
        <translation>Bild nach rechts drehen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="503"/>
        <source>Double page mode</source>
        <translation>Doppelseiten-Modus</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="504"/>
        <source>Switch to double page mode</source>
        <translation>Zum Doppelseiten-Modus wechseln</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="512"/>
        <source>Double page manga mode</source>
        <translation>Doppelseiten-Manga-Modus</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="513"/>
        <source>Reverse reading order in double page mode</source>
        <translation>Umgekehrte Lesereihenfolge im Doppelseiten-Modus</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="521"/>
        <source>Go To</source>
        <translation>Gehe zu</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="522"/>
        <source>Go to page ...</source>
        <translation>Gehe zu Seite ...</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="527"/>
        <source>Options</source>
        <translation>Optionen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="528"/>
        <source>YACReader options</source>
        <translation>YACReader Optionen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="534"/>
        <location filename="main_window_viewer.cpp" line="841"/>
        <source>Help</source>
        <translation>Hilfe</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="535"/>
        <source>Help, About YACReader</source>
        <translation>Hilfe, über YACReader</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="540"/>
        <source>Magnifying glass</source>
        <translation>Vergößerungsglas</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="541"/>
        <source>Switch Magnifying glass</source>
        <translation>Vergrößerungsglas wechseln</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="547"/>
        <source>Set bookmark</source>
        <translation>Lesezeichen setzen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="548"/>
        <source>Set a bookmark on the current page</source>
        <translation>Lesezeichen auf dieser Seite setzen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="556"/>
        <source>Show bookmarks</source>
        <translation>Lesezeichen anzeigen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="557"/>
        <source>Show the bookmarks of the current comic</source>
        <translation>Lesezeichen für diesen Comic anzeigen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="562"/>
        <source>Show keyboard shortcuts</source>
        <translation>Tastenkürzel anzeigen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="567"/>
        <source>Show Info</source>
        <translation>Info anzeigen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="575"/>
        <source>Escape</source>
        <translation>Escape</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="578"/>
        <source>Escape key: quit, or cancel the active mode</source>
        <translation>Escape-Taste: Reader beenden oder aktiven Modus abbrechen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="583"/>
        <source>Close</source>
        <translation>Schliessen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="586"/>
        <source>Show Dictionary</source>
        <translation>Wörterbuch anzeigen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="592"/>
        <source>Show go to flow</source>
        <translation>&quot;Gehe zu Comic Flow&quot; anzeigen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="597"/>
        <source>Edit shortcuts</source>
        <translation>Kürzel ändern</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="618"/>
        <source>&amp;File</source>
        <translation>&amp;Datei</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="633"/>
        <location filename="main_window_viewer.cpp" line="795"/>
        <source>Open recent</source>
        <translation>Kürzlich geöffnet</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="783"/>
        <source>File</source>
        <translation>Datei</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="805"/>
        <source>Edit</source>
        <translation>Ändern</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="809"/>
        <source>View</source>
        <translation>Anzeigen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="826"/>
        <source>Go</source>
        <translation>Los</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="834"/>
        <source>Window</source>
        <translation>Fenster</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="951"/>
        <source>Open Comic</source>
        <translation>Comic öffnen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="950"/>
        <source>Comic files</source>
        <translation>Comic-Dateien</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1038"/>
        <source>Open folder</source>
        <translation>Ordner öffnen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1351"/>
        <location filename="main_window_viewer.cpp" line="1364"/>
        <source>Comics</source>
        <translation>Comichefte</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1375"/>
        <source>Toggle fullscreen mode</source>
        <translation>Vollbild-Modus umschalten</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1378"/>
        <source>Hide/show toolbar</source>
        <translation>Symbolleiste anzeigen/verstecken</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1352"/>
        <location filename="main_window_viewer.cpp" line="1381"/>
        <source>General</source>
        <translation>Allgemein</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1400"/>
        <source>Size up magnifying glass</source>
        <translation>Vergrößerungsglas vergrößern</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1403"/>
        <source>Size down magnifying glass</source>
        <translation>Vergrößerungsglas verkleinern</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1406"/>
        <source>Zoom in magnifying glass</source>
        <translation>Vergrößerungsglas reinzoomen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1409"/>
        <source>Zoom out magnifying glass</source>
        <translation>Vergrößerungsglas rauszoomen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1412"/>
        <source>Reset magnifying glass</source>
        <translation>Lupe zurücksetzen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1353"/>
        <location filename="main_window_viewer.cpp" line="1419"/>
        <source>Magnifiying glass</source>
        <translation>Vergrößerungsglas</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1426"/>
        <source>Toggle between fit to width and fit to height</source>
        <translation>Zwischen Anpassung an Seite und Höhe wechseln</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1354"/>
        <location filename="main_window_viewer.cpp" line="1430"/>
        <source>Page adjustement</source>
        <translation>Seitenanpassung</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1108"/>
        <source>The current page is not ready. Please try again later.</source>
        <translation>Die aktuelle Seite ist noch nicht bereit. Bitte versuchen Sie es später erneut.</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1113"/>
        <source>Overwrite file?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1113"/>
        <source>The file already exists. Do you want to overwrite it?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1119"/>
        <source>The current page could not be saved.</source>
        <translation>Die aktuelle Seite konnte nicht gespeichert werden.</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1138"/>
        <source>The selected pages are not ready. Please try again later.</source>
        <translation>Die ausgewählten Seiten sind noch nicht bereit. Bitte versuchen Sie es später erneut.</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1149"/>
        <source>The current page could not be extracted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1154"/>
        <source>Overwrite files?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1154"/>
        <source>Some files already exist. Do you want to overwrite them?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1167"/>
        <source>Some pages could not be extracted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1448"/>
        <source>Autoscroll down</source>
        <translation>Automatisches Runterscrollen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1451"/>
        <source>Autoscroll up</source>
        <translation>Automatisches Raufscrollen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1454"/>
        <source>Autoscroll forward, horizontal first</source>
        <translation>Automatisches Vorwärtsscrollen, horizontal zuerst</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1458"/>
        <source>Autoscroll backward, horizontal first</source>
        <translation>Automatisches Zurückscrollen, horizontal zuerst</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1462"/>
        <source>Autoscroll forward, vertical first</source>
        <translation>Automatisches Vorwärtsscrollen, vertikal zuerst</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1466"/>
        <source>Autoscroll backward, vertical first</source>
        <translation>Automatisches Zurückscrollen, vertikal zuerst</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1470"/>
        <source>Move down</source>
        <translation>Nach unten</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1473"/>
        <source>Move up</source>
        <translation>Nach oben</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1476"/>
        <source>Move left</source>
        <translation>Nach links</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1479"/>
        <source>Move right</source>
        <translation>Nach rechts</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1482"/>
        <source>Go to the first page</source>
        <translation>Zur ersten Seite gehen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1485"/>
        <source>Go to the last page</source>
        <translation>Zur letzten Seite gehen</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1488"/>
        <source>Offset double page to the left</source>
        <translation>Doppelseite nach links versetzt</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1490"/>
        <source>Offset double page to the right</source>
        <translation>Doppelseite nach rechts versetzt</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1355"/>
        <location filename="main_window_viewer.cpp" line="1508"/>
        <source>Reading</source>
        <translation>Lesend</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1557"/>
        <source>There is a new version available</source>
        <translation>Neue Version verfügbar</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1558"/>
        <source>Do you want to download the new version?</source>
        <translation>Möchten Sie die neue Version herunterladen?</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1561"/>
        <source>Remind me in 14 days</source>
        <translation>In 14 Tagen erneut erinnern</translation>
    </message>
    <message>
        <location filename="main_window_viewer.cpp" line="1562"/>
        <source>Not now</source>
        <translation>Nicht jetzt</translation>
    </message>
</context>
<context>
    <name>YACReader::WhatsNewDialog</name>
    <message>
        <location filename="../custom_widgets/whats_new_dialog.cpp" line="182"/>
        <source>Release notes are not available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../custom_widgets/whats_new_dialog.cpp" line="238"/>
        <source>Previous versions</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>YACReaderFieldEdit</name>
    <message>
        <location filename="../custom_widgets/yacreader_field_edit.cpp" line="11"/>
        <source>Restore to default</source>
        <translation>Ursprungszustand wiederherstellen</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_field_edit.cpp" line="9"/>
        <location filename="../custom_widgets/yacreader_field_edit.cpp" line="28"/>
        <source>Click to overwrite</source>
        <translation>Anklicken, um zu überschreiben</translation>
    </message>
</context>
<context>
    <name>YACReaderFieldPlainTextEdit</name>
    <message>
        <location filename="../custom_widgets/yacreader_field_plain_text_edit.cpp" line="10"/>
        <source>Restore to default</source>
        <translation>Urpsrungszustand wiederherstellen</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_field_plain_text_edit.cpp" line="9"/>
        <location filename="../custom_widgets/yacreader_field_plain_text_edit.cpp" line="19"/>
        <location filename="../custom_widgets/yacreader_field_plain_text_edit.cpp" line="44"/>
        <location filename="../custom_widgets/yacreader_field_plain_text_edit.cpp" line="50"/>
        <source>Click to overwrite</source>
        <translation>Anklicken, um zu überschreiben</translation>
    </message>
</context>
<context>
    <name>YACReaderOptionsDialog</name>
    <message>
        <location filename="../custom_widgets/yacreader_options_dialog.cpp" line="21"/>
        <source>Save</source>
        <translation>Speichern</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_options_dialog.cpp" line="22"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_options_dialog.cpp" line="29"/>
        <source>Keyboard shortcuts</source>
        <translation>Tastenkürzel</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_options_dialog.cpp" line="31"/>
        <source>Customize the keyboard shortcuts used by the application.</source>
        <translation>Passen Sie die von der Anwendung verwendeten Tastenkürzel an.</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_options_dialog.cpp" line="32"/>
        <source>Edit shortcuts</source>
        <translation>Kürzel bearbeiten</translation>
    </message>
    <message>
        <location filename="../custom_widgets/yacreader_options_dialog.cpp" line="27"/>
        <source>Shortcuts</source>
        <translation>Kürzel</translation>
    </message>
</context>
<context>
    <name>YACReaderSlider</name>
    <message>
        <location filename="width_slider.cpp" line="52"/>
        <source>Reset</source>
        <translation>Zurücksetzen</translation>
    </message>
</context>
<context>
    <name>YACReaderTranslator</name>
    <message>
        <location filename="translator.cpp" line="100"/>
        <source>clear</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location filename="translator.cpp" line="195"/>
        <source>Service not available</source>
        <translation>Service nicht verfügbar</translation>
    </message>
    <message>
        <location filename="translator.cpp" line="80"/>
        <location filename="translator.cpp" line="186"/>
        <source>Translation</source>
        <translation>Übersetzung</translation>
    </message>
    <message>
        <location filename="translator.cpp" line="40"/>
        <source>YACReader translator</source>
        <translation>YACReader Übersetzer</translation>
    </message>
</context>
</TS>
