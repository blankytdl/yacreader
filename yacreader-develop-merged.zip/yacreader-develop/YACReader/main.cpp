#include "QsLog.h"
#include "QsLogDest.h"
#include "app_language_utils.h"
#include "appearance_configuration.h"
#include "exit_check.h"
#include "main_window_viewer.h"
#include "theme_manager.h"
#include "theme_repository.h"
#include "yacreader_global.h"

#include <QApplication>
#include <QCommandLineParser>
#include <QDir>
#include <QImageReader>

using namespace QsLogging;
using namespace YACReader;

#if defined(WIN32) && defined(_DEBUG)
#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>
#define DEBUG_NEW new (_NORMAL_BLOCK, __FILE__, __LINE__)
#define new DEBUG_NEW
#endif

#ifdef Q_OS_MACOS
#include <QEvent>
#include <QFileOpenEvent>
class YACReaderApplication : public QApplication
{
public:
    YACReaderApplication(int &argc, char **argv)
        : QApplication(argc, argv)
    {
    }

    void setWindow(MainWindowViewer *w)
    {
        window = w;
    }

protected:
    bool event(QEvent *event) override
    {
        switch (event->type()) {
        case QEvent::FileOpen:
            window->openComicFromPath(static_cast<QFileOpenEvent *>(event)->file());
            return true;
        default:
            return QApplication::event(event);
        }
    }

private:
    MainWindowViewer *window;
};
#endif

void messageHandler(QtMsgType type, const QMessageLogContext &context, const QString &msg)
{
    Q_UNUSED(context);

    QByteArray localMsg = msg.toLocal8Bit();
    switch (type) {
    case QtInfoMsg: {
        QLOG_INFO() << localMsg.constData();
        break;
    }
    case QtDebugMsg: {
        QLOG_DEBUG() << localMsg.constData();
        break;
    }

    case QtWarningMsg: {
        QLOG_WARN() << localMsg.constData();
        break;
    }

    case QtCriticalMsg: {
        QLOG_ERROR() << localMsg.constData();
        break;
    }

    case QtFatalMsg: {
        QLOG_FATAL() << localMsg.constData();
        break;
    }
    }
}

int main(int argc, char *argv[])
{
    qInstallMessageHandler(messageHandler);

    QApplication::setHighDpiScaleFactorRoundingPolicy(Qt::HighDpiScaleFactorRoundingPolicy::PassThrough);

    QImageReader::setAllocationLimit(0);

#ifdef Q_OS_WIN
    // Resize glitch (QTBUG-99602): the default FLIP_DISCARD swap chain of the embedded D3D11 window
    // (go to flow) is composited apart from the raster widgets, so it falls behind the layout
    // while resizing. The legacy (blit) swap chain model is composited with the parent window.
    if (!qEnvironmentVariableIsSet("QT_D3D_NO_FLIP"))
        qputenv("QT_D3D_NO_FLIP", "1");
#endif

#if defined(_MSC_VER) && defined(_DEBUG)
    _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#endif

#ifdef Q_OS_MACOS
    YACReaderApplication app(argc, argv);
#else
    QApplication app(argc, argv);
#endif

    app.setApplicationName("YACReader");
    app.setOrganizationName("YACReader");
    YACReader::initializeSharedPluginPaths();

    auto *appearanceConfig = new AppearanceConfiguration(
            YACReader::getSettingsPath() + "/YACReader.ini", qApp);
    auto *themeRepo = new ThemeRepository(
            ":/themes", YACReader::getSettingsPath() + "/themes/user", "YACReader");
    ThemeManager::instance().initialize(appearanceConfig, themeRepo);

    if (QIcon::hasThemeIcon("YACReader")) {
        app.setWindowIcon(QIcon::fromTheme("YACReader"));
    }

    // simple commandline parser
    QCommandLineParser parser;
    parser.addHelpOption();
    parser.addVersionOption();
    parser.addOption({ "loglevel", "Set log level. Valid values: trace, info, debug, warn, error.", "loglevel", "warning" });
    parser.addPositionalArgument("[File|Directory]", "File or directory to open.");
    QCommandLineOption comicId("comicId", "", "comicId");
    QCommandLineOption libraryId("libraryId", "", "libraryId");
    QCommandLineOption readingListId("readingListId", "", "readingListId");
    // hide comicId and libraryId from help
    comicId.setFlags(QCommandLineOption::HiddenFromHelp);
    libraryId.setFlags(QCommandLineOption::HiddenFromHelp);
    readingListId.setFlags(QCommandLineOption::HiddenFromHelp);

    // process
    parser.addOption(comicId);
    parser.addOption(libraryId);
    parser.addOption(readingListId);
    parser.process(app);

    QString destLog = YACReader::getSettingsPath() + "/yacreader.log";
    QDir().mkpath(YACReader::getSettingsPath());

    Logger &logger = Logger::instance();
    logger.setLoggingLevel(QsLogging::TraceLevel);

    if (parser.isSet("loglevel")) {
        if (parser.value("loglevel") == "trace") {
            logger.setLoggingLevel(QsLogging::TraceLevel);
        } else if (parser.value("loglevel") == "info") {
            logger.setLoggingLevel(QsLogging::InfoLevel);
        } else if (parser.value("loglevel") == "debug") {
            logger.setLoggingLevel(QsLogging::DebugLevel);
        } else if (parser.value("loglevel") == "warn") {
            logger.setLoggingLevel(QsLogging::WarnLevel);
        } else if (parser.value("loglevel") == "error") {
            logger.setLoggingLevel(QsLogging::ErrorLevel);
        } else {
            parser.showHelp();
        }
    }

    DestinationPtrU fileDestination(DestinationFactory::MakeFileDestination(
            destLog, LogRotationOption::EnableLogRotation, MaxSizeBytes(1048576), MaxOldLogCount(2)));
    DestinationPtrU debugDestination(DestinationFactory::MakeDebugOutputDestination());
    logger.addDestination(std::move(debugDestination));
    logger.addDestination(std::move(fileDestination));

    QSettings uiSettings(YACReader::getSettingsPath() + "/YACReader.ini", QSettings::IniFormat);
    YACReader::UiLanguage::applyLanguage("yacreader", uiSettings.value(UI_LANGUAGE).toString());
    auto mwv = new MainWindowViewer();

    // some arguments need to be parsed after MainWindowViewer creation
    QStringList arglist = parser.positionalArguments();
    if (parser.isSet(comicId) && parser.isSet(libraryId) && arglist.count() >= 1) {
        OpenComicSource source;

        if (parser.isSet(readingListId)) {
            source = OpenComicSource { OpenComicSource::ReadingList, parser.value(readingListId).toULongLong() };
        } else {
            source = OpenComicSource { OpenComicSource::Folder, 33 }; // Folder is not needed to get the comic information, the comid id points to a unique comic
        }

        mwv->open(arglist.at(0), parser.value(comicId).toULongLong(), parser.value(libraryId).toULongLong(), source);
    } else if (arglist.count() >= 1) {
        mwv->openComicFromPath(arglist.at(0));
    }

#ifdef Q_OS_MACOS
    app.setWindow(mwv);
#endif
    mwv->show();
    int ret = app.exec();
    delete mwv;

    // Configuration::getConfiguration().save();
    YACReader::exitCheck(ret);
#ifdef Q_OS_WIN
    logger.shutDownLoggerThread();
#endif
    return ret;
}
