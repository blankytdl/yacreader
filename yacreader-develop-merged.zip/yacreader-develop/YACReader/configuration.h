#ifndef __CONFIGURATION_H
#define __CONFIGURATION_H

#include "resize_image.h"
#include "yacreader_global_gui.h"

#include <QByteArray>
#include <QColor>
#include <QDate>
#include <QObject>
#include <QSettings>
#include <QSize>
#include <QString>

#define CONF_FILE_PATH "."
#define SLIDE_ASPECT_RATIO 1.585

using namespace YACReader;

namespace YACReader {

enum FitMode {
    ToWidth = 0x01,
    ToHeight = 0x02,
    FullRes = 0x03,
    FullPage = 0x04
};

enum MouseMode {
    Normal,
    LeftRightNavigation,
    HotAreas
};

enum EscapeKeyBehavior {
    EscapeQuits = 0,
    EscapeCancelsMode = 1
};

class Configuration : public QObject
{
    Q_OBJECT

private:
    QSettings *settings;

    Configuration();

public:
    static Configuration &getConfiguration()
    {
        static Configuration configuration;
        return configuration;
    }
    QSettings *getSettings();
    void load(QSettings *settings);
    QString getDefaultPath() { return settings->value(PATH).toString(); }
    void setDefaultPath(QString defaultPath) { settings->setValue(PATH, defaultPath); }
    QSize getMagnifyingGlassSize() { return settings->value(MAG_GLASS_SIZE).toSize(); }
    void setMagnifyingGlassSize(const QSize &mgs) { settings->setValue(MAG_GLASS_SIZE, mgs); }
    float getMagnifyingGlassZoom() { return settings->value(MAG_GLASS_ZOOM, 0.5).toFloat(); }
    void setMagnifyingGlassZoom(float mgz) { settings->setValue(MAG_GLASS_ZOOM, mgz); }
    bool getMagnifyingGlassCircular() { return settings->value(MAG_GLASS_CIRCULAR, false).toBool(); }
    void setMagnifyingGlassCircular(bool circular) { settings->setValue(MAG_GLASS_CIRCULAR, circular); }
    bool getMagnifyingGlassRing() { return settings->value(MAG_GLASS_RING, true).toBool(); }
    void setMagnifyingGlassRing(bool ring) { settings->setValue(MAG_GLASS_RING, ring); }
    bool getMagnifyingGlassEdgeEase() { return settings->value(MAG_GLASS_EDGE_EASE, true).toBool(); }
    void setMagnifyingGlassEdgeEase(bool ease) { settings->setValue(MAG_GLASS_EDGE_EASE, ease); }
    QSize getGotoSlideSize() { return settings->value(GO_TO_FLOW_SIZE).toSize(); }
    void setGotoSlideSize(const QSize &gss) { settings->setValue(GO_TO_FLOW_SIZE, gss); }
    float getZoomLevel() { return settings->value(ZOOM_LEVEL).toFloat(); }
    void setZoomLevel(float zl) { settings->setValue(ZOOM_LEVEL, zl); }

    // Unified enum based fitmode
    YACReader::FitMode getFitMode() { return static_cast<YACReader::FitMode>(settings->value(FITMODE, YACReader::FitMode::FullPage).toInt()); }
    void setFitMode(YACReader::FitMode fitMode) { settings->setValue(FITMODE, static_cast<int>(fitMode)); }

    // openRecent
    int getOpenRecentSize() { return settings->value("recentSize", 25).toInt(); }
    QStringList openRecentList() { return settings->value("recentFiles").toStringList(); }
    void updateOpenRecentList(QString path);
    void clearOpenRecentList() { settings->remove("recentFiles"); }

    FlowType getFlowType() { return (FlowType)settings->value(FLOW_TYPE_SW).toInt(); }
    void setFlowType(FlowType type) { settings->setValue(FLOW_TYPE_SW, type); }
    bool getFullScreen() { return settings->value(FULLSCREEN).toBool(); }
    void setFullScreen(bool f) { settings->setValue(FULLSCREEN, f); }

    QByteArray getGeometry() const { return settings->value(Y_WINDOW_GEOMETRY).toByteArray(); }
    void setGeometry(const QByteArray &g) { settings->setValue(Y_WINDOW_GEOMETRY, g); }
    bool getDoublePage() { return settings->value(DOUBLE_PAGE).toBool(); }
    void setDoublePage(bool b) { settings->setValue(DOUBLE_PAGE, b); }
    bool getDoubleMangaPage() { return settings->value(DOUBLE_MANGA_PAGE).toBool(); }
    void setDoubleMangaPage(bool b) { settings->setValue(DOUBLE_MANGA_PAGE, b); }
    bool getDoublePageShadow() { return settings->value(DOUBLE_PAGE_SHADOW, false).toBool(); }
    void setDoublePageShadow(bool b) { settings->setValue(DOUBLE_PAGE_SHADOW, b); }
    bool getContinuousScroll() { return settings->value(CONTINUOUS_SCROLL, false).toBool(); }
    void setContinuousScroll(bool b) { settings->setValue(CONTINUOUS_SCROLL, b); }
    bool getEnlargeImages() { return settings->value(ENLARGE_IMAGES, true).toBool(); }
    void setEnlargeImages(bool b) { settings->setValue(ENLARGE_IMAGES, b); }

    QColor getBackgroundColor(const QColor &color) { return settings->value(BACKGROUND_COLOR, color).value<QColor>(); }
    void setBackgroundColor(const QColor &color) { settings->setValue(BACKGROUND_COLOR, color); }
    bool getShowToolbars() { return settings->value(SHOW_TOOLBARS).toBool(); }
    void setShowToolbars(bool b) { settings->setValue(SHOW_TOOLBARS, b); }
    bool getShowInformation() { return settings->value(SHOW_INFO, false).toBool(); }
    void setShowInformation(bool b) { settings->setValue(SHOW_INFO, b); }
    bool getShowTimeInInformation() { return settings->value(SHOW_TIME_IN_INFO, true).toBool(); }
    void setShowTimeInInformation(bool b) { settings->setValue(SHOW_TIME_IN_INFO, b); }
    QDate getLastVersionCheck() { return settings->value(LAST_VERSION_CHECK).toDate(); }
    void setLastVersionCheck(const QDate &date) { settings->setValue(LAST_VERSION_CHECK, date); }
    int getNumDaysBetweenVersionChecks() { return settings->value(NUM_DAYS_BETWEEN_VERSION_CHECKS, 1).toInt(); }
    void setNumDaysBetweenVersionChecks(int days) { return settings->setValue(NUM_DAYS_BETWEEN_VERSION_CHECKS, days); }
    bool getQuickNaviMode() { return settings->value(QUICK_NAVI_MODE).toBool(); }
    bool getDisableShowOnMouseOver() { return settings->value(DISABLE_MOUSE_OVER_GOTO_FLOW).toBool(); }
    bool getUseSoftwareGoToFlow() { return settings->value(USE_SOFTWARE_GO_TO_FLOW, false).toBool(); }
    void setUseSoftwareGoToFlow(bool b) { settings->setValue(USE_SOFTWARE_GO_TO_FLOW, b); }
    bool getDoNotTurnPageOnScroll() { return settings->value(DO_NOT_TURN_PAGE_ON_SCROLL, false).toBool(); }
    bool getUseSingleScrollStepToTurnPage() { return settings->value(USE_SINGLE_SCROLL_STEP_TO_TURN_PAGE, false).toBool(); }
    void setDisableScrollAnimation(bool b) { settings->setValue(DISABLE_SCROLL_ANIMATION, b); }
    bool getDisableScrollAnimation()
    {
#ifdef Q_OS_MACOS
        auto defaultValue = true;
#else
        auto defaultValue = false;
#endif

        return settings->value(DISABLE_SCROLL_ANIMATION, defaultValue).toBool();
    }

    MouseMode getMouseMode() { return static_cast<MouseMode>(settings->value(MOUSE_MODE, MouseMode::Normal).toInt()); }
    void setMouseMode(MouseMode mouseMode) { settings->setValue(MOUSE_MODE, static_cast<int>(mouseMode)); }

    EscapeKeyBehavior getEscapeKeyBehavior() { return static_cast<EscapeKeyBehavior>(settings->value(ESCAPE_KEY_BEHAVIOR, EscapeKeyBehavior::EscapeQuits).toInt()); }
    void setEscapeKeyBehavior(EscapeKeyBehavior behavior) { settings->setValue(ESCAPE_KEY_BEHAVIOR, static_cast<int>(behavior)); }

    ScaleMethod getScalingMethod() { return static_cast<ScaleMethod>(settings->value(SCALING_METHOD, static_cast<int>(ScaleMethod::Lanczos)).toInt()); }
    void setScalingMethod(ScaleMethod method) { settings->setValue(SCALING_METHOD, static_cast<int>(method)); }
};

}

#endif
