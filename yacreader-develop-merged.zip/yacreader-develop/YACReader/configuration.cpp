#include "configuration.h"

#include <QCoreApplication>
#include <QFile>
#include <QMessageBox>
#include <QStringList>
#include <QTextStream>

Configuration::Configuration()
{
}

QSettings *Configuration::getSettings()
{
    return settings;
}

void Configuration::load(QSettings *settings)
{
    this->settings = settings;

    // TODO set defaults
    if (!settings->contains(PATH))
        settings->setValue(PATH, ".");
    if (!settings->contains(GO_TO_FLOW_SIZE))
        settings->setValue(GO_TO_FLOW_SIZE, QSize(126, 200));
    if (!settings->contains(MAG_GLASS_SIZE))
        settings->setValue(MAG_GLASS_SIZE, QSize(350, 175));
    if (!settings->contains(MAG_GLASS_ZOOM))
        settings->setValue(MAG_GLASS_ZOOM, 0.5);
    if (!settings->contains(MAG_GLASS_CIRCULAR))
        settings->setValue(MAG_GLASS_CIRCULAR, false);
    if (!settings->contains(MAG_GLASS_RING))
        settings->setValue(MAG_GLASS_RING, true);
    if (!settings->contains(MAG_GLASS_EDGE_EASE))
        settings->setValue(MAG_GLASS_EDGE_EASE, true);
    if (!settings->contains(FLOW_TYPE))
        settings->setValue(FLOW_TYPE, 0);
    if (!settings->contains(FULLSCREEN))
        settings->setValue(FULLSCREEN, false);
    if (!settings->contains(DOUBLE_PAGE))
        settings->setValue(DOUBLE_PAGE, false);
    if (!settings->contains(SHOW_TOOLBARS))
        settings->setValue(SHOW_TOOLBARS, true);
    if (!settings->contains(QUICK_NAVI_MODE))
        settings->setValue(QUICK_NAVI_MODE, false);
}
void Configuration::updateOpenRecentList(QString path)
{
    QStringList list = openRecentList();
    list.removeAll(path);
    list.prepend(path);
    // TODO: Make list lenght configurable
    while (list.length() > getOpenRecentSize()) {
        list.removeLast();
    }
    settings->setValue("recentFiles", list);
}
