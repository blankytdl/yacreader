#include "goto_dialog.h"

#include <QHBoxLayout>
#include <QIntValidator>
#include <QVBoxLayout>

GoToDialog::GoToDialog(QWidget *parent)
    : QDialog(parent)
{
    setupUI();
    initTheme(this);
}

void GoToDialog::setupUI()
{
    textLabel = new QLabel(tr("Page : "));
    pageNumber = new QLineEdit;
    v = new QIntValidator(this);
    v->setBottom(1);
    pageNumber->setValidator(v);
    textLabel->setBuddy(pageNumber);
    textLabel->setAlignment(Qt::AlignRight | Qt::AlignVCenter);

    accept = new QPushButton(tr("Go To"));
    connect(accept, &QAbstractButton::clicked, this, &GoToDialog::goTo);
    cancel = new QPushButton(tr("Cancel"));
    connect(cancel, &QAbstractButton::clicked, this, &QWidget::close);

    auto topLayout = new QHBoxLayout;

    topLayout->addWidget(textLabel);
    topLayout->addWidget(pageNumber);

    auto bottomLayout = new QHBoxLayout;
    bottomLayout->addStretch();
    bottomLayout->addWidget(accept);
    bottomLayout->addWidget(cancel);

    auto mainLayout = new QVBoxLayout;
    mainLayout->addWidget(numPagesLabel = new QLabel(tr("Total pages : ")));
    mainLayout->addLayout(topLayout);
    mainLayout->addStretch();
    mainLayout->addLayout(bottomLayout);

    auto imgMainLayout = new QHBoxLayout;
    imgLabel = new QLabel();
    imgMainLayout->addWidget(imgLabel);
    imgMainLayout->addLayout(mainLayout);

    setLayout(imgMainLayout);

    setWindowTitle(tr("Go to..."));
    setModal(true);

    pageNumber->setFocusPolicy(Qt::StrongFocus);
    pageNumber->setFocus();
}

void GoToDialog::goTo()
{
    unsigned int page = pageNumber->text().toInt();
    if (page >= 1 && page <= v->top()) {
        emit goToPage(page - 1);
        close();
    }
}

void GoToDialog::setNumPages(unsigned int numPages)
{
    numPagesLabel->setText(tr("Total pages : ") + QString::number(numPages));
    v->setTop(numPages);
}

void GoToDialog::open()
{
    pageNumber->clear();
    pageNumber->setFocus();
    QDialog::open();
}

void GoToDialog::applyTheme(const Theme &theme)
{
    imgLabel->setPixmap(theme.dialogIcons.goToDialogIcon);
}
