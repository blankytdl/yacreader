#ifndef YACREADER_TABLE_VIEW_H
#define YACREADER_TABLE_VIEW_H

#include "themable.h"

#include <QStyledItemDelegate>
#include <QTableView>

class QResizeEvent;

class YACReaderTableView : public QTableView, protected Themable
{
    Q_OBJECT
public:
    explicit YACReaderTableView(QWidget *parent = 0);
    QColor starRatingColor() const { return theme.comicsViewTable.starRatingColor; }
    QColor starRatingSelectedColor() const { return theme.comicsViewTable.starRatingSelectedColor; }

protected:
    void applyTheme(const Theme &theme) override;

signals:
    void comicRated(int, QModelIndex);
    void customCoverDropped(const QString &imagePath, const QModelIndex &index);
public slots:
    void closeRatingEditor();
protected slots:

    void closeEditor(QWidget *editor, QAbstractItemDelegate::EndEditHint hint) override;
    void commitData(QWidget *editor) override;

private:
    void resizeEvent(QResizeEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;
    void leaveEvent(QEvent *event) override;
    void performDrag();
    void dragEnterEvent(QDragEnterEvent *event) override;
    void dragMoveEvent(QDragMoveEvent *event) override;
    void dropEvent(QDropEvent *event) override;

    bool editing;
    QModelIndex currentIndexEditing;
    QWidget *myeditor;

    // drag from here
    QPoint startDragPos;
};

//---

class YACReaderRatingDelegate : public QStyledItemDelegate
{
    Q_OBJECT

public:
    YACReaderRatingDelegate(QWidget *parent = 0)
        : QStyledItemDelegate(parent) { }

    void paint(QPainter *painter, const QStyleOptionViewItem &option,
               const QModelIndex &index) const;
    QSize sizeHint(const QStyleOptionViewItem &option,
                   const QModelIndex &index) const;
    QWidget *createEditor(QWidget *parent, const QStyleOptionViewItem &option,
                          const QModelIndex &index) const;
    void setEditorData(QWidget *editor, const QModelIndex &index) const;
    void setModelData(QWidget *editor, QAbstractItemModel *model,
                      const QModelIndex &index) const;

private slots:
    void sendCloseEditor();
    void sendCommitData();
};

//---

class StarRating
{
public:
    enum EditMode { Editable,
                    ReadOnly };

    StarRating(int starCount = 1, int maxStarCount = 5);

    void paint(QPainter *painter, const QRect &rect,
               const QPalette &palette, EditMode mode) const;
    void paint(QPainter *painter, const QRect &rect,
               const QPalette &palette, EditMode mode, QColor color) const;
    void paintSelected(QPainter *painter, const QRect &rect,
                       const QPalette &palette, EditMode mode, QColor color) const;
    void paintSelected(QPainter *painter, const QRect &rect,
                       const QPalette &palette, EditMode mode) const;
    QSize sizeHint() const;
    int starCount() const { return myStarCount; }
    int maxStarCount() const { return myMaxStarCount; }
    void setStarCount(int starCount) { myStarCount = starCount; }
    void setMaxStarCount(int maxStarCount) { myMaxStarCount = maxStarCount; }

private:
    QPolygonF starPolygon;
    QPolygonF diamondPolygon;
    int myStarCount;
    int myMaxStarCount;
};
Q_DECLARE_METATYPE(StarRating);
//---

class StarEditor : public QWidget
{
    Q_OBJECT

public:
    StarEditor(QWidget *parent = 0);

    QSize sizeHint() const;
    void setStarRating(const StarRating &starRating)
    {
        myStarRating = starRating;
    }
    StarRating starRating() { return myStarRating; }
    bool getShouldCommitData() { return shouldCommitData; };

signals:
    void editingFinished();
    void commitData();

protected:
    void paintEvent(QPaintEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
    void mousePressEvent(QMouseEvent *event);
    void leaveEvent(QEvent *event);

private:
    int starAtPosition(int x);
    StarRating myStarRating;
    bool shouldCommitData;
};
#endif // YACREADER_TABLE_VIEW_H
